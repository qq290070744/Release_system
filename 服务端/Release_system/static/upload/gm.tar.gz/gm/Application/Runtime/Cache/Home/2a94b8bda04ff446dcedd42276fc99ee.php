<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>精武门——管理平台</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>

<!-- 主题样式 -->
<link href="/gm/Public/static/js/ExtJs/lib/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" type="text/css"  />
<!-- ico图标样式 -->
<link href="/gm/Public/static/css/icon.css" rel="stylesheet" type="text/css"  />
<!-- 自定义样式 -->

<link href="/gm/Public/static/css/system.css" rel="stylesheet" type="text/css" />

<!-- ExtJs入口文件 -->
<script src="/gm/Public/static/js/ExtJs/lib/ext-all.js" charset="UTF-8" type="text/javascript"></script>

<!-- Chart引用文件 -->
<script src="/gm/Public/static/js/ExtJs/lib/packages/sencha-charts/build/sencha-charts.js"></script>


<script type="text/javascript" src="/gm/Public/static/languages.js"></script>  

<script type="text/javascript" src="/gm/Public/static/js/ckeditor/ckeditor.js"></script>



<!-- 脚本程序 -->


<script src="/gm/Public/static/js/index/app.js"></script>


</head>
<body>

	<script type="text/javascript">
	//这里是主界面
	//这里是用来切换 语言的脚本  
	var cookie = new Ext.state.CookieProvider(); 
	Ext.state.Manager.setProvider(cookie); 
	var params = cookie.get("languages");
	
	if(params)
	{
		//切换前端语言
		var url = Ext.util.Format.format('/gm/Public/static/js/ExtJs/lib/packages/ext-locale/build/ext-locale-{0}.js', params); 
		var url2 = Ext.util.Format.format('/gm/Public/static/js/ext-lang/{0}.js', params); 	
   
		var script = document.createElement('script');
		script.type = "text/javascript";
		script.src = url;
		document.body.appendChild(script);
		
		var script2 = document.createElement('script');
		script2.type = "text/javascript";
		script2.src = url2;
		document.body.appendChild(script2);
		
		//切换后台语言
		Ext.Ajax.request({
			url: '<?php echo U('lang');?>',
			method: 'GET',
			params: { lang: params},
			success: function (response, options) {
                //location.reload();
            },
		});
	}
	</script>

</body>
</html>