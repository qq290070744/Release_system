<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>精武门——管理平台</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>

<!-- 主题样式 -->
<link href="/gm/Public/static/js/ExtJs/lib/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" type="text/css"  />
<!-- ico图标样式 -->
<link href="/gm/Public/static/css/icon.css" rel="stylesheet" type="text/css"  />
<!-- 自定义样式 -->

<link href="/gm/Public/static/css/system.css" rel="stylesheet" type="text/css" />

<!-- ExtJs入口文件 -->
<script src="/gm/Public/static/js/ExtJs/lib/ext-all.js" charset="UTF-8" type="text/javascript"></script>

<!-- Chart引用文件 -->
<script src="/gm/Public/static/js/ExtJs/lib/packages/sencha-charts/build/sencha-charts.js"></script>


<script type="text/javascript" src="/gm/Public/static/languages.js"></script>  

<script type="text/javascript" src="/gm/Public/static/js/ckeditor/ckeditor.js"></script>



<!-- 脚本程序 -->

    <script>
		//定义验证码控件  
		//这是登陆页面 运行脚本
        Ext.onReady(function(){	
		    var store = Ext.create('Ext.data.ArrayStore', {  
                fields: ['code', 'language'],  
                data  : Ext.local.languages //from languages.js  
            }); 
			
            Ext.create('Ext.window.Window', {
                title: 'UserLogin',
                draggable: false,
                closable: false,
				resizable : false,
                layout: 'fit',
                items: { 
                    xtype: 'form',
                    id: 'loginform',
					bodyPadding : 10,
                    defaultType: 'textfield',
                    shrinkWrap: 3,
                    bodyCls: 'loginformbg',
                    fieldDefaults: {
                        allowBlank: false,
                        labelAlign: 'center',
                        labelWidth: 50,
                        labelSeparator: ''
                    },
                    items: [{
                        fieldLabel: 'username',
                        name: 'username',
						id:'username',
                        fieldCls: 'username-ico'						
                    }, {
                        fieldLabel: 'password',
                        name: 'password',
						id:'password',
                        inputType: 'password',
                        fieldCls: 'userpassword-ico'
                    },{
						xtype:'combobox',
						id:'languages',
						name:'languages',
						fieldLabel:'languages',  
						triggerAction: 'all',
						emptyText: 'Select a language...',
						store: store,
						displayField:'language',
						valueField:'code',  
						mode: 'local',
						forceSelection : true,
						typeAhead : true, 
						handleHeight : 10
					}
					]
                },
				buttons: [
				  {
                        text: 'login',
                        iconCls: 'Doorin',
                        id: 'loginbtn',
                        handler: function(){
                            //得到form  
                            var basic = Ext.getCmp('loginform');
                            if (basic.isValid()) {
                                basic.submit({
                                    clientValidation: true,//要经过客户端验证的  
                                    url: '<?php echo U('login');?>',
                                    method: 'POST',
                                    success: function(form, action){
                                        if (action.result.msg == 'OK') {
											var languages = Ext.getCmp('languages').getValue();
											
											var cookie = new Ext.state.CookieProvider()
											Ext.state.Manager.setProvider(cookie);
											cookie.set("languages",languages);
											
											window.location.href=action.result.url;
                                        }
                                    },
                                    failure: function(form, action){
										if(action.result.msg != null)
										{
											Ext.Msg.alert('error',action.result.msg , function(){
												basic.reset();
												Ext.getCmp('username').focus();
											});
										}
										else
										{
										   Ext.Msg.alert('error','Failed to connect to sever', function(){
                                            basic.reset();
											Ext.getCmp('username').focus();
											});
										}
          
                                    }
                                });
                            }
                        }
                    }
				],
				buttonAlign : 'center',
                listeners: {
                    afterRender: function(thisForm, options){
                        this.keyNav = Ext.create('Ext.util.KeyNav', this.el, {
                            enter: function(){
                                var btn = Ext.getCmp('loginbtn');
                                btn.handler();
                            },
                            scope: this
                        });
                    }
                }
            }).show();
 
        });
    </script>

</head>
<body>


</body>
</html>