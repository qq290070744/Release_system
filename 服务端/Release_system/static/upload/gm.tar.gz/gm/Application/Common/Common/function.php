<?php
use Home\Controller\PublicController;
use Think\Log;

// +----------------------------------------------------------------------------
// | 描述：公共函数库
// +----------------------------------------------------------------------------
// | 作者：度月飞天 490702087@qq.com
// +----------------------------------------------------------------------------
// | 版权：Copyright (c) 2015 www.keebin.cn All rights reserved.
// +----------------------------------------------------------------------------
// | 日期：2015-2-10 下午8:34:20
// +----------------------------------------------------------------------------

/**
 * 检测用户是否登录
 * @return integer 0-未登录，大于0-当前登录用户ID
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function is_login(){
	$user = session('user_auth');
	if (empty($user)) {
		return 0;
	} else {
		return session('user_auth_sign') == data_auth_sign($user) ? $user['uid'] : 0;
	}
}

/**
 * 数据签名认证
 * @param  array  $data 被认证的数据
 * @return string       签名
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function data_auth_sign($data) {
	//数据类型检测
	if(!is_array($data)){
		$data = (array)$data;
	}
	ksort($data); //排序
	$code = http_build_query($data); //url编码并生成query字符串
	$sign = sha1($code); //生成签名
	return $sign;
}

/**
 * 检测当前用户是否为管理员
 * @return boolean true-管理员，false-非管理员
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function is_administrator($uid = null){
	$uid = is_null($uid) ? is_login() : $uid;
	return $uid && (intval($uid) === C('USER_ADMINISTRATOR'));
}

/**
 * 调用系统的API接口方法（静态方法）
 * api('User/getName','id=5'); 调用公共模块的User接口的getName方法
 * api('Admin/User/getName','id=5');  调用Admin模块的User接口
 * @param  string  $name 格式 [模块名]/接口名/方法名
 * @param  array|string  $vars 参数
 */
function api($name,$vars=array()){
	$array     = explode('/',$name);
	$method    = array_pop($array);
	$classname = array_pop($array);
	$module    = $array? array_pop($array) : 'Common';
	$callback  = $module.'\\Api\\'.$classname.'Api::'.$method;
	if(is_string($vars)) {
		parse_str($vars,$vars);
	}
	return call_user_func_array($callback,$vars);
}


/**
 * 发送HTTP请求方法
 * @param  string $url    请求URL  定义一个要发送的目标URL
 * @param  array  $params 请求参数  定义传递的参数数组；
 * @param  string $method 请求方法GET/POST
 * @return array  $data   响应数据
 */
function http($url, $params, $method = 'GET', $header = array()){
	Log::record('url:'.$url,'DEBUG');
	Log::record('params:'.implode(',',$params),'DEBUG');
	Log::record('method:'.$method,'DEBUG');
	Log::record('header:'.implode(',',$header),'DEBUG');
    $opts = array(
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER     => $header,
    );

    /* 根据请求类型设置特定参数 */
    switch(strtoupper($method)){
        case 'GET':
            $opts[CURLOPT_URL] = $url. '?GM' . http_build_query($params);
            break;
        case 'POST':
            $opts[CURLOPT_URL] = $url.'?GM';
            $opts[CURLOPT_POST] = 1;
            $opts[CURLOPT_POSTFIELDS] = http_build_query($params);
            break;
        default:
            throw new Exception('不支持的请求方式！');
    }

    /* 初始化并执行curl请求 */
    $ch = curl_init();
	curl_setopt($ch,CURLOPT_FAILONERROR,true);
    curl_setopt_array($ch, $opts);
    $data  = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    if($error) {
		$b['errorMessage'] = $error;
		$b['success'] = 'false';
		//throw new Exception('请求发生错误：' . $error);
	}
	else{
		$b = (array)json_decode($data,true);
	}
    return  $b;
}


//二维维数组转字符串
function rebuild_array($arr){  //rebuild a array
	$temp = '';
	foreach($arr as $key=>$value){//$key对应记录的条数
		if(($key != '_id') && ($key != 'roleid')&&($key != 'time'))
		{
			if(is_array($value)){
				$temp = $temp.'['.$key.']';
			foreach($value as $k=>$v){//$k对应字段名称
					$temp = $temp.'('.$k.':'.$v.')';
				}
				$temp = $temp.',';
			}
			else{
				$temp = $temp.'['.$key.']'.$value.',';
			}
		}	
	}
	
	return $temp;
}


/** 
 * @desc  im:获取指定月的第一天
 * @param (date)$date 指定的月份 
 * return 返回：指定月份的第一天
*/  
function getCurMonthFirstDay($date) {
    return date('Y-m-01', strtotime($date));
}

/** 
 * @desc  im:获取指定月的最后一天
 * @param (date)$date 指定的月份 
 * return 返回：指定月份的最后一天
*/  
function getCurMonthLastDay($date) {
    return date('Y-m-d', strtotime(date('Y-m-01', strtotime($date)) . ' +1 month -1 day'));
}

/**
*判断当前时区是否是夏令时
*/
function isDst()
{
	//获取当前使用的时区
	$timezone = date('e');
	//强制设置时区US/Pacific-New
	date_default_timezone_set('America/New_York');
	//判断是否夏令时
	$dst = date('I');
	//还原时区
	date_default_timezone_set($timezone);
	return $dst;
}


/** 
 * @desc  im:十进制数转换成三十六机制数 
 * @param (int)$num 十进制数 
 * return 返回：三十六进制数 
*/  
function get_char($num) {  
    $num = intval($num);  
    if ($num <= 0)  
        return false;  
    $charArr = array("0","1","2","3","4","5","6","7","8","9",'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');  
    $char = '';  
    do {  
        $key = ($num - 1) % 36;  
        $char= $charArr[$key] . $char;  
        $num = floor(($num - $key) / 36);  
    } while ($num > 0);  
    return $char;  
}  
  
/** 
 * @desc  im:三十六进制数转换成十机制数 
 * @param (string)$char 三十六进制数 
 * return 返回：十进制数 
 */  
function get_num($char){  
    $array=array("0","1","2","3","4","5","6","7","8","9","A", "B", "C", "D","E", "F", "G", "H", "I", "J", "K", "L","M", "N", "O","P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y","Z");  
    $len=strlen($char);  
    for($i=0;$i<$len;$i++){  
        $index=array_search($char[$i],$array);  
        $sum+=($index+1)*pow(36,$len-$i-1);  
    }  
    return $sum;  
}  


//生成激活码
function get_code($type,$index){	
	$first_rand = rand(8, 281);		
	$end_rand = rand(1, 99);	
    $index_num = strval($index);            //strval  本函数可将数组及类之外的变量类型转换成字符串类型
	$index_str = sprintf('%07s',$index_num);
	$type_str = strval($type);
	$num = strval($first_rand).$type_str.$index_str.strval($end_rand);	
	$temp = base_convert($num, 10, 36);   //10进制的$num转换36进制$temp
	$temp = strtoupper($temp);	          //strtoupper  把字符串转换为大写
	return $temp;
}

function get_redeem($type,$index){	
	$first_rand = rand(8, 281);		
	$end_rand = rand(1, 99);	
	$ends = rand(222,999);
    $index_num = strval($index);
	$index_str = sprintf('%07s',$index_num);
	$type_str = strval($type);
	$num = strval($first_rand).$type_str.$index_str.strval($end_rand);	
	$temp = base_convert($num, 10, 36);
	$temp = strtoupper($temp).$ends;	
	return $temp;
}

/*function get_redeem($type,$index){	
	$first_rand = rand(1, 99);	
	$end_rand = rand(8, 281);	
	$num = $first_rand * 100000000 + $index * 1000 + $end_rand;
	
	$temp = get_char($num);
	
	return $temp;
}
/*
function get_code($type,$index){
	$temp = '';
	
	$str = dechex(time());
	$in = dechex($index);
	
	$size = 16 - strlen($type);
	
	$size = $size - strlen($str);
	
	$size = $size - 4;
			
	$rand = dechex(rand(1,1000));
	$temp = $type.$str; 
	
	$size = $size - strlen($rand);
	
	for($i = 0 ;$i < $size;$i++)
	{
		$temp = $temp.'0';
	}
		
	$temp = $temp.$rand;
	
	$size2 =  4 - strlen($in);
	for($i = 0 ;$i < $size2;$i++)
	{
		$temp = $temp.'0';
	}
	
	$temp = $temp.$in;
	
	return $temp;
}*/
