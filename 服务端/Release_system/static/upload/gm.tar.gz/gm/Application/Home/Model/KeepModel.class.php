<?php

namespace Home\Model;
use Think\Model\MongoModel;
class KeepModel extends MongoModel {
	//protected $pk               =   'id';
	//protected $dbName = 'mongodb';
}