<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;


//UI上  数据统计  数据统计 留存统计 等级分布统计
//用户管理工具 玩家操作日志  用户信息查询 日志查询 

//group 最大数量20000条 要改成mapreduce
//[['登陆用户统计','1'],['在线人数统计','2'],['新增用户统计','3']]
//修改日志  增加配置属性 group改为aggregate 
//增加log字段对应转说明

//主要是统计管理的    UI上    数据统计 相关
class StatisController extends Controller {
	
	//利用 thinkphp 多语言 对 log 里面字段进行翻译 显示说明
	public function Logrebuild_array($arr,$dbname){  //rebuild a array
		$temp = '';
		foreach($arr as $key=>$value){//$key对应记录的条数
			if(($key != $dbname.'_oper')&&($key != '_id') && ($key != 'roleid')&&($key != 'time')&&($key != 'channel_id'))
			{
				$keyname = 'log_'.$dbname.'_value_'.$key;
				$temp = $temp.L($keyname);
				
				if(is_array($value)){
					$temp = $temp.'(';
					foreach($value as $k=>$v){//$k对应字段名称
						$item_key_name = 'log_res_value_'.$k;
						$temp = $temp.L($item_key_name).':'.$v.',';
					}
					$temp = $temp.')';
					$temp = $temp.',';					
				}
				else{
					$temp = $temp.'('.$value.'),';
				}
			}
		}
	
		return $temp;
	}

	
	//获取login日志
    public function getPlayerLoginLog($date){
		
		$data['data'] = array();
		
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
		
		for ($i=0; $start->sec <= $etime; $i++) {
			
			$start = new \MongoDate($stime +($i)*60*60*24);
			$end = new \MongoDate($stime +($i+1)*60*60*24-1);
			//$start = $stime +($i)*60*60*24;
			//$end = $stime +($i+1)*60*60*24-1;
			
			if( $start->sec >= $etime)
			{
				break;
			}
			
			$time = array('$gt' => $start, '$lte' => $end);

			$serverdata = S('SERVER_CONFIG_DATA');
			$num = 0;

			foreach ($serverdata AS $value)
			{
				if(I('serverid') == 0 || I('serverid') == $value['id'])
				{
					
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);
		
					$model=new MongoModel($value['logname'].'.login','log_',$connection);
					
					$model->getCollection()->createIndex(array('time' => 1,'login_oper'=>1));
					
					//$key    = array('roleid'=>1);
					//$init   = array('num'=>0);
					//$reduce = "function(obj, prev){prev.num++;}";
					$where = array(
						'time' => $time,
						'login_oper' => array('$in'=>array('login','logout')),
					);
					
					if(I('channelid') != -1)
					{
						$where['channel_id'] = intval(I('channelid'));
					}
				
				
					//$result = $model->where($where)->group($key, $init, $reduce);
				
					//$num = $num + $result['keys']->value;
					
					
					//echo $this->ajaxReturn($result);
								
					$cond = array(  
						array(  
							'$match' => $where,
							),  
						array(  
							'$group' => array(  
								'_id' => '$roleid',
							),  
						), 
						array(  
							'$group' => array(  
								'_id' => 'null',
								'num'=> array('$sum'=>1),
							),  
						), 
					); 
				
					$result = $model->getCollection()->aggregate($cond);
					
					$num = $num + $result['result'][0]['num'];
					
				}
				
			}
			
			$proname = date('Y-m-d', $start->sec);
			$listdata = array(
				'proname'=>$proname,
				'num'=>$num,
			);
			
			array_push($data['data'],$listdata);
		}
		
		$data['success']=true;
		
		echo $this->ajaxReturn($data);
    }
	
    //获取在线日志
	public function getPlayerOnlineLog($date){
		$data['data'] = array();
		$listdata = array();
		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
		
		$time = array('$gt' => $start, '$lte' => $end);
		
		$serverdata = S('SERVER_CONFIG_DATA');

		foreach ($serverdata AS $value)
		{										
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);
				
				$model=new MongoModel($value['logname'].'.online_num','log_',$connection);
				
				$model->getCollection()->createIndex(array('time' => 1,'channel_id'=>1));
				
				$where = array(
					'time' => $time,
					'channel_id' => intval(I('channelid')),
				);
				
				$result = $model->where($where)->select(array('order' => array("time" => 1)));
				
				foreach ($result AS $key)
				{
					$proname = $key['time']->sec;
					if(array_key_exists($proname,$listdata))
					{
						$listdata[$proname]['num'] = $listdata[$proname]['num']+$key['number'];
					}
					else{
						$listdata[$proname] = array(
								'proname'=>date('Y-m-d H:i:s', $proname),
								'num'=>$key['number'],
						);
					}
				}
			}
		}

		
		$i = 0;
		foreach ($listdata AS $key)
		{	
			$data['data'][$i] = $key;
			$i++;
		}	
		
		$data['success']=true;
		
		echo $this->ajaxReturn($data);

    }
	
    
    //获取新增用户日志
	public function getPlayerNewLog($date){
		$data['data'] = array();
		
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
			
		for ($i=0; $start->sec <= $etime; $i++) 
		{			
			//$start =$stime +($i)*60*60*24;
			//$end = $stime +($i+1)*60*60*24-1;	

			$start = new \MongoDate($stime +($i)*60*60*24);
			$end = new \MongoDate($stime +($i+1)*60*60*24-1);
			
			if( $start->sec >= $etime)
			{
				break;
			}				
			
			$time = array('$gt' => $start, '$lte' => $end);
			
			$serverdata = S('SERVER_CONFIG_DATA');
			$num = 0;
			foreach ($serverdata AS $value)
			{
				if(I('serverid') == 0 || I('serverid') == $value['id'])
				{
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);
		
					$model=new MongoModel($value['logname'].'.login','log_',$connection);
					
					$model->getCollection()->createIndex(array('time' => 1,'login_oper'=>1));
					
					$where = array(
						'time' => $time,
						'login_oper' => 'register',
					);
				
					if(I('channelid') != -1)
					{
						$where['channel_id'] = intval(I('channelid'));
					}
					
					ini_set('mongo.long_as_object', 0);
					
					$num = $num + $model->where($where)->count();
				
				}
			}
			
			$proname = date('Y-m-d', $start->sec);
			$listdata = array(
				'proname'=>$proname,'num'=>$num,
			);
			
			array_push($data['data'],$listdata);		
		}
			
		$data['success']=true;
		
		echo $this->ajaxReturn($data);
    }
	
    
    //统一的接口 
	public function getInfo(){
		
		if(I('searchtype') == 1)
		{
			$this->getPlayerLoginLog($time);
		}
		else if(I('searchtype') == 2)
		{
			$this->getPlayerOnlineLog($time);
		}
		else if(I('searchtype') == 3)
		{
			$this->getPlayerNewLog($time);
		}
    }
	
	
    //及时 获取留存数据 现在不使用了
	public function getPlayerkeepLog(){
		
		$data['data'] = array();
		
		$stime = strtotime(I('startdate'));
		$etime = strtotime(I('enddate')) - 1;
		
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
		
		$time = array('$gt' => $start, '$lte' => $end);

		$serverdata = S('SERVER_CONFIG_DATA');
			
		$listdata = array();
			
		foreach ($serverdata AS $value)
		{
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{			
				$map = "
					function() {
						emit(this.roleid,{oper_:this.login_oper,time_:this.time,register_time:0,createrole_time:0,login_time:[]});
					} 
				"; 
				$reduce = "
					function(key, values){ 
						var ret = {register_time:0,createrole_time:0,login_time:[],register:0,twoday:0,threeday:0,sevenday:0,thirtyday:0};
						values.forEach(function(val) {
							var time = val.time_/1000 - (val.time_/1000 + 8*60*60)%86400 - 8*60*60;
							if(typeof val.oper_=='undefined')
							{
								if(val.register_time != 0)
								{
									ret.register_time = val.register_time;
								}
								if(val.createrole_time != 0)
								{
									ret.createrole_time = val.createrole_time;
								}
								val.login_time.forEach(function(val2) {
									ret.login_time.push(val2);
								});	
							}
							else{
								if(val.oper_ == 'register') 
								{
									ret.register_time = time;
									val.register_time = ret.register_time;
								
								}else if(val.oper_ == 'create_role') {
									ret.createrole_time = time;
									val.createrole_time = ret.createrole_time;
								}
								else{
									ret.login_time.push(time);
								}
							}
						});

						return ret;
					}
				";
				
				$finalize = "
					function Finalize(key, reduced)
					{	
						if(reduced.register_time != 0)
						{
							reduced.register = 1;
							reduced.login_time.forEach(function(val){
								var day = (val - reduced.register_time)/86400;
								
								if(day >= 29 && day < 30)
									reduced.thirtyday = 1;
								else if(day >= 6 && day < 7)
									reduced.sevenday = 1;
								else if(day >= 2 && day < 3)
									reduced.threeday = 1;
								else if(day >= 1 && day < 2)
									reduced.twoday = 1;
							});
						}

						return reduced;
					}
				";
					
				$where = array(
					'time' => $time,
					'login_oper' => array('$in'=>array('login','logout','create_role','register')),
				);
				
				if($value['loguser'] != '')
				{
					$host = 'mongodb://'.$value['logpass'].':'.$value['loguser'].'@'.$value['logip'].':'.$value['logport'].'/';
				}
				else{
					$host = 'mongodb://'.$value['logip'].':'.$value['logport'].'/';
				}
				
				$mongo = new \MongoClient($host);
				$instance = $mongo->selectDB($value['logname']);
				
				$result2 = $instance->command(array(
						'mapreduce' => 'log_login',
						'map'       => $map,
						'reduce'    => $reduce,
						'query'	=> $where,
						'finalize' =>$finalize,
						'out' => 'log_keep_temp',
						
				));
				//echo $this->ajaxReturn($result2);		
			
				$tempdb = $instance->selectCollection("log_keep_temp");
				
				$cond = array(  
					array(  
						'$match' => array(
							'value.register' => array('$gt'=> 0 ),
						)),  
					array(  
						'$group' => array(  
							'_id' => '$value.register_time',
							'register'=> array('$sum'=>'$value.register'),
							'twoday'=> array('$sum'=>'$value.twoday'),
							'threeday'=> array('$sum'=>'$value.threeday'), 
							'sevenday'=> array('$sum'=>'$value.sevenday'), 
							'thirtyday'=> array('$sum'=>'$value.thirtyday'), 
						),  
					),  
				); 

				$results = $tempdb->aggregate($cond);
				
				foreach ($results['result'] AS $value)
				{
					$proname = date('Y-m-d', $value['_id']+8*60*60);
					if(!array_key_exists($proname,$listdata))
						$listdata[$proname] = $value;
						
					$listdata[$proname]['date'] = $proname;	
				}
					
				//echo $this->ajaxReturn($results);
			}
		}
		
		$i = 0;
		$listend = 0;
		for ($i=0; $etime >= $listend; $i++) 
		{			
			$liststart =$stime +($i)*60*60*24;
			$listend = $stime +($i+1)*60*60*24;	
			
			$proname = date('Y-m-d', $liststart);
			
			if(array_key_exists($proname,$listdata))
			{
				$data['data'][$i] = $listdata[$proname];
			}
			else
			{
				$data['data'][$i] = array(
					'date' => $proname,
					'register' => 0,
					'twoday' => 0,
					'threeday' => 0,
					'sevenday' => 0,
					'thirtyday' => 0,		
				);
			}
		}


		$data['success']=true;
		
		echo $this->ajaxReturn($data);

    }
	
    
    //等级分布统计
	public function getPlayerLevelLog(){
		
		$data['data'] = array();
		
		$stime = strtotime(I('startdate'));
		$etime = strtotime(I('enddate')-1);

		
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
			
		$time = array('$gt' => $start, '$lte' => $end);
		
		$serverdata = S('SERVER_CONFIG_DATA');
			
		$listdata = array();
		//$listdata[0] = 0;
		//$listdata[1] = 0;
		$total = 0;
		foreach ($serverdata AS $value)
		{
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);

				$model=new MongoModel($value['logname'].'.role','log_',$connection);
					
				//$key    = array('roleid'=>1);
				//$init   = array('lv'=>0);
				//$reduce = "function(obj, prev){ 
				//if(obj.level > prev.lv) 
				//{ 
				//	prev.lv = obj.level;
				//} }";
					
				//$where = array(
				//	'time' => $time,
				//	'role_oper' => 'addExp',
				//);
							
				//$result = $model->where($where)->group($key, $init, $reduce);
				
				$cond = array(  
					array(  
						'$match' => array(
								'time' => $time,
								'role_oper' => 'addExp'
						)),  
					array(  
						'$group' => array( 
							'_id' => '$roleid',
							'lv'=> array('$max'=>'$level'),   						
						)
					),
					array(  
						'$group' => array( 
							'_id' => '$lv',
							'num'=> array('$sum'=>1),   						
						)
					),						
				); 
				
				$result = $model->getCollection()->aggregate($cond);
				
				foreach ($result['result'] AS $value)
				{
					$proname = $value['_id'];
					if(!array_key_exists($proname,$listdata))
					{
						$listdata[$proname] = 0;
					}
												
					$listdata[$proname] = $listdata[$proname]+$value['num'];
					$total = $total + $value['num'];
				}
												
				//$model2=new MongoModel($value['logname'].'.keep_temp','log_',$connection);
				//if($model2 != null)
				//{
				//	$where = array(
				//		'value.createrole_time'=>0.0,
				//	);
				//	$num = $model2->where($where)->count();

				//	$where2 = array(
				//		'value.createrole_time'=>array('$ne'=>0),
				//		'value.login_time.2' => array('$exists'=>0),
				//	);
					//$where3 = array(
					//	'value.createrole_time'=>array('$ne'=>0),
					//	'value.login_time' => array('$size'=>2),
					//);
				//	$num2 = $model2->where($where2)->count();
					//$num3 = $model2->where($where3)->count();
					
				//	$listdata[0]= $listdata[0]+$num;
				//	$listdata[1]= $listdata[1]+$num2;// + $num3;

					//echo $this->ajaxReturn($num);
				//}
				
				//echo $this->ajaxReturn($result);
				
			}
		}
		
		$i = 0;
		foreach ($listdata AS $key=>$value)
		{
			$data['data'][$i]['level'] =  $key;
			$data['data'][$i]['num'] =  $value;	
			$i++;			
		}
		
		$totlar['level'] = 'all';
		$totlar['num'] = $total;
		
		array_push($data['data'],$totlar);	
		

		$data['success']=true;
		
		echo $this->ajaxReturn($data);

    }
	
	
    //获取玩家操作日志
	public function getAllPlayerLog(){
		
		$data['data'] = array();
		$data['success']=false;
		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
			
		$time = array('$gt' => $start, '$lte' => $end);// 大于:$gt 小于等于:$lte
		
		
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);
		
	
		$model=new MongoModel( $value['logname'].'.'.I('logtype'),'log_',$connection);
			
		$where = array(
			'time' => $time,
		);
		
		if (I('roleid') != "")
		{
			$where['roleid'] = I('roleid');
		} 
		
		if(I('logcomm') != "0")
		{
			$where[I('logtype').'_oper'] = I('logcomm');
		}
		ini_set('mongo.long_as_object', 1);
		$result = $model->where($where)->limit(I('start').','.I('limit'))->select();
				
		$data['totalCount']=$model->where($where)->count();
		ini_set('mongo.long_as_object', 0);
		$i = 0;
		foreach ($result AS $key)
		{	
			$listdata["roleid"] = $key["roleid"];
			$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);
			$listdata["serverid"] = $key["group_id"];
			
			$keyvalue_ = I('logtype').'_oper';
			if (array_key_exists($keyvalue_,$key))
			{
				$keyname = 'log_oper_'.$key[$keyvalue_];
				$listdata["oper"] = L($keyname);
				$listdata["text"] = $this->Logrebuild_array($key,I('logtype'));
			}
			else{
				$listdata["oper"] = "";
				$listdata["text"] = rebuild_array($key);
			}
			 
			$data['data'][$i] = $listdata;
					
			$i++;
		}	
				
		$data['success']=true;

		echo $this->ajaxReturn($data);

    }
	
	
    //获取单一玩家日志
	public function getPlayerLog(){	
		
		$data['data'] = array();
		$result = array();
		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
			
		$time = array('$gt' => $start, '$lte' => $end);
			
		$serverdata = S('SERVER_CONFIG_DATA');										
		$value = $serverdata[I('serverid')];
		
		$roleid = I('roleid');
		
		$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['loguser'],
			'db_pwd'   => $value['logpass'],
			'db_host'  => $value['logip'],
			'db_port'  => $value['logport'],
		);
		
		$model=new MongoModel($value['logname'].'.'.I('logtype'),'log_',$connection);
			
		$where = array(
			'roleid' => $roleid,
			'time' => $time,
		);
		
		if(I('logcomm') != "0")
		{
			$where[I('logtype').'_oper'] = I('logcomm');
		}
			
		$data['totalCount']=$model->where($where)->count();
		
		ini_set('mongo.long_as_object', 1);
		
		$result = $model->where($where)->limit(I('start').','.I('limit'))->select();		
		$i = 0;
		foreach ($result AS $key)
		{	
			$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);
			
			$keyvalue_ = I('logtype').'_oper';
			if (array_key_exists($keyvalue_,$key))
			{
				$keyname = 'log_oper_'.$key[$keyvalue_];
				$listdata["oper"] = L($keyname);	
				$listdata["text"] = $this->Logrebuild_array($key,I('logtype'));
			}
			else{
				$listdata["oper"] = "";
				$listdata["text"] = rebuild_array($key);
			}
			
	 
			$data['data'][$i] = $listdata;
					
			$i++;
		}	
	
		$data['success']=true;
		
		echo $this->ajaxReturn($data);
		

    }


}