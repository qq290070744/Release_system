<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
use Think\Log;

//UI 邮件推送 群体邮件 直接管理 toolsdb 下 systemmail


class MailController extends Controller {
	public function Mailbuild_array($array){
		$temp = "";
		foreach($array as $u){//$k对应字段名称
			if(is_array($u)){
				$temp = $temp.'(';
				foreach($u as $k=>$v){//$k对应字段名称
					$temp = $temp.$k.':'.$v.',';
				}
				$temp = $temp.')';
			}
			else{
				$temp = $temp.'('.$value['user'].')';
			}
		}
		
		return $temp;
	}
   
	public function getInfo(){	

		$itmezone = date_default_timezone_get();
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
			
			ini_set('mongo.long_as_object', 1);
		
			$model=new MongoModel($value['toolsname'].'.systemmail',null,$connection);
				
			$field = array('user'=>false);
			$options = array('where'=>array(),'field'=>$field, 'order'=>array('time'=>-1));
			$cursor = $model->limit(I('start').','.I('limit'))->select($options);
			
			$data['totalCount']=$model->count();
			
			foreach ($cursor AS $key=>$value)
			{
				$tempvalue = $value;
				
				$start_time = $value['start_time'];
	    		$end_time = $value['end_time'];
	    		if($itmezone == 'EST')
	    		{
		    		if(isDst())
		    		{
		    			Log::record('isDst'.$start_time,'DEBUG');	
		    			Log::record('isDst'.$end_time,'DEBUG');
		    			$start_time -= 3600;
		    			$end_time -= 3600;
		    		}
	    		}

				$tempvalue['start_time'] = date('Y-m-d H:i:s', $start_time);
				$tempvalue['end_time'] = date('Y-m-d H:i:s', $end_time);
				
				$temp = $this->Mailbuild_array($value['user']);
				
				$tempvalue['user'] = $temp; 
				
				$temp = $this->Mailbuild_array($value['items']);
				
				$tempvalue['items'] = $temp;
				
				$data['data'][] = $tempvalue;
			}	
		
			$data['success']=true;
			
			ini_set('mongo.long_as_object', 0);
		}
		
		
		echo $this->ajaxReturn($data);
    }
	
	public function delInfo(){
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);
	
		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = intval($temp['id']);
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
		
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
		$model=new MongoModel($value['toolsname'].'.systemmail',null,$connection);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		echo $this->ajaxReturn($data);
    }

	public function editInfo(){
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		$where = array(
			'id'=>intval($datajson['id'])
		);
		
		echo $this->ajaxReturn($data);
    }
    
    //发送全体邮件
    public function addAllPlayerMail(){

    	$itmezone = date_default_timezone_get();
    	$serverdata = S('SERVER_CONFIG_DATA');
    	$value = $serverdata[I('serverid')];
    
    	if($value == null)
    	{
    		$httpstr['success'] = false;
    		$httpstr['errorMessage'] = L('error_server');
    	}
    	else{
    		$connection = array(
    				'db_type'  => 'mongo',
    				'db_user'  => $value['toolsuser'],
    				'db_pwd'   => $value['toolspass'],
    				'db_host'  => $value['toolsip'],
    				'db_port'  => $value['toolsport'],
    		);
    
    		$model=new MongoModel($value['toolsname'].'.systemmail',null,$connection);
    
    		//暂时用来取最大的id数+1
    		$cond = array(
    				array(
    						'$group' => array(
    								'_id'=>null,
    								'index'=> array('$max'=>'$id'),
    						)
    				),
    		);
    
    		$result = $model->getCollection()->aggregate($cond);
    
    		$index = $result['result'][0]['index'];
    
    		$postdata = I('post.items');
    
    		$postdata = str_ireplace('&quot;','"',$postdata);
    			
    		$jsonitems = json_decode($postdata);
    			
    		$items = array();
    			
    		foreach ($jsonitems AS $value)
    		{
    			$temp = array();
    
    			$temp['type'] = intval($value->type);
    			$temp['itemid'] = intval($value->itemid);
    			$temp['quality'] = intval($value->quality);
    			$temp['itemnum'] = intval($value->itemnum);
    			$temp['level'] = intval($value->level);
    
    			$items[] = $temp;
    		}
    			
    		$start_time = strtotime(I('post.start_time'));
    		$end_time = strtotime(I('post.end_time'));
    		if($itmezone == 'EST')
    		{
	    		if(isDst())
	    		{
	    			Log::record('isDst'.$start_time,'DEBUG');	
	    			Log::record('isDst'.$end_time,'DEBUG');
	    			$start_time += 3600;
	    			$end_time += 3600;
	    		}
    		}
    
    		$data = array(
    				'id' => $index+1,
    				'text' =>I('post.text'),
    				'name'=>I('post.name'),
    				'title'=>I('post.title'),
    				'items'=>$items,
    				'start_time' =>$start_time,
    				'end_time' =>$end_time,
    				'time'=>new \MongoDate(),
    		);
    		ini_set('mongo.native_long', 0);
    		$result = $model->add($data);
    
    		//LOG记录
    		D('Gmlog')->GmAddLog('SendAllPlayerMail',json_encode($data));
    	}
    
    	 
    	 
    	 
    	$datas['success']=true;
    	echo $this->ajaxReturn($datas);
    }
}