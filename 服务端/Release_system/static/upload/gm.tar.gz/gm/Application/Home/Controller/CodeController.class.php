<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
use Think\Csv;
use Think\Log;


//兑换码生成相关
//

class CodeController extends Controller {
	
	
    public function getCode(){
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
			
			ini_set('mongo.long_as_object', 1);
		
			$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
				
			$where = array(
				'user.0' => array('$exists'=>(int)I('codeuse')),
			);
			
			if(I('codetype') != 0)
			{
				$where['redeemid'] = intval(I('codetype'));
			}

			if(I('platformid') != 0)
			{
				$where['platformid'] = intval(I('platformid'));
				$model->getCollection()->createIndex(array('platformid' => 1));
			}			

			$model->getCollection()->createIndex(array('user.roleid' => 1,'redeemid' => 1));
			
			$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();
			
			$data['totalCount']=$model->where($where)->count();
			
			foreach ($cursor AS $key=>$value)
			{
				$tempvalue = $value;
				$temp = "";
				foreach($value['user'] as $u){//$k对应字段名称
					if(is_array($u)){
						$temp = $temp.'(';
						foreach($u as $k=>$v){//$k对应字段名称
							$temp = $temp.$k.':'.$v.',';
						}
						$temp = $temp.')';
					}
					else{
						$temp = $temp.'('.$value['user'].')';
					}
				}
				if (is_object($value['type']))
					$tempvalue['type'] = $value['type']->value;
				if (is_object($value['redeemid']))
					$tempvalue['redeemid'] = $value['redeemid']->value;
				
				$tempvalue['user'] = $temp; 
				
				$data['data'][] = $tempvalue;
			}	
		
			$data['success']=true;
			
			ini_set('mongo.long_as_object', 0);
		}
		
		echo $this->ajaxReturn($data);
    }
	
	public function exportCode(){
		$data = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
			echo $this->ajaxReturn($data);
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
			$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
				
			$where = array(
				'user.0' => array('$exists'=>(int)I('codeuse')),
			);
			//var_dump($where);
			if(I('codetype') != 0)
			{
				$where['redeemid'] = intval(I('codetype'));
			}

			if(I('platformid') != 0)
			{
				$where['platformid'] = intval(I('platformid'));	
			}
			
			ini_set('mongo.long_as_object', 0);
			
			$model->getCollection()->createIndex(array('user.roleid' => 1,'redeemid' => 1));
			
			$cursor = $model->field('id,type,redeemid,isrepeat,platformid')->where($where)->select();
			
			//echo $model->_sql();
			$csv_title = array('_id',L('csv_title_code'),L('csv_title_codetype'),L('csv_title_redeemid'),L('csv_title_isrepeat'),L('csv_title_platformid'));
				
		
			//$file = iconv('utf-8','gb2312',"激活码");
			//$filename = $file.date('Ymd').'.csv';
			//export_csv($filename,$str);
			//echo $model->_sql();
		//	
			$csv=new Csv();
			$csv->put_csv($cursor,$csv_title);
		}
	}
    public function addCode(){
		
		$num = I('post.codenum')+1;
		$platformid = I('post.platformid');
								
		$code = array();
		
		$i = 1;
		while($i < $num)
		{
			$data = array(				
				'id' => get_code(I('post.redeemid'),$i, $platformid),
				'type' =>intval(I('post.codetype')),
				'redeemid' =>intval(I('post.redeemid')),
				'isrepeat' =>(bool)I('post.codeisrepeat'),
				'platformid' =>intval($platformid),
				'time'=>new \MongoDate(),
			);
				
			$code[] = $data;
			$i++;
		}
		
		
		$serverdata = S('SERVER_CONFIG_DATA');
		ini_set('mongo.native_long', 0);
			
		foreach ($serverdata AS $value)
		{
			if(I('post.serverid') == 0 || I('post.serverid') == $value['id'])
			{
				$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['toolsuser'],
						'db_pwd'   => $value['toolspass'],
						'db_host'  => $value['toolsip'],
						'db_port'  => $value['toolsport'],
				);
		
				$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
					
				try 
				{
					foreach ($code AS $key)
					{
						$result = $model->getCollection()->insert($key);
					}
					
				} catch (MongoException $e) {					
					Log::record('用户数据错误');
				}
			}
		}
		
		$res['success']='true';
		echo $this->ajaxReturn($res);
    }
	
	public function delCode(){	
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);
	
		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = $temp['id'];
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
		
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
		$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		echo $this->ajaxReturn($data);
    }

    


    public function getCodeTotalPay(){
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
		}
		else
		{
			//$code_list = this->getCodeList(I('platformid'));		
			$data['totalCount']=$code_list['totalCount'];
			foreach ($cursor AS $key=>$value)
			{				
				$data['data'][] = $tempvalue;
			}	
		
			$data['success']=true;
			
			ini_set('mongo.long_as_object', 0);
		}
		
		
		echo $this->ajaxReturn($data);
    }

    function _get($str){ 
		$val = !empty($_GET[$str]) ? $_GET[$str] : null; 
		return $val; 
	} 

    public function addCodeTotalPay(){		
		$platformid = I('post.platformid');
		$channelid = I('post.channelid');
		$createdate = I('post.createdate');
		$serverid = I('post.serverid');
		$endtime = I('post.endtime');

		$serverdata = S('SERVER_CONFIG_DATA');

		Log::record('createdate'.$createdate,'DEBUG');	
		Log::record('end_time'.$end_time,'DEBUG');

		foreach ($serverdata AS $value)
		{			
			$roledata = $this->getCodeRoleList($value, $platformid);
			$chargedata = $this->getCodeChargeInfo($serverdata, $createdate, $channelid, $serverid, $roledata);

			if(count($chargedata) == 0)
			{
				$res['err'] = L('error_nodata');
				$res['success']=false;
				echo $this->ajaxReturn($res);
			}
			else
			{
				$res['success']=true;
				$res['data'] = $chargedata;
				echo $this->ajaxReturn($res);

			}
			
		}			
			
		$res['success']=true;
		
		
		echo $this->ajaxReturn($res);
    }
	
	public function getCodeRoleList($sconfig, $iplatformid){	
		$rolelist = array();


		ini_set('mongo.long_as_object', 1);
		

		$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $sconfig['toolsuser'],
			'db_pwd'   => $sconfig['toolspass'],
			'db_host'  => $sconfig['toolsip'],
			'db_port'  => $sconfig['toolsport'],
			);
		
		
	
		$model=new MongoModel($sconfig['toolsname'].'.exchangecode',null,$connection);		

		$where = array('user'=> array('$exists' => 1));
		$where['platformid'] = intval(I('platformid'));
		$model->getCollection()->createIndex(array('platformid' => 1));		
		$field = array('user'=>true);
		$options = array('where'=>$where,'field'=>$field);

		$cursor = $model->limit(I('start').','.I('limit'))->select($options);
		
		//$data['totalCount']=$model->where($where)->count();
		
		if(is_array($cursor))
		{
			foreach ($cursor AS $key=>$value)
			{
				$tempvalue = $value;
				$temp = "";
				foreach($value['user'] as $u){//$k对应字段名称
					if(is_array($u)){
						//$temp = $temp.'(';
						foreach($u as $k=>$v){//$k对应字段名称
							$temp = $temp.$k.':'.$v.',';
						}
						//$temp = $temp.')';
					}
					else{
						$temp = $temp.$value['user'];
					}
				}						

				$roleid = new \MongoInt64($temp);
				//array_push($v,$roleid);
				$rolelist[] = $roleid;
			}			
		}
		
		ini_set('mongo.long_as_object', 0);

		//$data['roleList'] = $rolelist;
		//return $data;
		return $rolelist;
	}

	public function getCodeChargeInfo($sconfig, $cdate, $channelid, $serverid, $roledata){
    	
    	$listdata = array();

    	
    	$stime = getCurMonthFirstDay($cdate);
		$etime = getCurMonthLastDay($cdate);	
		$start = new \MongoDate(strtotime($stime));
		$end = new \MongoDate(strtotime($etime));
	
		$time = array('$gt' => $start, '$lte' => $end);

		Log::record('start time'.$stime,'DEBUG');

		Log::record('end time'.$etime,'DEBUG');

		ini_set('mongo.long_as_object', 1);
		foreach ($sconfig AS $value)
		{
			if($serverid == 0 || $serverid == $value['id'])
			{
				$data_temp = array();
		    	$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
				);
				
				
			
				$model=new MongoModel($value['logname'].'.role','log_',$connection);
				
				
				$where = array(
					'roleid'=>array('$in'=>array_values($roledata)),	
					'time' => $time,
					'role_oper'=>'ChargeDiamond',
				);
					
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$channel_id',
										'number'=> array('$sum'=> '$diamond' ),
								),
						),
				);
					
				$result = $model->getCollection()->aggregate($cond);
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
							
						$data_temp[$index]['charge_diamond'] = $resvalue['number'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['charge_diamond'] = $resvalue['number'];
					}
				
					$allchannel['charge_diamond'] += $resvalue['number'];
				}
					
				foreach ($data_temp AS $value)
				{
					array_push($listdata,$value);
				}
				
				
			}
		}

		ini_set('mongo.long_as_object', 0);
		return $listdata;
    }

}