<?php
namespace Home\Controller;
use Think\Controller;

class ProController extends AuthController {
    public function mylist(){
    	$this->display();
    }
}