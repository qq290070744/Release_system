<?php
namespace Home\Controller;
use Think\Model\MongoModel;
use Think\Controller;
use Think\Csv;

class PlayerLogController extends Controller {
	  //利用 thinkphp 多语言 对 log 里面字段进行翻译 显示说明
	  	public function Logrebuild_array($arr,$dbname){  //rebuild a array
		$temp = '';
		foreach($arr as $key=>$value){//$key对应记录的条数
			if(($key != $dbname.'_oper')&&($key != '_id') && ($key != 'roleid')&&($key != 'time'))
			{
				$keyname = 'log_'.$dbname.'_value_'.$key;
				$temp = $temp.L($keyname);
				
				if(is_array($value)){
					$temp = $temp.'(';
					foreach($value as $k=>$v){//$k对应字段名称
						$item_key_name = 'log_res_value_'.$k;
						$temp = $temp.L($item_key_name).':'.$v.',';
					}
					$temp = $temp.')';
					$temp = $temp.',';					
				}
				else{
					$temp = $temp.'('.$value.'),';
				}
			}
		}
	
		return $temp;
	}
	
	  public function addplayerlog(){
		$data['data'] = array();
		$data['success']=false;
		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
			echo $this->ajaxReturn($end);
		$time = array('$gt' => $start, '$lte' => $end);// 大于:$gt 小于等于:$lte
		
		
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		
					$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
					);
		$model=new MongoModel( $value['logname'].'.'.I('logtype'),'log_',$connection);
		$where = array(
			'time' => $time,
		);
		echo $this->ajaxReturn($where);
		if (I('roleid') != "")
		{
			$where['roleid'] = new \MongoInt64 (I('roleid'));
		} 
		if(I('logcomm') != "0")
		{
			$where[I('logtype').'_oper'] = I('logcomm');
		}
		ini_set('mongo.long_as_object', 1);
		
		$result = $model->where($where)->select();
		
		$data['totalCount']=$model->where($where)->count();
		
		ini_set('mongo.long_as_object', 0);
		$i = 0;
		foreach ($result AS $key)
		{	
			if (array_key_exists("roleid", $key))
				$listdata["roleid"] = $key["roleid"]->value;
			if (array_key_exists("group_id", $key))
				$listdata["serverid"] = $key["group_id"]->value;
			$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);
			
			
			$keyvalue_ = I('logtype').'_oper';
			if (array_key_exists($keyvalue_,$key))
			{
				$keyname = 'log_oper_'.$key[$keyvalue_];
				$listdata["oper"] = L($keyname);
				$listdata["text"] = $this->Logrebuild_array($key,I('logtype'));
			}
			else{
				$listdata["oper"] = "";
				$listdata["text"] = rebuild_array($key);
			}
			 
			$data['data'][$i] = $listdata;
					
			$i++;
		}	
				
		//$data['success']=true;

	//	echo $this->ajaxReturn($result);
		//	$csv_title = array('_id',L('csv_title_oper'),L('csv_title_roleid'),L('csv_title_time'),L('csv_title_serverid'),L('csv_title_text'));
				
		//$csv=new Csv();
		//	$csv->put_csv($result,$csv_title);
	  }
	  public function exportCode(){
		$data = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
			echo $this->ajaxReturn($data);
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
			$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
				
			$where = array(
				'user.0' => array('$exists'=>(int)I('codeuse')),
			);
			//var_dump($where);
			if(I('codetype') != 0)
			{
				$where['redeemid'] = intval(I('codetype'));
			}

			if(I('platformid') != 0)
			{
				$where['platformid'] = intval(I('platformid'));	
			}
			
			ini_set('mongo.long_as_object', 0);
			
			$model->getCollection()->createIndex(array('user.roleid' => 1,'redeemid' => 1));
			
			$cursor = $model->field('id,type,redeemid,isrepeat,platformid')->where($where)->select();
			//var_dump($cursor);	
			//echo $model->_sql();
			$csv_title = array('_id',L('csv_title_code'),L('csv_title_codetype'),L('csv_title_redeemid'),L('csv_title_isrepeat'),L('csv_title_platformid'));
				
		
			//$file = iconv('utf-8','gb2312',"激活码");
			//$filename = $file.date('Ymd').'.csv';
			//export_csv($filename,$str);
			//echo $model->_sql();
		//	die;
			$csv=new Csv();
			$csv->put_csv($cursor,$csv_title);
		}
	}
	  
}