<?php

namespace Home\Model;
use Think\Model\MongoModel;
class DailyModel extends MongoModel {
	//protected $pk               =   'id';
}