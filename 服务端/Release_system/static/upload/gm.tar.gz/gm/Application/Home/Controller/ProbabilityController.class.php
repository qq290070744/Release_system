<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;

class ProbabilityController extends Controller{
	 public function addProbability(){
		 $this->display(edit);
	 }
	// function transform(){
	//	 var arr = [];
	//	 for(var items in obj){
	//		 arr.push(obj[items]);
	//	 }
	//	 return arr;
//	 }
	   public function addAllProbability(){
		   
		$postdata = I('post.items');
       // var_dump($postdata);die;
		$postdata = str_ireplace('&quot;','"',$postdata);
		
		$serverdata = S('SERVER_CONFIG_DATA');
		$value = $serverdata[I('serverid')];
			
		if($value == null)
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_server');
		}
		else{
			$url = $value['severip'].":".$value['severport'];
			$data['fun']="AddProbability";//SendPlayerList
			//定义传递的参数数组
			//$data['serverid'] => I('post.serverid'),
			//$data['items'] => $postdata,
			//$data['lastday'] => I('post.lastday'),
			$data['id'] = I('post.serverid');
			$data['lastday'] = I('post.lastday');
			$data['items'] = $postdata;
		//	$this->transform('items');
			$httpstr = http($url, $data,'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
			
			//LOG记录
			D('Gmlog')->GmAddLog('addAllProbability',json_encode($data));
		}
			
		echo $this->ajaxReturn($httpstr);
    }
	
}