<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;


//UI上  数据统计 消费排行统计
//这是及时 查询 玩家消费排行的数据
//暂时只是能统计  货币 和游戏充值
//消费类型 分的太散的 还没想到好办法
//考虑到数据量 只显示 前500

class RankController extends Controller {	
	public function getInfo(){
			
		if(I('ranktype') == 'playercost')
		{
			$this->getplayercost();
		}
		else if(I('ranktype') == 'playerpay')
		{
			$this->getplayerpay();
		}
		else if(I('ranktype') == 'cost')
		{
			$this->getCostType();
		}
    }
	
	
	public function getplayercost(){
		
		$stime = strtotime(I('startdate'));
		$etime = strtotime(I('enddate')) - 1;
		
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
		
		$time = array('$gt' => $start, '$lte' => $end);
		
		$data['data'] = array();
		
		$serverdata = S('SERVER_CONFIG_DATA');
		
		$value = $serverdata[I('serverid')];
		if ($value == null)
		{
			$data['success']=false;
		}
		else {
			$data['success']=true;
			$data['totalCount']=500;
			
			$listdata = array();
			$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $value['loguser'],
					'db_pwd'   => $value['logpass'],
					'db_host'  => $value['logip'],
					'db_port'  => $value['logport'],
				);

			$model=new MongoModel($value['logname'].'.role','log_',$connection);
			
			$numstr;
			
			$match = array(
				'time' => $time,
				'role_oper' => I('rankcoin'),
			);
			
			if(I('rankcoin') == 'ChangeMoney')
			{
				$numstr = 'money';
			}
			else if(I('rankcoin') == 'ChangeDiamond')
			{
				$numstr = 'diamond';
			}
			else {
				$numstr ='num';
			}
			
			$match[$numstr] = array('$lt'=>0);
			
			$cond = array(  
				array(  
					'$match' => $match,					
				),  
				array(  
					'$group' => array( 
						'_id' => '$roleid',
						'num'=> array('$sum'=>'$'.$numstr),   						
					)
				),
				array(  
					'$sort' => array( 'num' => 1),
				),
				array(
					'$skip'=>intval(I('start')),
				),
				array(
					'$limit'=>intval(I('limit')),
				),

			); 
			ini_set('mongo.long_as_object', 1);
			
			 $result= $model->getCollection()->aggregate($cond);
			foreach ($result['result'] AS $value)
			{
				//$proname = $value;
				$proname['_id'] = $value['_id'];
				if($value['num']->value == 0){
					$proname['num'] = $value['num'];
				}
				else{
					$proname['num'] = $value['num']->value;
				}
							
				$data['data'][]=$proname;
			}
			
		}
		
		echo $this->ajaxReturn($data);

    }
    
    public function getplayerpay()
    {
    	$stime = strtotime(I('startdate'));
    	$etime = strtotime(I('enddate')) - 1;
    	
    	$start = new \MongoDate($stime);
    	$end = new \MongoDate($etime);
    	
    	$time = array('$gt' => $start, '$lte' => $end);
    	
    	$data['data'] = array();

    	$data['success']=true;
    	$data['totalCount']=500;
    			
    	$listdata = array();
    	$paydb = S('OTHERSERVER_CONFIG_DATA');
		$connection = array(
				'db_type'  => 'mongo',
				'db_user'  => $paydb['paydbuser'],
				'db_pwd'   => $paydb['paydbpass'],
				'db_host'  => $paydb['paydbip'],
				'db_port'  =>$paydb['paydbport'],
		);
		
		$model=new MongoModel( $paydb['paydbname'].'.prepaid_order_result','log_',$connection);
    	   			
    	$match = array(
    			'time' => $time,
    			'group'=>intval(I('serverid')),
    			'detail'=>'check_pass',
    	);
    			  			
    	$cond = array(
    			array(
    					'$match' => $match,
    			),
    			array(
    					'$group' => array(
    							'_id' => '$role_id',
    							'num'=> array('$sum'=>'$rmb'),
    					)
    				),
    				array(
    						'$sort' => array( 'num' => -1),
    				),
    				array(
    						'$skip'=>intval(I('start')),
    				),
    				array(
    						'$limit'=>intval(I('limit')),
    				),
    	
    		);
    		ini_set('mongo.long_as_object', 1);
    			
    		$result = $model->getCollection()->aggregate($cond);
    			
    		foreach ($result['result'] AS $value)
    		{
    			//$proname = $value;
    			$proname['_id'] = $value['_id'];
    			if($value['num']->value == 0){
    				$proname['num'] = $value['num'];
    			}
    			else{
    				$proname['num'] = $value['num']->value;
    			}
    				
    			$data['data'][]=$proname;
    		}
    	
    	echo $this->ajaxReturn($data);
    }
}