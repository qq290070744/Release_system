<?php
namespace Home\Controller;
use Think\Controller;


//菜单
class MenuController extends Controller {
	//菜单列表
	public  function menuList(){	
		//数据库读取权限设置
		$data = array();
		//根据权限设置生成菜单列表
		$user = session('user_auth');
		$object = $user['auth'];
		$user_auth = explode(',',$object);
		$data["success"]=true;
	   for($i=0,$size=count($user_auth);$i<$size;++$i){
		$c = $user_auth[$i];
	        switch($c){
				case 1:$data["menus"][]=array(			
							 array(
							 'title'=>'服务器管理','name'=>'servermanager','xtype'=>'treepanel','rootVisible'=>false,'margin'=>0,'iconCls'=>'Bulletwrench','store'=>'admin.store.menu.Config'),
							 );continue;
					case 2:$data["menus"][]= array(			
								array('title'=>'数据统计', 'name'=>'data_staticstic', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Serverchart', 'store'=>'admin.store.menu.Inquiry'),
						);continue;
						case 3:$data["menus"][]=array(			
									array('title'=>'用户管理', 'name'=>'users_manage', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Folderuser', 'store'=>'admin.store.menu.Player'),
							);continue;
							case 4:$data["menus"][]=array(			
									  array('title'=>'公告管理', 'name'=>'announcement', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Note', 'store'=>'admin.store.menu.Notice'),
								); continue;
								case 5:$data["menus"][]=array(			
											array('title'=>'充值管理', 'name'=>'charge_manage', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Databaseedit', 'store'=>'admin.store.menu.Distribute'),
									);continue;
										case 6:$data["menus"][]=array(			
													array('title'=>'活动管理', 'name'=>'activity', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Note', 'store'=>'admin.store.menu.Activity'),
											);continue;
					case 7:$data["menus"][]=array(			
							array('title'=>'礼包管理', 'name'=>'redeem_function', 'xtype'=>'treepanel', 'rootVisible'=>false, 'margin'=>0, 'iconCls'=>'Note', 'store'=>'admin.store.menu.Redeems')
					);
			}continue;
		}
		$newArr = array();
		 foreach($data['menus'] as $key=>$val){
			  foreach($val as $k=>$v){
			   $newArr['menus'][] = $v;
			   $newArr['success']=$data["success"];
		 }
            }
		//	print_r($newArr);die;
		echo $this->ajaxReturn($newArr);
	}

	//服务器管理
	public function config(){
		$data["children"]=array(
			array('text'=>L('menu_gmlog'),'leaf'=>true,'xtypeClass'=>'GmLogList'),
			array('text'=>L('menu_user'),'leaf'=>true,'xtypeClass'=>'userList'),
			array('text'=>L('menu_server'),'leaf'=>true,'xtypeClass'=>'ServerList'),
		);
		echo $this->ajaxReturn($data);
	}
	
	
	//数据统计
	public function inquiry(){
		$data["children"]=array(
				array('text'=>L('menu_statis'),'leaf'=>true,'xtypeClass'=>'statisList'),
				array('text'=>L('menu_keep'),'leaf'=>true,'xtypeClass'=>'keepList'),
				array('text'=>L('menu_level'),'leaf'=>true,'xtypeClass'=>'levelList'),
				array('text'=>L('menu_daily'),'leaf'=>true,'xtypeClass'=>'dailyList'),
				//array('text'=>L('menu_rank'),'leaf'=>true,'xtypeClass'=>'rankList'),
				

		);
		echo $this->ajaxReturn($data);
	}
	
	//用户管理工具 //邮件管理
	public function player(){
		$data["children"]=array(
				array('text'=>L('menu_playerLog'),'leaf'=>true,'xtypeClass'=>'playerLog'),
				array('text'=>L('menu_playerinfo'),'leaf'=>true,'xtypeClass'=>'playerInfo'),
				array('text'=>L('menu_playerRes'),'leaf'=>true,'xtypeClass'=>'playerRes'),
				array('text'=>L('menu_limitList'),'leaf'=>true,'xtypeClass'=>'limitList'),
				//array('text'=>'用户反馈','leaf'=>true,'xtypeClass'=>''),
		);
		echo $this->ajaxReturn($data);
	}
	
	//公告管理
	public function notice(){
		$data["children"]=array(
				array('text'=>L('menu_scrollbar'),'leaf'=>true,'xtypeClass'=>'scrollbarList'),
				array('text'=>L('menu_notice'),'leaf'=>true,'xtypeClass'=>'noticeList'),
				//array('text'=>L('menu_activitybar'),'leaf'=>true,'xtypeClass'=>'activityList'),
			//	array('text'=>'在线GM','leaf'=>true,'xtypeClass'=>''),
		);
		echo $this->ajaxReturn($data);
	}
	
	//激活码管理
	public function code(){
		$data["children"]=array(
				array('text'=>L('menu_codecreate'),'leaf'=>true,'xtypeClass'=>'codeList'),
				array('text'=>L('menu_code_totalpay'),'leaf'=>true,'xtypeClass'=>'codetotalpayList'),
			//	array('text'=>L('menu_activity'),'leaf'=>true,'xtypeClass'=>'activityInfo'),
			//	array('text'=>L('menu_exchangecode'),'leaf'=>true,'xtypeClass'=>''),
				
		);
		echo $this->ajaxReturn($data);
	}
	
	//充值管理
	public function distribute(){
		$data["children"]=array(
				array('text'=>L('menu_charge'),'leaf'=>true,'xtypeClass'=>'chargeList'),
				array('text'=>L('menu_chargelog'),'leaf'=>true,'xtypeClass'=>'chargeLog'),
		);
		echo $this->ajaxReturn($data);
	}
	
	//活动管理
	public function activity(){
		$data["children"]=array(
				array('text'=>L('menu_probability'),'leaf'=>true,'xtypeClass'=>'probabilityList'),
			//	array('text'=>L('menu_chargelog'),'leaf'=>true,'xtypeClass'=>'chargeLog'),
		);
		echo $this->ajaxReturn($data);
	}
	//礼包功能
		public function redeems(){
		$data["children"]=array(
				array('text'=>L('menu_addredeem'),'leaf'=>true,'xtypeClass'=>'redeemList'),
		);
		echo $this->ajaxReturn($data);
	}
}