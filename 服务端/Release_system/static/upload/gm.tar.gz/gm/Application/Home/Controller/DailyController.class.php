<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
use Think\Csv;

//ini_set('mongo.long_as_object', 1);

//日报分析
//先创建日报 读取的都是之前创建的
//gmdb gm_dail
//字段说明  id 自增  date 数据时间  channel_id 登陆平台  serverid 服务器组id oper 日报类型
//login 登陆用户 register 注册用户  charge 充值用户  rmb 充值总数  online 在线人数最高  online 最高在线人数时段  charge_diamond 总充值钻石 consumption_diamond 总消耗钻石
//
class DailyController extends Controller {
	
	public function clearDaily()
	{
		$daily=D('Daily');

		$where = array(
			"oper"=>I('type'),
		);
		
		if(I('serverid') != 0)
		{
			$where['serverid'] = intval(I('serverid'));
		}
		
		ini_set('mongo.long_as_object', 0);
		
		$daily->where($where)->delete();
		
		$data['success']=true;
		
		echo $this->ajaxReturn($data);
	}
	
	//获取日报
	public function getDaily()
	{
		$data['data'] = array();
		
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
		
		$time = array('$gte' => $start, '$lte' => $end);
		$where = array(
			'time'=>$time,
			'oper'=>I('type'),
			'channel_id'=>intval(I('channelid')),
		);
		
		$daily=D('Daily');
		
		ini_set('mongo.long_as_object', 0);
		
		//if(I('serverid') == 0)
		//{
		//	$cond = array(
		//			array(
		//					'$match' => $where,
		//			),
		//			array(
		//					'$sort' => array('online'=> -1),
		//			),
		//			array(
		//					'$group' => array(
		//							'_id'=>'$date',
		//							'login'=> array('$sum'=>'$login'),
		//							'register'=> array('$sum'=>'$register'),
		//							'charge'=> array('$sum'=>'$charge'),
		//							'rmb'=> array('$sum'=>'$rmb'),
		//							'online'=> array('$first'=>'$online'),
		//							'online_time'=> array('$first'=>'$online_time'),
		//							'charge_diamond'=> array('$sum'=>'$charge_diamond'),
		//							'consumption_diamond'=> array('$sum'=>'$consumption_diamond'),
		//					)
		//			),
		//			array(
		//					'$limit'=>intval(I('limit')),
		//			),
		//			array(
		//					'$skip'=>intval(I('start')),
		//			)					
		//	);
			
		//	$result = $daily->getCollection()->aggregate($cond);
			
		//	foreach ($result['result'] AS $value)
		//	{
		//		$temp = $value;
		//		$temp['date'] = $value['_id'];
				
		//		$data['totalCount'] = $daily->where($where)->count();
				
		//		array_push($data['data'],$temp);
		//	}
		//}
		//else 
		//{
			if(I('serverid') != 0){
				$where['serverid'] = intval(I('serverid'));
			}
			
			$daily->getCollection()->createIndex(array('channel_id' => 1,'oper' => 1));
				
			$data['totalCount']=$daily->where($where)->count();
			
			$cursor = $daily->where($where)->limit(I('start').','.I('limit'))->select();
			
			foreach ($cursor AS $key=>$value)
			{
				array_push($data['data'],$value);
			}
			$data['success']=true;
		//}
			
		
		
		echo $this->ajaxReturn($data);
	}
	
	//日报生成 每天生成一份
	public function createDaily()
	{
		$data['data'] = array();
		$data['success']=false;
		
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
		
		if ($stime == 0 || $etime == 0)
		{
			$data['err'] = L('error_nodate');
			$data['success']=false;
			echo $this->ajaxReturn($data);
		}
			
		for ($i=0; $start <= $etime; $i++)
		{
			$start = $stime +($i)*60*60*24;
			$end = $stime +($i+1)*60*60*24-1;
			
			if( $start >= $etime)
			{
				break;
			}
			
							
			$datalist = $this->GetReportForm($start,$end,I('serverid'));
			
			if(count($datalist) == 0)
			{
				$data['err'] = L('error_nodata');
				$data['success']=false;
				echo $this->ajaxReturn($data);
			}
			
			$daily =D('Daily');
			
			
			foreach ($datalist AS $value)
			{
				$where = array(
					'oper'=>'daily',
					'serverid'=>$value['serverid'],
					'channel_id'=>$value['channel_id'],
					'date'=>$value['date'],
					
				);
				
				$count = $daily->where($where)->count();
				if ($count == 0)
				{
					$value['oper'] = 'daily';
					$daily->add($value);
				}
				else 
				{
					$daily->where($where)->save($value);
				}
			}
			
			$data['success']=true;
			
		}
		
		
		echo $this->ajaxReturn($data);
	}
	
	//周期日报生成   这段时间内 生成一份
	public function createDately()
	{
		$data['data'] = array();
		$data['success']=false;
	
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
		
		if ($stime == 0 || $etime == 0)
		{
			$data['err'] = L('error_nodate');
			$data['success']=false;
			echo $this->ajaxReturn($data);
		}
			
		$datalist = $this->GetReportForm($stime,$etime,I('serverid'));
				
		if(count($datalist) == 0)
		{
			$data['err'] = L('error_nodata');
			$data['success']=false;
			echo $this->ajaxReturn($data);
		}
				
		$daily =D('Daily');
				
		foreach ($datalist AS $value)
		{
			$datestr= date('Y-m-d', $stime).'/'.date('Y-m-d', $etime);
			$value['date'] = $datestr;
			$where = array(
				'oper'=>'dately',
				'serverid'=>$value['serverid'],
				'channel_id'=>$value['channel_id'],
				'date'=>$value['date'],
			);
	
			$count = $daily->where($where)->count();
			if ($count == 0)
			{
				$value['oper'] = 'dately';
				$daily->add($value);
			}
			else
			{
				$daily->where($where)->save($value);
			}
		}
				
		$data['success']=true;

		echo $this->ajaxReturn($data);
	}
	
	
	public function exportDaily()
	{
		$data['data'] = array();
		
		$where = array(
			'oper'=>I('type'),
			'channel_id'=>intval(I('channelid')),
		);
		
		if(I('serverid') != 0)
		{
			$where['serverid'] = intval(I('serverid'));
		}
		
		//if(I('channelid') != -1)
		//{
		//	$where['channel_id'] = ;
		//}
		
		$daily=D('Daily');
		$field = array(
				'_id'=>false,
				'date'=>false,
				);
		$options = array('field'=>$field);
		$cursor = $daily->where($where)->select($options);//array('order' => array("oper"=> 1,"date" => 1))
		foreach ($cursor AS $value)
		{
			$proname = date('Y-m-d', $value['time']->sec);
			if(!array_key_exists($proname,$listdata))
			{
				$listdata[$proname] = $value;
				 $listdata[$proname]['time']=date('Y-m-d',$value['time']->sec);
			}
		}
		$csv_title = array(L('csv_title_date'),L('csv_title_channel_id'),L('csv_title_serverid'),L('csv_title_login'),L('csv_title_register')
				,L('csv_title_charge'),L('csv_title_rmb'),L('csv_title_online'),L('csv_title_online_time'),L('csv_title_charge_diamond')
				,L('csv_title_consumption_diamond'),L('csv_title_oper')
		);
		$csv=new Csv();
		$csv->put_csv($listdata,$csv_title);
		
	}
	
	//返回时间段内报表
	public function GetReportForm($start,$end,$serverid)
	{		
		$stime = $start;
		$etime = $end;
		//$stime = strtotime(I('startdate'));
		//$etime = strtotime(I('enddate')) - 1;
	
		$start = new \MongoDate($start);
		$end = new \MongoDate($end);
	
		$time = array('$gt' => $start, '$lte' => $end);
	
		$serverdata = S('SERVER_CONFIG_DATA');
			
		$listdata = array();
		
		
		foreach ($serverdata AS $value)
		{
			if($serverid == 0 || $serverid == $value['id'])
			{
				$data_temp = array();
					
				$ruledata = array(
						'date'=>date('Y-m-d', $stime),
						'time'=>new \MongoDate($stime),
						'channel_id'=>-1,
						'serverid'=>$value['id'],
						'login'=>0,
						'register'=>0,
						'charge'=>0,
						'rmb'=>0,
						'online'=>0,
						'online_time'=>0,
						'charge_diamond'=>0,
						'consumption_diamond'=>0,
							
				);
					
				$allchannel = $ruledata;
					
				$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['loguser'],
						'db_pwd'   => $value['logpass'],
						'db_host'  => $value['logip'],
						'db_port'  => $value['logport'],
				);
					
				//统计登陆人数
				$model=new MongoModel($value['logname'].'.login','log_',$connection);
					
				$where = array(
						'login_oper' => array('$in'=>array('login','logout')),
						'time' => $time,
				);
				
				$cond = array(
						array(
								'$match' => $where,
						),
				
						array(
								'$group' => array(
										'_id' => '$roleid',
										'channel'=>array('$first'=>'$channel_id')
								),
						),
						array(
								'$group' => array(
										'_id' => '$channel',
										'num'=> array('$sum'=>1),
								),
						),
				);
					
				$result = $model->getCollection()->aggregate($cond);
					
				
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
						$data_temp[$index]['login'] = $resvalue['num'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['login'] = $resvalue['num'];
					}
				
					$allchannel['login'] += $resvalue['num'];
				}
					
				//统计注册人数
				$where = array(
						'login_oper'=>'acc_register',
						'time' => $time,
				);
				
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$channel_id',
										'num'=> array('$sum'=>1),
								),
						),
				);
				
				$result = $model->getCollection()->aggregate($cond);
				
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
						$data_temp[$index]['register'] = $resvalue['num'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['register'] = $resvalue['num'];
					}
				
					$allchannel['register'] += $resvalue['num'];
				}
				
				$paydb = S('OTHERSERVER_CONFIG_DATA');
				
				$connection_pay = array(
						'db_type'  => 'mongo',
						'db_user'  => $paydb['paydbuser'],
						'db_pwd'   => $paydb['paydbpass'],
						'db_host'  => $paydb['paydbip'],
						'db_port'  =>$paydb['paydbport'],
				);
				
				//充值总金额   充值总人数
				$model=new MongoModel($paydb['paydbname'].'.prepaid_order_result','log_',$connection_pay);
				
				$where = array(
						'group'=>intval($value['id']),
						'time' => $time,
						'detail'=>'check_pass',
				);
				
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$role_id',
										'channel'=>array('$first'=>'$channel'),
										'user_rmb'=> array('$sum'=>'$rmb'),
								),
						),
						array(
								'$group' => array(
										'_id' => '$channel',
										'total'=> array('$sum'=>'$user_rmb'),
										'total_user'=> array('$sum'=> 1),
								),
						),
				);
				
				$result = $model->getCollection()->aggregate($cond);
				
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
						$data_temp[$index]['charge'] = $resvalue['total_user'];
						$data_temp[$index]['rmb'] = $resvalue['total'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['charge'] = $resvalue['total_user'];
						$data_temp[$index]['rmb'] = $resvalue['total'];
					}
				
					$allchannel['charge'] += $resvalue['total_user'];
					$allchannel['rmb'] += $resvalue['total'];
				}
				
				//新增充值用户数  	
				$where = array(
						'group'=>intval($value['id']),						
						'detail'=>'check_pass',
				);
				
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$role_id',
										'channel'=>array('$first'=>'$channel'),
										'time'=>array('$first'=>'$time'),
								),
						),
						array(
								'$match'=>array('time' => $time,)
						),
						array(
								'$group' => array(
										'_id' => '$channel',
										'total_user'=> array('$sum'=> 1),
								),
						),
				);
				
				$result = $model->getCollection()->aggregate($cond);
				
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
						$data_temp[$index]['new_charge'] = $resvalue['total_user'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['new_charge'] = $resvalue['total_user'];
					}
				
					$allchannel['new_charge'] += $resvalue['total_user'];
				}
					
					
				//最高在线人数 和时间段
				$model=new MongoModel($value['logname'].'.online_num','log_',$connection);
					
				$where = array(
						'time' => $time,
						//'channel_id'=>array('$ne'=>-1)
				);
					
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$sort' => array(
										'peak_number'=>-1,
								),
						),
						array(
								'$group' => array(
										'_id' => '$channel_id',
										'number'=> array('$first'=> '$peak_number' ),
										'time'=>array('$first'=>'$time'),
								),
						),
				);
					
				$result = $model->getCollection()->aggregate($cond);
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if ($index == -1)
					{
						$allchannel['online'] = $resvalue['number'];
						$allchannel['online_time'] = date('Y-m-d H:i:s', $resvalue['time']->sec);
					}
					else if(array_key_exists($index,$data_temp))
					{
						$data_temp[$index]['online'] = $resvalue['number'];
						$data_temp[$index]['online_time'] = date('Y-m-d H:i:s', $resvalue['time']->sec);
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['online'] = $resvalue['number'];
						$data_temp[$index]['online_time'] = date('Y-m-d H:i:s', $resvalue['time']->sec);
					}
				}
					
					
				//消费元宝
				$model=new MongoModel($value['logname'].'.role','log_',$connection);
				
				$where = array(
						'time' => $time,
						'role_oper'=>'ChangeDiamond',
						'diamond'=>array('$lt'=>0),
				);
				
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$channel_id',
										'number'=> array('$sum'=> '$diamond' ),
								),
						),
				);
				
				$result = $model->getCollection()->aggregate($cond);
				
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
				
						$data_temp[$index]['consumption_diamond'] = abs($resvalue['number']);
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['consumption_diamond'] = abs($resvalue['number']);
					}
				
					$allchannel['consumption_diamond'] += abs($resvalue['number']);
				}
					
				//充值元宝
				$where = array(
						'time' => $time,
						'role_oper'=>'ChargeDiamond',
				);
					
				$cond = array(
						array(
								'$match' => $where,
						),
						array(
								'$group' => array(
										'_id' => '$channel_id',
										'number'=> array('$sum'=> '$diamond' ),
								),
						),
				);
					
				$result = $model->getCollection()->aggregate($cond);
					
				foreach ($result['result'] AS $resvalue)
				{
					$index = $resvalue['_id'];
					if(array_key_exists($index,$data_temp))
					{
							
						$data_temp[$index]['charge_diamond'] = $resvalue['number'];
					}
					else {
						$data_temp[$index]=$ruledata;
						$data_temp[$index]['channel_id'] = $index;
						$data_temp[$index]['charge_diamond'] = $resvalue['number'];
					}
				
					$allchannel['charge_diamond'] += $resvalue['number'];
				}
					
				foreach ($data_temp AS $value)
				{
					array_push($listdata,$value);
				}
					
				array_push($listdata,$allchannel);
			}
			
		}
	
		return $listdata;
		
		//echo $this->ajaxReturn($listdata);
	}
	
	
}