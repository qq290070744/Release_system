<?php
return array(
	//'配置项'=>'配置值'
	'acc_ip'  => '192.168.3.242',
	'acc_port'  => 8888,
	'accountdb_ip'  => '192.168.3.242',
	'accountdb_port' => 27017,
	'accountdb_user' => '',
	'accountdb_pass' => '',
	'accountdb_name' => 'accountdb',
);