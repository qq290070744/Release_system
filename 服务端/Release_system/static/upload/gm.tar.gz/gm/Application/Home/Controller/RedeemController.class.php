<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
use Think\Log;
use Think\Csv;

class RedeemController extends AuthController {
	public function Itembuild_array($array){
		$temp = "";
		foreach($array as $u){//$k对应字段名称
			if(is_array($u)){
				$temp = $temp.'(';
				foreach($u as $k=>$v){//$k对应字段名称
					$temp = $temp.$k.':'.$v.',';
				}
				$temp = $temp.')';
			}
			else{
				$temp = $temp.'('.$value['user'].')';
			}
		}
		
		return $temp;
	}

    public function getAddredem(){
    	$this->display();
    }
	
	 public function addRedeem(){
		 
		 	$serverdata = S('SERVER_CONFIG_DATA');
		$value = $serverdata[I('serverid')];
		//var_dump($value);
		//die;
		$deadline = strtotime(I('post.deadline'));
		ini_set('mongo.native_long', 0);
			
		foreach ($serverdata AS $value)
		{
			if(I('post.serverid') == 0 || I('post.serverid') == $value['id'])
			{
				$connection = array(
						'db_type'  => 'mongo',
						'db_user'  => $value['toolsuser'],
						'db_pwd'   => $value['toolspass'],
						'db_host'  => $value['toolsip'],
						'db_port'  => $value['toolsport'],
				);
		
				$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
		
		$num = I('post.redeemcount')+1;
								
		$redeem = array();
		
		$postdata = I('post.itemsd');
    
    		$postdata = str_ireplace('&quot;','"',$postdata);
    			
    		$jsonitems = json_decode($postdata);
    			
    		$itemsd = array();
    			
    		foreach ($jsonitems AS $value)
    		{
    			$temp = array();
                $temp['type'] = intval($value->type);
    			$temp['itemid'] = intval($value->itemid);
    			$temp['quality'] = intval($value->quality);
    			$temp['itemnum'] = intval($value->itemnum);
    			$itemsd[] = $temp;
    		}
		
		$i = 1;
		while($i < $num)
		{
			$data = array(				
				'id' => get_redeem(I('post.redeemnameid'),$i, $platformid),
				'type' =>intval(I('post.redeemtype')),
				//'type' =>intval(I('post.codetype')),
				'redeemid' =>urldecode(I('post.redeemnameid')),
				'isrepeat' =>(bool)I('post.isrepeat'),
				'channelid' =>intval(I('post.channelid')),
				'items'=>$itemsd,
			//	'Items' =>intval(I('post.itemsd')),
		       //  'money' =>intval(I('post.goldcount')),
				// 'diamond' =>intval(I('post.syceecount')),
				//'channelid' =>intval($channelid),I('post.deadline')date('Y-m-d H:i:s',)
				 'deadline' =>$deadline,
				'time'=>new \MongoDate(),
			);
				
			$redeem[] = $data;
			$i++;
		}	
				try 
				{
					foreach ($redeem AS $key)
					{
						$result = $model->getCollection()->insert($key);
					}
					
				} catch (MongoException $e) {					
					Log::record('用户数据错误');
				}
			}
			}
				$res['success']='true';
		echo $this->ajaxReturn($res);
}

   public function getredeem(){
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
			
			ini_set('mongo.long_as_object', 1);
		
			$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
				
			$where = array(
				'user.0' => array('$exists'=>(int)I('redeemuse')),
			//	'id' => array('$exists'=>I('redeemids')),
			);
			
			if(I('id') != "")
			{
				$where['id'] =I('id');
			//	$model->getCollection()->createIndex(array('redeemids' => 1));
			}
            
			if(I('channelid') != 0)
			{
				$where['channelid'] = intval(I('channelid'));
				$model->getCollection()->createIndex(array('channelid' => 1));
			}			

			$model->getCollection()->createIndex(array('user.roleid' => 1,'id' => 1));
			
			$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();//
			
			$data['totalCount']=$model->where($where)->count();
			
			foreach ($cursor AS $key=>$value)
			{
				$tempvalue = $value;
				$temp = "";
				foreach($value['user'] as $u){//$k对应字段名称
					if(is_array($u)){
						$temp = $temp.'(';
						foreach($u as $k=>$v){//$k对应字段名称
							$temp = $temp.$k.':'.$v.',';
						}
						$temp = $temp.')';
					}
					else{
						$temp = $temp.'('.$value['user'].')';
					}
				}
				if (is_object($value['id']))
					$tempvalue['id'] = $value['id']->value;
				if (is_object($value['redeemid']))
					$tempvalue['redeemid'] = $value['redeemid']->value;
				if (is_object($value['deadline']))
					$tempvalue['deadline'] = $value['deadline']->value;
				$tempvalue['user'] = $temp; 								
				$tempvalue['items']=$this->Itembuild_array($value['items']);

				$data['data'][] = $tempvalue;
			}	
			$data['success']=true;
			
			ini_set('mongo.long_as_object', 0);
		}
		
		echo $this->ajaxReturn($data);
    }
public function delRedeem(){	
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);
	
		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = $temp['id'];
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
		
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
		$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		echo $this->ajaxReturn($data);
    }

    public function exportRedeem(){
		$data = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
			echo $this->ajaxReturn($data);
		}
		else
		{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
			$model=new MongoModel($value['toolsname'].'.exchangecode',null,$connection);
				
			$where = array(
				'user.0' => array('$exists'=>(int)I('redeemuse')),
			//	'id' => array('$exists'=>I('redeemids')),
			);
			
			if(I('id') != "")
			{
				$where['id'] =I('id');
			//	$model->getCollection()->createIndex(array('redeemids' => 1));
			}
           
			if(I('channelid') != 0)
			{
				$where['channelid'] = intval(I('channelid'));
				$model->getCollection()->createIndex(array('channelid' => 1));
			}			

			
			ini_set('mongo.long_as_object', 0);
			
			$model->getCollection()->createIndex(array('user.roleid' => 1,'id' => 1));
			
			$cursor = $model->field(array('_id'=>false,'id'=>true,'type'=>true,'redeemid'=>true,'isrepeat'=>true,'channelid'=>true,'deadline'=>true))->where($where)->select();
			//print_r($cursor);
			//echo $model->_sql();
			$csv_title = array(L('csv_title_code'),L('csv_title_codetype'),L('csv_title_redeemid'),L('csv_title_isrepeat'),L('csv_title_channelid'),L('csv_title_deadline'));
				
		
			//$file = iconv('utf-8','gb2312',"激活码");
			//$filename = $file.date('Ymd').'.csv';
			//export_csv($filename,$str);
			//echo $model->_sql();
			$csv=new Csv();
			$csv->put_csv($cursor,$csv_title);
		}
	}
}