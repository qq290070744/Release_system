<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;

class ActivityController extends Controller{
	
	
	public function getActivity(){
		$data['data'] = array();
		$serverdata = S('SERVER_CONFIG_DATA');
												
		//$value = $serverdata[I('serverid')];
        foreach ($serverdata AS $value)
		{
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
		$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
				
				$model=new MongoModel($value['toolsname'].'.activitynews',null,$connection);
					
		$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();
		
		$data['totalCount']=$model->where($where)->count();
		foreach ($cursor AS $key=>$cursorvalue)
		{
			$activity = $cursorvalue;
			//$activity['id'] = $cursorvalue['_id'];
			//$activity['nid'] = $cursorvalue['id'];
			$activity['serverid'] = $value['id'];
			
			
			array_push($data['data'],$activity);
		}
		$data['success']=true;
	}
		
		}
		echo $this->ajaxReturn($data);
	}
	
	
	public function AddActivity(){
		
		$serverdata = S('SERVER_CONFIG_DATA');
		foreach ($serverdata AS $value)
		{										
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
				
				$model=new MongoModel($value['toolsname'].'.activitynews',null,$connection);
				$cond = array(   
					array(  
						'$group' => array(
							'_id'=>null,
							'index'=> array('$max'=>'$id'),   						
						)
					),					
				); 
				$result = $model->getCollection()->aggregate($cond);
                $index = $result['result'][0]['index'];

				$data = array(
     			    'id' => $index+1,
					'type'=>I('post.news'),
					'title'=>I('post.title'),
					'name'=>I('post.name'),
					'msg' =>I('post.msg'),
					'time'=>new \MongoDate(),
				);

				$result = $model->add($data);
		$serverdata = S('SERVER_CONFIG_DATA');
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_server');
		}
		else{
			$url = $value['severip'].":".$value['severport'];
			$data['fun']="ActivityAnnouncement";
			$data['type'] = I('post.news');
			$data['title'] = I('post.title');
			$data['name'] = I('post.name');
			$data['msg'] = I('post.msg');
			$httpstr = http($url, $data,'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
			
			//LOG��¼
			D('Gmlog')->GmAddLog('AddActivity',json_encode($data));
		}	
       // $httpstr['success']='true';		
		//echo $this->ajaxReturn($httpstr);
	   }
	}
	    $res['success']='true';
		echo $this->ajaxReturn($res);
	}
	
	public function updateActivity(){
		$httpContent = file_get_contents('php://input', 'r');
		
		$datajson = (array)json_decode($httpContent);
		
	    $where = intval($datajson['id']);
       		
       $serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
	
		$activity = [];
		
		if(array_key_exists('type',$datajson))
		{
			$activity['type'] = $datajson['news'];
		}
		
		if(array_key_exists('title',$datajson))
		{
			$activity['title'] = $datajson['title'];
		}
		
		if(array_key_exists('name',$datajson))
		{
			$activity['name'] = $datajson['name'];
		}
		
		if(array_key_exists('msg',$datajson))
		{
			$activity['msg'] = $datajson['msg'];
		}
			
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
			
		$model=new MongoModel($value['toolsname'].'.activitynews',null,$connection);
		
		if($model->where($where)->save($activity))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		//$url = $value['severip'].":".$value['severport'];
		//$httpstr = http($url, $activity,'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
		D('Gmlog')->GmAddLog('updateScrollbarNotic',json_encode($notice));
		
		echo $this->ajaxReturn($data);
    }
	//��ɾ�����ݿ����ݣ�����Э�鵽������
	public function delActivity(){
		
		$httpContent=file_get_contents('php://input', 'r');
		
		$where=json_decode($httpContent);
	
	
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		$model=new MongoModel($value['toolsname'].'.activitynews',null,$connection);
		
		
		ini_set('mongo.long_as_object', 1);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		D('Gmlog')->GmAddLog('delActivity',json_encode($where));
		
		echo $this->ajaxReturn($data);
}
		}