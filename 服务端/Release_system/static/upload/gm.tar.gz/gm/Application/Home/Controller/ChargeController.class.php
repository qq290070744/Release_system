<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
ini_set('mongo.long_as_object', 1);


//充值log相关读取
class ChargeController extends Controller {
	
	public function getInfo(){	
		$data['data'] = array();
		$data['success']=false;
		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
			
		$time = array('$gt' => $start, '$lte' => $end);
		
		$paydb = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $paydb['paydbuser'],
					'db_pwd'   => $paydb['paydbpass'],
					'db_host'  => $paydb['paydbip'],
					'db_port'  =>$paydb['paydbport'],
		);
		
		$model=new MongoModel( $paydb['paydbname'].'.prepaid_order_result','log_',$connection);
		
		$model->getCollection()->createIndex(array('group' => 1,'time' => 1,'detail' => 1));
			
		$where = array(
			'group'=>intval(I('serverid')),
			'time' => $time,
			'detail'=>'check_pass',
		);
		
		if(I('channelid') != -1)
		{
			$where['channel'] = intval(I('channelid'));
		}
		
		if(I('roleid') != 0)
		{
			$where['role_id'] = new \MongoInt64(I('roleid'));
		}
							
		//$data['totalCount']=$model->where($where)->count();
				
		$cond = array(
			array(  
				'$match' => $where,
			), 
			array(
				'$group' => array(
					'_id'=>null,
					'index'=> array('$sum'=>'$rmb'),
					'count'=> array('$sum'=>1),
				)
			),					
		);
		
		ini_set('mongo.long_as_object', 1);
				
		$result = $model->getCollection()->aggregate($cond);
		
		$rmb = $result['result'][0]['index'];
		$data['totalCount'] = $result['result'][0]['count']->value;
		
		$data['data'][] =	array(
			'order_id'=>'all',
			'rmb' => round($rmb, 2),
		);
			
			
		$result = $model->where($where)->limit(I('start').','.I('limit'))->select();
		
		foreach ($result AS $key)
		{	
			$listdata = $key;
			$listdata["roleid"] = $key["role_id"]->value;
			$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);

			$data['data'][] = $listdata;
		}	
				
		$data['success']=true;

		echo $this->ajaxReturn($data);
    }
	
	
    public function getlogInfo(){
    	$data['data'] = array();
    	$data['success']=false;
    
		$paydb = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $paydb['paydbuser'],
					'db_pwd'   => $paydb['paydbpass'],
					'db_host'  => $paydb['paydbip'],
					'db_port'  =>$paydb['paydbport'],
		);
    
    	$model=new MongoModel( $paydb['paydbname'].'.prepaid_order_result','log_',$connection);
    	
    	$model->getCollection()->createIndex(array('roleid' => 1,'order_id' => 1));
    	
    	$where = array();
    
    	if(I('roleid') != "")
    	{
    		$where['role_id'] = new \MongoInt64(I('roleid'));
    	}
    	
    	if(I('orderid') != "")
    	{
    		$where['order_id'] = I('orderid');
    	}
    		
    	$data['totalCount']=$model->where($where)->count();
   
    	$result = $model->where($where)->limit(I('start').','.I('limit'))->select();
    	
    	foreach ($result AS $key)
    	{
    		$listdata = $key;
    		$listdata["roleid"] = $key["role_id"]->value;
    		$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);
    
    		$data['data'][] = $listdata;
    	}
    
    	$data['success']=true;
    
    	echo $this->ajaxReturn($data);
    }

    public function fillOrders(){

    	$data = array(
			'channel'=>I('post.channelid'),
			'order_id'=>I('post.order_id'),
			'roleid'=>I('post.roleid'),
			'group' => I('post.serverid'),
			'use'=>false,
			'product_id' => I('post.product_id'),
			'rmb' => I('post.rmb'),			
		);

		$paydb = S('OTHERSERVER_CONFIG_DATA');
    	$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $paydb['prepaiddbuser'],
					'db_pwd'   => $paydb['prepaiddbpass'],
					'db_host'  => $paydb['prepaiddbip'],
					'db_port'  =>$paydb['prepaiddbport'],
		);    
    	$model=new MongoModel( $paydb['prepaiddbname'].'.playerorder', null,$connection);
		$result = $model->add($data);	
				
		D('Gmlog')->GmAddLog('fillOrders',json_encode($data));

		$res['success']='true';
    	echo $this->ajaxReturn($res);
    }
}