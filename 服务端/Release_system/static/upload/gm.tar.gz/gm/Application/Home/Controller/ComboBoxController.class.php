<?php
namespace Home\Controller;
use Think\Controller;

class ComboBoxController extends Controller {
	
	//所有下拉框 相关都在这里
	
	//账号管理 区域
	public function getUserLevelComboBox(){
		
		$user = session('user_auth');
				
		if($user['area'] == 1)
		{
			$data = array(	
				array( 'name'=> L('userlevel_china'),'type'=>2),
				//array( 'name'=> L('userlevel_TW'),'type'=>3),
				//array( 'name'=> L('userlevel_VT'),'type'=>4),
			);
		}
		elseif($user['area'] == 2){
			$data = array(
				array( 'name'=> L('userlevel_china'),'type'=>2),
			);
		}
		elseif($user['area'] == 3){
			$data = array(
				array( 'name'=> L('userlevel_TW'),'type'=>3),
			);
		}
		elseif($user['area'] == 4){
			$data = array(
				array( 'name'=> L('userlevel_VT'),'type'=>4),
			);
		}
		else 
		{
			$data = array(
					array( 'name'=> L('userlevel_china'),'type'=>2),
					//array( 'name'=> L('userlevel_TW'),'type'=>3),
					//array( 'name'=> L('userlevel_VT'),'type'=>4),
			);
		}
			
		echo $this->ajaxReturn($data);
    }
	
	//带全服
	public function getAllSeverComboBox(){
		$serverdata = S('SERVER_CONFIG_DATA');
		$data =array();
		
		foreach ($serverdata AS $value)
		{
			array_push($data,$value);
		}
		
		if(count($data) <= 0)
		{
			echo $this->ajaxReturn($data);
		}
		
		array_unshift($data,array(
			'id'=>0,
			'name'=>L('common_allserver'),
		));
		
		echo $this->ajaxReturn($data);
    }
	
	public function getIdtypeComboBox(){
		$data = array(
		array( 'name'=> L('NAME'),'id'=>"name"),
        array( 'name'=> L('ACC_ID'),'id'=>"acc_id"),
		array( 'name'=> L('ROLE_ID'),'id'=>"role_id"),
		);
		echo $this->ajaxReturn($data);
	}
	
	//带不全服
	public function getSeverComboBox(){
		$serverdata = S('SERVER_CONFIG_DATA');
		
		$data =array();
		
		foreach ($serverdata AS $value)
		{
			array_push($data,$value);
		}
			
		echo $this->ajaxReturn($data);
    }
	
	//log服务器
	public function getLogComboBox(){
		$data = array(
		
		array( 'name'=> L('log_db_activity'),'id'=>"activity"),
		array( 'name'=> L('log_db_card'),'id'=>"card"),
		//array( 'name'=> L('log_db_rmg'),'id'=>"prepaid_order_result"),
		array( 'name'=> L('log_db_cleanout'),'id'=>"cleanout"),
		array( 'name'=> L('log_db_equip'),'id'=>"equip"),
		array( 'name'=> L('log_db_friend'),'id'=>"friend"),
		array( 'name'=> L('log_db_item'),'id'=>"item"),
		array( 'name'=> L('log_db_login'),'id'=>"login"),
		array( 'name'=> L('log_db_pvp'),'id'=>"pvp"),
		array( 'name'=> L('log_db_mail'),'id'=>"mail"),
		array( 'name'=> L('log_db_mission'),'id'=>"mission"),
		array( 'name'=> L('log_db_role'),'id'=>"role"),
		array( 'name'=> L('log_db_stage'),'id'=>"stage"),
		array( 'name'=> L('log_db_team'),'id'=>"team"),
		array( 'name'=> L('log_db_trader'),'id'=>"trader"),
		array( 'name'=> L('log_db_guild'),'id'=>"guild"),
				
		);
			
		echo $this->ajaxReturn($data);
    }
	
    //log 子操作
	public function getLogCommComboBox(){
		
		$type = I('type');
		
		$data = array();
		
		if($type == "activity")
		{
			$data = array(
				array( 'name'=> L('log_oper_lifelongcard_reward'),'id'=>"lifelongcard_reward"),
				array( 'name'=> L('log_oper_reward_time'),'id'=>"reward_time"),
				array( 'name'=> L('log_oper_upgrade_award'),'id'=>"upgrade_award"),
				array( 'name'=> L('log_oper_check_in'),'id'=>"check_in"),
				array( 'name'=> L('log_oper_check_in_day'),'id'=>"check_in_day"),
				array( 'name'=> L('log_oper_luxury_check_in_day'),'id'=>"luxury_check_in_day"),
				array( 'name'=> L('log_oper_reward_welfare_card'),'id'=>"reward_welfare_card"),
				array( 'name'=> L('log_oper_reward_ud'),'id'=>"reward_ud"),
				array( 'name'=> L('log_oper_reward_recharge'),'id'=>"reward_recharge"),
				array( 'name'=> L('log_oper_buy_monthcard'),'id'=>"buy_monthcard"),
				array( 'name'=> L('log_oper_reward_exchangecode'),'id'=>"reward_exchangecode"),
				array( 'name'=> L('log_oper_send_red_envelope'),'id'=>"send_red_envelope"),
				array( 'name'=> L('log_oper_send_rob_red_envelope'),'id'=>"send_rob_red_envelope"),
				array( 'name'=> L('log_oper_world_boss'),'id'=>"world_boss"),
					
			);
		}
		else if($type == "card")
		{
			$data = array(
				array( 'name'=> L("log_oper_del_card"),'id'=>"del_card"),
				array( 'name'=> L("log_oper_strength_card"),'id'=>"strength_card"),
				array( 'name'=> L("log_oper_get_new_card"),'id'=>"get_new_card"),
				array( 'name'=> L("log_oper_draw_card"),'id'=>"draw_card"),
				array( 'name'=> L("log_oper_compound_card"),'id'=>"compound_card"),
				array( 'name'=> L("log_oper_skill_upgrade"),'id'=>"skill_upgrade"),
				array( 'name'=> L("log_oper_sell_card"),'id'=>"sell_card"),
				array( 'name'=> L("log_oper_decompose_card"),'id'=>"decompose_card"),
				array( 'name'=> L("log_oper_skill_unlock"),'id'=>"skill_unlock"),
				array( 'name'=> L("log_oper_card_element_level_up"),'id'=>"card_element_level_up"),
				array( 'name'=> L("log_oper_card_element_change"),'id'=>"card_element_change"),
				array( 'name'=> L("log_oper_mix_card"),'id'=>"mix_card"),
				array( 'name'=> L("log_oper_evolution_card"),'id'=>"evolution_card"),
			);
		}
		else if($type == "prepaid_order_result")
		{
			//$data = array(
			//	array( 'name'=> "充值不用选",'id'=>""),
			//);
		}
		else if($type == "cleanout")
		{
			$data = array(
				array( 'name'=> L('log_oper_start_cleanout'),'id'=>"start_cleanout"),
				array( 'name'=> L('log_oper_end_cleanout'),'id'=>"end_cleanout"),
				array( 'name'=> L('log_oper_atonce_cleanout'),'id'=>"atonce_cleanout"),
			);
		}
		else if($type == "equip")
		{
			$data = array(
				array( 'name'=> L('log_oper_compound_equip'),'id'=>"compound_equip"),
				array( 'name'=> L('log_oper_sell_equip'),'id'=>"sell_equip"),
				array( 'name'=> L('log_oper_strength_equip'),'id'=>"strength_equip"),
				array( 'name'=> L('log_oper_decompose_equip'),'id'=>"decompose_equip"),
				array( 'name'=> L('log_oper_refine_equip'),'id'=>"refine_equip"),
				array( 'name'=> L('log_oper_refine_equip_result_save'),'id'=>"refine_equip_result_save"),
			);
		}
		else if($type == "friend")
		{
			$data = array(
				array( 'name'=> L('log_oper_add_friend'),'id'=>"add_friend"),
				array( 'name'=> L('log_oper_del_friend'),'id'=>"del_friend"),
				array( 'name'=> L('log_oper_hello_friend'),'id'=>"hello_friend"),
				array( 'name'=> L('log_oper_hellos_friend'),'id'=>"hellos_friend"),
				array( 'name'=> L('log_oper_invite_friend'),'id'=>"invite_friend"),
				array( 'name'=> L('log_oper_pk_friend'),'id'=>"pk_friend"),
			);
		}
		else if($type == "item")
		{
			$data = array(
				array( 'name'=> L('log_oper_add_item'),'id'=>"add_item"),
				array( 'name'=> L('log_oper_del_item'),'id'=>"del_item"),
				array( 'name'=> L('log_oper_sell_item'),'id'=>"sell_item"),
				array( 'name'=> L('log_oper_sell_item_num'),'id'=>"sell_item_num"),
				array( 'name'=> L('log_oper_use_item'),'id'=>"use_item"),
			);
		}
		else if($type == "login")
		{
			$data = array(
				array( 'name'=> L('log_oper_logout'),'id'=>"logout"),
				array( 'name'=> L('log_oper_create_role'),'id'=>"create_role"),
				array( 'name'=> L('log_oper_login'),'id'=>"login"),
				array( 'name'=> L('log_oper_register'),'id'=>"register"),
			//	array( 'name'=> L('log_oper_platform_login'),'id'=>"platform_login"),
					
			);
		}
		else if($type == "pvp")
		{
			$data = array(
				array( 'name'=> L('log_oper_pvp_attack'),'id'=>"pvp_attack"),
				array( 'name'=> L('log_oper_rank_change'),'id'=>"rank_change"),
				array( 'name'=> L('log_oper_friend_pk_result'),'id'=>"friend_pk_result"),
				array( 'name'=> L('log_oper_friend_pk_start'),'id'=>"friend_pk_start"),
				array( 'name'=> L('log_oper_thornisland_result'),'id'=>"thornisland_result"),			
				array( 'name'=> L('log_oper_thornisland_attack'),'id'=>"thornisland_attack"),
			);
		}
		else if($type == "mail")
		{
			$data = array(
				array( 'name'=> L('log_oper_reward_mail'),'id'=>"reward_mail"),
				array( 'name'=> L('log_oper_all_reward_mail'),'id'=>"all_reward_mail"),
				array( 'name'=> L('log_oper_add_mail'),'id'=>"add_mail"),
				array( 'name'=> L('log_oper_del_dbmail'),'id'=>"del_dbmail"),
				array( 'name'=> L('log_oper_del_mail'),'id'=>"del_mail"),
				array( 'name'=> L('log_oper_del_rewardmail'),'id'=>"del_rewardmail"),
			);
		}
		else if($type == "mission")
		{
			$data = array(
				array( 'name'=> L('log_oper_accept_mission'),'id'=>"accept_mission"),
				array( 'name'=> L('log_oper_complete_mission'),'id'=>"complete_mission"),
				array( 'name'=> L('log_oper_reward_mission'),'id'=>"reward_mission"),
			);
		}
		else if($type == "role")
		{
			$data = array(
				array( 'name'=> L('log_oper_addExp'),'id'=>"addExp"),
				array( 'name'=> L('log_oper_ChangeMoney'),'id'=>"ChangeMoney"),
				array( 'name'=> L('log_oper_ChangeDiamond'),'id'=>"ChangeDiamond"),
				array( 'name'=> L('log_oper_ChangeBagSize'),'id'=>"ChangeBagSize"),
				array( 'name'=> L('log_oper_ChangeCardBagSize'),'id'=>"ChangeCardBagSize"),
				array( 'name'=> L('log_oper_ChangeEvolutionStone'),'id'=>"ChangeEvolutionStone"),
				array( 'name'=> L('log_oper_ChangeRefineStone'),'id'=>"ChangeRefineStone"),
				array( 'name'=> L('log_oper_ChangeAdvanceStone'),'id'=>"ChangeAdvanceStone"),
				array( 'name'=> L('log_oper_ChangeElementWindStone'),'id'=>"ChangeElementWindStone"),
				array( 'name'=> L('log_oper_ChangeElementWaterStone'),'id'=>"ChangeElementWaterStone"),
				array( 'name'=> L('log_oper_ChangeElementLandStone'),'id'=>"ChangeElementLandStone"),
				array( 'name'=> L('log_oper_ChangeElementFireStone'),'id'=>"ChangeElementFireStone"),
				array( 'name'=> L('log_oper_ChangeFriendPoint'),'id'=>"ChangeFriendPoint"),
				array( 'name'=> L('log_oper_ChargeDiamond'),'id'=>"ChargeDiamond"),
				array( 'name'=> L('log_oper_ChangePower'),'id'=>"ChangePower"),
				array( 'name'=> L('log_oper_ChangeMoneyMazeTimes'),'id'=>"ChangeMoneyMazeTimes"),
				array( 'name'=> L('log_oper_ChangeExpMazeTimes'),'id'=>"ChangeExpMazeTimes"),
				array( 'name'=> L('log_oper_ChangeHonor'),'id'=>"ChangeHonor"),
				array( 'name'=> L('log_oper_consuption'),'id'=>"consuption"),
				array( 'name'=> L('log_oper_get_give_power'),'id'=>"get_give_power"),
				array( 'name'=> L('log_oper_free_draw_card'),'id'=>"free_draw_card"),
				array( 'name'=> L('log_oper_get_item'),'id'=>"get_item"),
				array( 'name'=> L('log_oper_mix_card'),'id'=>"mix_card"),
				array( 'name'=> L('log_oper_mine_explore'),'id'=>"mine_explore"),
			);
		}
		else if($type == "stage")
		{
			$data = array(
				array( 'name'=> L('log_oper_exit_stage'),'id'=>"exit_stage"),
				array( 'name'=> L('log_oper_pass_stage'),'id'=>"pass_stage"),
				array( 'name'=> L('log_oper_start_stage'),'id'=>"start_stage"),
				array( 'name'=> L('log_oper_stage_error'),'id'=>"stage_error"),
			);
		}
		else if($type == "team")
		{
			$data = array(
				array( 'name'=> L('log_oper_change_member_pos'),'id'=>"change_member_pos"),
				array( 'name'=> L('log_oper_change_cur_team'),'id'=>"change_cur_team"),
			);
		}
		else if($type == "trader")
		{
			$data = array(
				array( 'name'=> L('log_oper_refresh_trader'),'id'=>"refresh_trader"),
				array( 'name'=> L('log_oper_buy_trader'),'id'=>"buy_trader"),
			);
		}
		else if($type == "guild")
		{
			$data = array(
					array( 'name'=> L('log_oper_reward_guild'),'id'=>"reward_guild"),
					array( 'name'=> L('log_oper_create_guild'),'id'=>"create_guild"),
					array( 'name'=> L('log_oper_Disband_guild'),'id'=>"Disband_guild"),
					array( 'name'=> L('log_oper_member_add'),'id'=>"member_add"),
					array( 'name'=> L('log_oper_member_del'),'id'=>"member_del"),
					array( 'name'=> L('log_oper_guild_handle'),'id'=>"guild_handle"),
			);
		}
		
		array_unshift($data,array(
			'id'=>0,
			'name'=>L('common_all'),
		));
		
		echo $this->ajaxReturn($data);
    }
	

	//平台相关
	public function getChannelComboBox(){
		$user = session('user_auth');
		
		$data = array();
		
		if($user['area'] == 1)
		{
			$data = array(				
				array( 'name'=> L('channel_zhanglong'),'type'=>"1"),
				array( 'name'=> L('channel_uc'),'type'=>"18"),
			);
		}
		

				
		echo $this->ajaxReturn($data);
    }
	
	
	//物品类型
	public function getItemTypeComboBox(){
		$data = array(	
			array( 'name'=> L('restype_card'),'id'=>"1"),
			array( 'name'=> L('restype_piece'),'id'=>"2"),
			array( 'name'=> L('restype_equipment'),'id'=>"3"),
			array( 'name'=> L('restype_consumables'),'id'=>"4"),
			array( 'name'=> L('restype_money'),'id'=>"5"),
			array( 'name'=> L('restype_diamond'),'id'=>"6"),
			array( 'name'=> L('restype_friendpoint'),'id'=>"7"),
			array( 'name'=> L('restype_power'),'id'=>"8"),
			array( 'name'=> L('restype_rune'),'id'=>"9"),
			array( 'name'=> L('restype_evolution'),'id'=>"10"),
			array( 'name'=> L('restype_honor'),'id'=>"11"),
			array( 'name'=> L('restype_refine_stone'),'id'=>"12"),
			array( 'name'=> L('restype_player_exp'),'id'=>"13"),
			array( 'name'=> L('restype_card_exp'),'id'=>"14"),
			array( 'name'=> L('restype_endurance'),'id'=>"15"),
			array( 'name'=> L('restype_es_water'),'id'=>"16"),
			array( 'name'=> L('restype_es_fire'),'id'=>"17"),
			array( 'name'=> L('restype_es_land'),'id'=>"18"),
			array( 'name'=> L('restype_es_wind'),'id'=>"19"),
			array( 'name'=> L('restype_advance_stone'),'id'=>"20"),
			array( 'name'=> L('restype_team_athletics_exp'),'id'=>"21"),
			array( 'name'=> L('restype_stone'),'id'=>"22"),
			array( 'name'=> L('restype_guild_money'),'id'=>"23"),
		);
			
		echo $this->ajaxReturn($data);
    }
	public function getItemTypeComboBoxRoller(){
		$data = array(	
		    array( 'name'=> L('restype_card'),'id'=>"1"),
		    array( 'name'=> L('restype_piece'),'id'=>"2"),
			array( 'name'=> L('restype_equipment'),'id'=>"3"),
			array( 'name'=> L('restype_consumables'),'id'=>"4"),
			array( 'name'=> L('restype_money'),'id'=>"5"),
			array( 'name'=> L('restype_diamond'),'id'=>"6"),
			array( 'name'=> L('restype_refine_stone'),'id'=>"12"),
			array( 'name'=> L('restype_advance_stone'),'id'=>"20"),
		);	
		echo $this->ajaxReturn($data);
    }
    //读取本地配置
	public function readXml($filename = string,$isAll = false){
		
		if (!file_exists(DATA_PATH.$filename)) {
			exit(DATA_PATH.$filename);
		} 
		
		$xml = simplexml_load_file(DATA_PATH.$filename);
		
		foreach($xml->children() as $child)
		{
			foreach($child->attributes() as $a => $b)
			{
				$value[$a] = $b->__toString();
			}
			
			$data[] = $value;
		}
		
		if($isAll)
		{
			array_unshift($data,array(
				'id'=>0,
				'name'=>L('common_all')
			));
		}

		echo $this->ajaxReturn($data);
	}
	
	//卡牌id
	public function getCardIDComboBox(){
		$user = session('user_auth');
		
		$filepath = "";
		$lang = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		$this->readXml($filepath.'Card'.$lang.'.xml');
		
			//echo $this->ajaxReturn($data);
	}
	
	//根据用户登陆选择语言
	public function getItemIDComboBox(){
		//要根据不同  根据服务器区域
		/*$user = session('user_auth');
		
		$filepath = "";
		$lang = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		*/
		$user = cookie('think_language');
		$filepath = "";
		$lang = "";
		//台湾
		if($user == 'en-us')
		{
			$filepath = 'ChinaMainland/';//'English/';
			$lang = '';
		}
		//越南
		elseif ($user == 'pt-br')
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		$type = I('type');
		if($type == 1)
		{
			$file = $filepath.'Card'.$lang.'.xml';
		}
		else if($type == 2)
		{
			$file = $filepath.'Fragment'.$lang.'.xml';
		}
		else if($type == 3)
		{
			$file = $filepath.'Equipment'.$lang.'.xml';
		}
		else if($type == 4)
		{
			$file = $filepath.'Item'.$lang.'.xml';
		}
		else if($type == 22)
		{
			$file = $filepath.'Stone'.$lang.'.xml';	
		}
		
		
		if($file != "")
		{
			$this->readXml($file);
		}
		else
		{
			$data = array(	
				array( 'name'=> L('common_not_id'),'id'=>"0"),
			);
			
			echo $this->ajaxReturn($data);
		}
	
    }
	
	//转盘礼品id
	public function getItemTypeComboBoxRollerId(){
		$user = cookie('think_language');
		$filepath = "";
		$lang = "";
		//台湾
		if($user == 'en-us')
		{
			$filepath = 'ChinaMainland/';//'English/';
			$lang = '';
		}
		//越南
		elseif ($user == 'pt-br')
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		$type = I('type');
		if($type == 1)
		{
			$file = $filepath.'RollerCard'.$lang.'.xml';
		}
		else if($type == 2)
		{
			$file = $filepath.'RollerFragment'.$lang.'.xml';
		}
		else if($type == 3)
		{
			$file = $filepath.'RollerEquipment'.$lang.'.xml';
		}
		else if($type == 4)
		{
			$file = $filepath.'RollerItem'.$lang.'.xml';
		}
		
		
		if($file != "")
		{
			$this->readXml($file);
		}
		else
		{
			$data = array(	
				array( 'name'=> L('common_not_id'),'id'=>"0"),
			);
			
			echo $this->ajaxReturn($data);
		}
	}
	//礼包id
	public function getRedeemIDComboBox(){
		$user = session('user_auth');
		$lang = "";
		$filepath = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		
		$this->readXml($filepath.'Redeem'.$lang.'.xml');
    }
	
	public function getItemComboBox(){
		$user = session('user_auth');
		$lang = "";
		$filepath = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		
		$this->readXml($filepath.'Item'.$lang.'.xml');
    }
	//id 带全部
	public function getAllRedeemComboBox(){
		$user = session('user_auth');
				
		$lang = '';
		$filepath = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		
		$this->readXml($filepath.'Redeem'.$lang.'.xml',true);
    }

    //平台id
	public function getPlatformIDComboBox(){
		$user = session('user_auth');
		$lang = "";
		$filepath = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		
		$this->readXml($filepath.'PlatformList'.$lang.'.xml');
    }

    //平台id 带全部
	public function getAllPlatformIDComboBox(){
		$user = session('user_auth');
				
		$lang = '';
		$filepath = "";
		//台湾
		if($user['area'] == 3)
		{
			$filepath = 'Taiwan/';
			$lang = '';
		}
		//越南
		elseif ($user['area'] == 4)
		{
			$filepath = 'Vietnam/';
			$lang = '_VN';
		}
		else {
			$filepath = 'ChinaMainland/';
			$lang = '';
		}
		
		$this->readXml($filepath.'PlatformList'.$lang.'.xml',true);
    }
    
    //报表类型
    public function getReportTypeComboBox(){
    	$data = array(
    			array( 'name'=> L('report_daily'),'id'=>'daily'),
    			array( 'name'=> L('report_dately'),'id'=>'dately'),
    	);
    		
    	echo $this->ajaxReturn($data);
    }
    
    //排行类型
    public function getRankTypeComboBox(){
    	$data = array(
    			array( 'name'=> L('rank_playercost'),'id'=>'playercost'),
    			array( 'name'=> L('rank_playerpay'),'id'=>'playerpay'),
    		//	array( 'name'=> L('rank_cost'),'id'=>'cost'),
    	);
    
    	echo $this->ajaxReturn($data);
    }
    
    
    //货币类型
    public function getRankCoinTypeComboBox(){
    	$data = array(
    			array( 'name'=> L('coin_money'),'id'=>'ChangeMoney'),
    			array( 'name'=> L('coin_diamond'),'id'=>'ChangeDiamond'),
    			array( 'name'=> L('coin_power'),'id'=>'ChangePower'),
    			array( 'name'=> L('coin_endurance'),'id'=>'ChangeEndurance'),
    			array( 'name'=> L('coin_honor'),'id'=>'ChangeHonor'),
    			array( 'name'=> L('coin_friendpoint'),'id'=>'ChangeFriendPoint'),
    			array( 'name'=> L('coin_evolutionStone'),'id'=>'ChangeEvolutionStone'),
    			array( 'name'=> L('coin_refinestone'),'id'=>'ChangeRefineStone'),
    			array( 'name'=> L('coin_advancestone'),'id'=>'ChangeAdvanceStone'),
    			array( 'name'=> L('coin_elementwind'),'id'=>'ChangeElementWindStone'),
    			array( 'name'=> L('coin_elementwater'),'id'=>'ChangeElementWaterStone'),
    			array( 'name'=> L('coin_elementland'),'id'=>'ChangeElementLandStone'),
    			array( 'name'=> L('coin_elementfrie'),'id'=>'ChangeElementFireStone'),
    			
    	);
    
    	echo $this->ajaxReturn($data);
    }
    //活动公告
	public function getAllActivityTypeComboBox(){
		$data = array(
		array('name'=>L('act_Recharge_rebates'),'type'=>'1'),
		array('name'=>L('act_Time_limited_recruitment'),'type'=>'2'),
		array('name'=>L('act_Recharge'),'type'=>'3'),
		array('name'=>L('act_consumption'),'type'=>'4'),
		);
		echo $this->ajaxReturn($data);
	}
}