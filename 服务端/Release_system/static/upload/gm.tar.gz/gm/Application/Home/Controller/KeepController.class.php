<?php
namespace Home\Controller;
use Think\Model\MongoModel;

use Think\Controller;
use Think\Log;
//留存统计
//现在留存数据是创建以后 读的缓存在数据库的数据
//gmdb gm_keep
//字段说明  id 自增  date 数据时间  channel_id 登陆平台 group 服务器组id register 注册用户  twoday 次日留存  threeday 三日留存  sevenday 七日留存  fifteen 十五天留存   thirtyday 三十天留存 time 创建时间


class KeepController extends Controller {
	
	//这是用来测试时区的
	public function getTimeDate(){
		$data = array();
			
		$data['start'] = strtotime(I('startdate'));
		$data['end'] = strtotime(I('enddate'))-1;
		
		$data['start_db'] = new \MongoDate($data['start']);
		$data['end_db'] = new \MongoDate($data['end']);
		
		$data['time_db'] = array('$gt' => $data['start_db'], '$lte' => $data['end_db']);
		 
		$data['zone'] = date_default_timezone_get();
		
		$data['nowtime'] = strtotime('now');
		
		$data['time'] = time();
				
		//$datalist = $this->createkeepData($start,$end,I('serverid'));
		
		echo $this->ajaxReturn($data);
	}
	
	public function createkeeplog()
	{
		
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;
		$channelid = intval(I('channelid'));
		$datalist = $this->getkeepData($stime, $etime,$channelid,I('serverid'));
		$daily =D('Keep');
		
		ini_set('mongo.long_as_object', 0);
		
		foreach ($datalist AS $value)
		{
			$where = array(
					'group'=>intval($value['group']),
					'date'=>$value['date'],
			);
				
			$count = $daily->where($where)->count();
			if ($count == 0)
			{
				$daily->add($value);
			}
			else
			{
				$daily->where($where)->save($value);
			}
		}
		
		
		$data['success']=true;
		echo $this->ajaxReturn($data);
	}
	
	public function getkeeplog()
	{
		$stime = strtotime(I('startdate'));
		$etime= strtotime(I('enddate'))-1;

		$keep =D('Keep');
		
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
		$channelid = intval(I('channelid'));
		$time = array('$gte' => $start, '$lt' => $end);
		
		$where = array(
			'time'=>$time,
		);
		
		if(I('serverid') != 0){
			$where['group'] = intval(I('serverid'));
		}
			ini_set('mongo.long_as_object', 0);
		$keep->getCollection()->createIndex(array('time'=>1,'serverid' => 1));
		$field = array(
				'_id'=>false,
				'date'=>false,
				);
		$options = array('field'=>$field);
		$data['totalCount']=$keep->where($where)->count();
			
		$cursor = $keep->where($where)->select($options);
		$data['data'] = array();
		$listdata = array();
		
		foreach ($cursor AS $value)
		{
			$proname = date('Y-m-d', $value['time']->sec);
			if(!array_key_exists($proname,$listdata))
			{
				$listdata[$proname] = $value;
				 $listdata[$proname]['time']=date('Y-m-d',$value['time']->sec);
			}
			else {
				$listdata[$proname]['date'] = $value['date'];
				$listdata[$proname]['register'] += $value['register'];
				$listdata[$proname]['twoday'] += $value['twoday'];
				$listdata[$proname]['threeday'] += $value['threeday'];
				$listdata[$proname]['forthday'] += $value['forthday'];
				$listdata[$proname]['fifthday'] += $value['fifthday'];
				$listdata[$proname]['sixthday'] += $value['sixthday'];
				$listdata[$proname]['sevenday'] += $value['sevenday'];
				$listdata[$proname]['fifteen'] += $value['fifteen'];
				$listdata[$proname]['thirtyday'] += $value['thirtyday'];
			}
		}
		$listend = 0;
		for ($i=0; $etime >= $listend; $i++)
		{
			$liststart =$stime +($i)*60*60*24;
			$listend = $stime +($i+1)*60*60*24-1;
				
			$proname = date('Y-m-d', $liststart);
				
			if(array_key_exists($proname,$listdata))
			{
				$data['data'][] = $listdata[$proname];
			}
			else
			{
				//$data['data'][] = array(
				//		'date' => $proname,
				//);
			}
		}
		$data['success']=true;
			
		echo $this->ajaxReturn($data);
	}
	
	//生成留存数据
	public function getkeepData($stime,$etime,$channelid,$serverid){
	
		$itmezone = date_default_timezone_get();
		$itmezonehour = 8;
		if ($itmezone == 'PRC')
		{
			$itmezonehour = 8;
		}
		else
		{
			$itmezonehour = 7;
		}
		
		$start = new \MongoDate($stime);
		$end = new \MongoDate($etime);
		$time = array('$gt' => $start, '$lte' => $end);

		$serverdata = S('SERVER_CONFIG_DATA');
		
		$listdata = array();
		
		$temp = array();
		foreach ($serverdata AS $value)
		{
			if($serverid == 0 || $serverid == $value['id'])
			{			
				$map = "
					function() {
						emit(this.acc,{oper_:this.login_oper,time_:this.time,channel_id:this.channel_id,register_time:0,createrole_time:0,login_time:[]});
					} 
				"; 
				$reduce = "
					function(key, values){
						var ret = {register_time:0,createrole_time:0,login_time:[],register:0,twoday:0,threeday:0,channel_id:0,forthday:0,fifthday:0,sixthday:0,sevenday:0,fifteen:0,thirtyday:0};
						values.forEach(function(val) {
							var time = val.time_/1000 - (val.time_/1000 + ".$itmezonehour."*60*60)%86400 - ".$itmezonehour."*60*60;
							
							if(val.channel_id != 0)
						{
								ret.channel_id = val.channel_id;
							}
						if(typeof val.oper_=='undefined')
							{
								if(val.register_time != 0)
								{
									ret.register_time = val.register_time;
								}
								if(val.createrole_time != 0)
								{
									ret.createrole_time = val.createrole_time;
								}
								val.login_time.forEach(function(val2) {
									ret.login_time.push(val2);
								});	
							}
							else{
								if(val.oper_ == 'acc_register') 
								{
									ret.register_time = time;
									val.register_time = ret.register_time;
								
								}else if(val.oper_ == 'create_role') {
									ret.createrole_time = time;
									val.createrole_time = ret.createrole_time;
								}
								else{
									ret.login_time.push(time);
								}
							}
						});

						return ret;
					}
				";
				
				$finalize = "
					function Finalize(key, reduced)
					{	
						if(reduced.register_time != 0)
						{
							reduced.register = 1;
							reduced.login_time.forEach(function(val){
								var day = (val - reduced.register_time)/86400;
								
								if(day >= 29 && day < 30)
									reduced.thirtyday = 1;
								if(day >= 14 && day < 15)
									reduced.fifteen = 1;
								else if(day >= 6 && day < 7)
									reduced.sevenday = 1;
								else if(day >= 5 && day < 6)
									reduced.sixthday = 1;
								else if(day >= 4 && day < 5)
									reduced.fifthday = 1;
								else if(day >= 3 && day < 4)
									reduced.forthday = 1;
								else if(day >= 2 && day < 3)
									reduced.threeday = 1;
								else if(day >= 1 && day < 2)
									reduced.twoday = 1;
							});
						}

						return reduced;
					}
				";
					$where = array(
					'time' => $time,
					'channel_id' => $channelid,
					'login_oper' => array('$in'=>array('acc_login','logout','create_role','acc_register')),
					);
			
				if($value['loguser'] != '')
				{
					$host = 'mongodb://'.$value['loguser'].':'.$value['logpass'].'@'.$value['logip'].':'.$value['logport'].'/';
				}
				else{
					$host = 'mongodb://'.$value['logip'].':'.$value['logport'].'/';
				}
				
				$mongo = new \MongoClient($host);
				$instance = $mongo->selectDB($value['logname']);
				
				$result2 = $instance->command(array(
						'mapreduce' => 'log_login',
						'map'       => $map,
						'reduce'    => $reduce,
						'query'	=> $where,
						'finalize' =>$finalize,
						'out' => 'log_keep_temp',
						
				));
			//	echo $this->ajaxReturn($result2);		
			
				$tempdb = $instance->selectCollection("log_keep_temp");
				
				$cond = array(  
					array(  
						'$match' => array(
							'value.register' => array('$gt'=> 0 ),
						)),  
					array(  
						'$group' => array(  
							'_id' => '$value.register_time',
							'register'=> array('$sum'=>'$value.register'),
							'twoday'=> array('$sum'=>'$value.twoday'),
							'threeday'=> array('$sum'=>'$value.threeday'), 
							'forthday'=> array('$sum'=>'$value.forthday'), 
							'fifthday'=> array('$sum'=>'$value.fifthday'), 
							'sixthday'=> array('$sum'=>'$value.sixthday'), 
							'sevenday'=> array('$sum'=>'$value.sevenday'),
							'fifteen'=> array('$sum'=>'$value.fifteen'),
							'thirtyday'=> array('$sum'=>'$value.thirtyday'), 
						),  
					),  
				); 

				$results = $tempdb->aggregate($cond);
				
				foreach ($results['result'] AS $result_value)
				{
					$time = array_shift($result_value)+$itmezonehour*60*60;
					
					$proname = date('Y-m-d', $time);
					$temp = $result_value;
					$temp['date'] = $proname;
					$temp['time'] = new \MongoDate($time);
					$temp['group'] = $value['id'];
					
					$listdata[] = $temp;
				}
					
				//echo $this->ajaxReturn($results);
			}
		}
		


		return $listdata;

		//$data['success']=true;
		
		//echo $this->ajaxReturn($data);
    }

}