<?php

namespace Home\Model;
use Think\Model\MongoModel;
class SeverModel extends MongoModel {
	//protected $pk               =   'id';
}