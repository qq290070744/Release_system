<?php

namespace Home\Model;
use Think\Model\MongoModel;
class BlacklistModel extends MongoModel {

}