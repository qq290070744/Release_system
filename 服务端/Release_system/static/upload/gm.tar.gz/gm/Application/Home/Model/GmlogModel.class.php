<?php

namespace Home\Model;
use Think\Model\MongoModel;


//如果需要在gmdb 建数据库 必须定义个 model 然后可以用 D('')直接调用
class GmlogModel extends MongoModel {
	public function GmAddLog($oper,$logstr){	
	
		$user = session('user_auth');
		
		$data = array(
			'uid'         => $user['uid'],
			'id'         => $user['id'],
			'ip'         => $user['login_ip'],
			'username'    => $user['username'],
			'oper'        => $oper,
			'logstr'      => $logstr,
			'time'        => new \MongoDate(),
        );
		
		
		//$datajson = (array)json_decode($data);
		
		$this->add($data);
    }
}