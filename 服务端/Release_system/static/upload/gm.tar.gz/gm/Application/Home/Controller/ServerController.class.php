<?php
namespace Home\Controller;
use Think\Controller;


//UI上  服务器管理 服务器配置

//管理GM后台配置的服务器信息    gm_sever  <-前缀是配置的
//字段说明   id 为0的  是特殊配置    
//accseverip 账号服务器ip accseverport 账号服务器开发http端口     这是用来和账号服务器通讯 主要只是封号的
//accdbip accdbport accdbuser accdbpass accdbname  账号数据库配置   是为了改 登陆的 公告
//paydbip paydbport paydbuser paydbpass paydbname  由于是用了一个付费服务器 所以log在一个db 上 需要单独配置

//其他配置
//字段说明     id 自增ID name 自配名字  severip 社交服务器ip severport 社交服务器开发http端口   area 服务器相关  
//logip logport loguser logpass logname  日志服数据库		分析数据用
//toolsip toolsport toolsuser toolspass toolsname  tools服数据库  相关系统 跑马灯 兑换码 发系统邮件

class ServerController extends Controller {
	public function getInfo(){	
		$server=D('Sever');	
		
		$data['success']=true;
		
		$user = session('user_auth');
		
		$acc = $server->where(array('id'=>0))->select();
		
		is_array($acc)?null:$acc = array();
		
		$accconfigdata=[];
		
		foreach ($acc AS $key=>$value)
		{
			$accconfigdata = $value;
		}
		
		S('OTHERSERVER_CONFIG_DATA',$accconfigdata);
		
		
		$where['id'] = array('$ne'=> 0);
		
		if($user['area'] != 1)
		{
			$where['area'] = $user['area'];
		}
		
		ini_set('mongo.long_as_object', 0);
		$total=$server->where($where)->count();
		
		$configdata =[];
		$data['totalCount']=$total;
		
		//select获取带数组带唯一id
		$serverdata=$server->where($where)->select();
	
		foreach ($serverdata AS $key=>$value)
		{
			$data['data'][] = $value;
			$configdata[$value['id']] = $value;
		}
		
		
		S('SERVER_CONFIG_DATA',$configdata);
		//$data['data']=$server->limit(I('start').','.I('limit'))->select();
		
		echo $this->ajaxReturn($data);
    }
	
	public function addInfo(){
		$httpContent = file_get_contents('php://input', 'r');
		$model=D('Sever');
		
		$datajson = (array)json_decode($httpContent);
		
		//暂时用来取最大的id数+1
		//$cond = array(   
		//			array(  
		//				'$group' => array(
		//					'_id'=>null,
		//					'index'=> array('$max'=>'$id'),   						
		//				)
		//			),					
		//		); 
				
		$result = $model->getCollection()->aggregate();
		
		$index = $result['result'][0]['index'];
		//$datajson['id'] = $index+1;
		ini_set('mongo.long_as_object', 0);
		if($model->add($datajson))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}	
		echo $this->ajaxReturn($data);
    }
	
	public function delInfo(){
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);

		$temp=array();
		
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = $temp['id'];
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$server=D('Sever');
		
		if($server->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		echo $this->ajaxReturn($data);
    }

	public function editInfo(){
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		$where = array(
			'id'=>$datajson['id']
		);
		
		$server=D('Sever');
		
		if($server->where($where)->save($datajson))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		echo $this->ajaxReturn($data);
    }
    
    public function editAccInfo(){
    	$server=D('Sever');
    	
    	$acc = I('post.');
    	$acc['id'] = 0;
    	if ($server->where(array('id'=>0))->count() == 0)
    	{
    		ini_set('mongo.long_as_object', 0);
    		if($server->add($acc))
    		{
    			$data['success']=true;
    		}else{
    			$data['success']=false;
    		}
    	}
    	else {
    		ini_set('mongo.long_as_object', 0);
    		if($server->where(array('id'=>0))->save($acc))
    		{
    			$data['success']=true;
    		}else{
    			$data['success']=false;
    		}
    	}
    	
    	S('OTHERSERVER_CONFIG_DATA',$acc);
    	
    	echo $this->ajaxReturn($data);
    }
    
    public function getAccInfo(){
    
    	$data['success'] = true;
    	$data['data'] = S('OTHERSERVER_CONFIG_DATA');
    	echo $this->ajaxReturn($data);
    }
    
    public function KickoutAllPlayer(){
    	$serverdata = S('SERVER_CONFIG_DATA');
			
		$listdata = array();
		
		foreach ($serverdata AS $value)
		{
			if($serverid == 0 || $serverid == $value['id'])
			{
				$playerurl = $value['severip'].":".$value['severport'];
				 
				$playerhttpdata['fun']="KickOutPlayer";
				$playerhttpdata['roleids']="";
				 
				$httpstr = http($playerurl, $playerhttpdata, 'POST', array("Content-type: text/html; charset=utf-8"));
			}
		}    		
    }
}