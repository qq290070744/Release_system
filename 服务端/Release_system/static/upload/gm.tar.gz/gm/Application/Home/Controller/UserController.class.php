<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;

//UI上  服务器管理 GM用户管理
//管理GM用户表的   gm_member  <-前缀是配置的
//字段说明     id 自增ID  username 用户名  password 用户密码 md5  status 用户所在区域  标明版本 读相应配置   time  场景时间   last_login_ip 最后一次登录ip  最后一次登录时间
class UserController extends Controller {
    public function addInfo(){
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		
		ini_set('mongo.long_as_object', 0);			
		
		$member=D('Member');
		
		$cond = array(   
			array(  
				'$group' => array(
					'_id'=>null,
					'index'=> array('$max'=>'$id'),   						
				)
			),					
		); 
		ini_set('mongo.long_as_object', 0);
		
		$result = $member->getCollection()->aggregate($cond);
		$index = $result['result'][0]['index'];
		
		$adddata = array(
			'id'=>intval($index+1),
			'username'=>$datajson['username'],
			'password'=>md5($datajson['newPwd']),
			'status'=>intval($datajson['status']),
			'time'=>new \MongoDate(),
			'auth'=>$datajson['auth']
		);
		
		if($member->add($adddata))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		
		echo $this->ajaxReturn($data);
    }
	
	public function getInfo(){	
		$member=D('Member');
		
		$user = session('user_auth');
		
		$where = array(
			'id' => array('$ne'=>intval($user['id'])),
		);
		
		if ($user['area'] != 1)
		{
			$where['state'] = intval($user['area']);
		}
		ini_set('mongo.long_as_object', 0);
		
		$total=$member->where($where)->count();
		
		$data['totalCount']=$total;
		$data['success']=true;
			
		$serverdata=$member->where($where)->limit(I('start').','.I('limit'))->select();
	
		$i= 0;
		foreach ($serverdata AS $key=>$value)
		{
			$data['data'][$i] = $value;
			$i++;
		}
		
		echo $this->ajaxReturn($data);
    }
	
	public function delInfo(){
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);

		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = intval($temp['id']);
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$member=D('Member');
		
		ini_set('mongo.long_as_object', 0);
		
		if($member->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		echo $this->ajaxReturn($data);
    }

	public function editInfo(){
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		$where = array(
			'id'=>intval($datajson['id'])
		);
		
		$update = [];
		
		if($datajson['newPwd'] != null)
		{
			$update['password'] = md5($datajson['newPwd']);
		}
		
		if($datajson['status'] != null)
		{
			$update['status'] = $datajson['status'];
		}
		if($datajson['auth'] != null)
		{
			$update['auth'] = $datajson['auth'];
		}

		$member=D('Member');
		
		ini_set('mongo.long_as_object', 0);
		
		if($member->where($where)->save($update))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		echo $this->ajaxReturn($data);
    }
}