<?php

namespace Home\Model;
use Think\Model\MongoModel;
class CodeModel extends MongoModel {
	//protected $pk               =   'id';

	public function getRoleList($iplatformid){	
		$role_list = array();
		$data['success']=false;


		$where['platformid'] = intval($iplatformid);
		$where = array('user'=> array('$exists' => 1));
		$model->getCollection()->createIndex(array('platformid' => 1));		

		
		$start = new \MongoDate(strtotime(I('startdate')));
		$end = new \MongoDate(strtotime(I('enddate'))-1);
			
		$time = array('$gt' => $start, '$lte' => $end);
		
		$paydb = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $paydb['paydbuser'],
					'db_pwd'   => $paydb['paydbpass'],
					'db_host'  => $paydb['paydbip'],
					'db_port'  =>$paydb['paydbport'],
		);
		
		$model=new MongoModel( $paydb['paydbname'].'.prepaid_order_result','log_',$connection);
		
		$model->getCollection()->createIndex(array('group' => 1,'time' => 1,'detail' => 1));
			
		$where = array(
			'group'=>intval(I('serverid')),
			'time' => $time,
			'detail'=>'check_pass',
		);
		
		if(I('channelid') != -1)
		{
			$where['channel'] = I('channel');
		}
		
		if(I('roleid') != 0)
		{
			$where['role_id'] = new \MongoInt64(I('roleid'));
		}
							
		//$data['totalCount']=$model->where($where)->count();
				
		$cond = array(
			array(  
				'$match' => $where,
			), 
			array(
				'$group' => array(
					'_id'=>null,
					'index'=> array('$sum'=>'$rmb'),
					'count'=> array('$sum'=>1),
				)
			),					
		);
		
		ini_set('mongo.long_as_object', 1);
				
		$result = $model->getCollection()->aggregate($cond);
		
		$rmb = $result['result'][0]['index'];
		$data['totalCount'] = $result['result'][0]['count']->value;
		
		$data['data'][] =	array(
			'order_id'=>'all',
			'rmb' => $rmb,
		);
			
			
		$result = $model->where($where)->limit(I('start').','.I('limit'))->select();
		
		foreach ($result AS $key)
		{	
			$listdata = $key;
			$listdata["roleid"] = $key["role_id"]->value;
			$listdata["time"] = date('Y-m-d H:i:s', $key['time']->sec);

			$data['data'][] = $listdata;
		}	
				
		$data['success']=true;

		echo $this->ajaxReturn($data);
    }
}