<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;


//账号处理
//gmdb gm_blacklist  <-前缀是配置的  主要这是 类似 记的封号处理的 log日志的
//字段说明  id  自增   roleid 处理玩家rollid time 处理时间  end_time 封号结束时间  severid 服务器id  remark 备注

class LimitController extends Controller {
	
    public function getLimit(){
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
										
		$value = $serverdata[I('serverid')];
		if($value == null)
		{
			$data['success'] = false;
			$data['errorMessage'] = L('error_server');
		}
		else
		{
			$model = D('Blacklist');
			
			$where = array(
				//'end_time'=> array('$gt' => time()),
				'removetime'=> array('$exists' => false),
				'serverid'=>intval(I('serverid')),
			);
		
			$model->getCollection()->createIndex(array('end_time' => 1,'serverid'=>1));
			
			$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();
			
			$data['totalCount']=$model->where($where)->count();
			
			foreach ($cursor AS $key=>$value)
			{
				$limitdata = $value;
				$limitdata['time'] = date('Y-m-d H:i:s', $value['time']->sec);
				$limitdata['end_time'] = date('Y-m-d H:i:s', $value['end_time']);
					
				array_push($data['data'],$limitdata);
			}	
		
			$data['success']=true;
		}
		
		
		echo $this->ajaxReturn($data);
    }
	
	
    public function addLimit(){
		$accids = str_ireplace('&quot;','"',I('post.accid'));
		$accid = json_decode($accids);
		
		$endtime = strtotime(I('post.end_time'));
		
		$serverdata = S('SERVER_CONFIG_DATA');	
		$value = $serverdata[I('post.server')];
		
		$model = D('Blacklist');
		
		//暂时用来取最大的id数+1
		$cond = array(   
			array(  
				'$group' => array(
					'_id'=>null,
					'index'=> array('$max'=>'$id'),   						
				)
			),					
		);
		
		$userdata = $_SESSION['user_auth']['username'];	

		$result = $model->getCollection()->aggregate($cond);
		$index = $result['result'][0]['index'];
		
		//$url = C('acc_ip').":".C('acc_port');
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		$url = $accserver['accseverip'].":".$accserver['accseverport'];

		$httpdata['fun']="LimitPlayer";
				
		$httpdata['accids']=$accids;
		$httpdata['time']=$endtime;

		$httpstr = http($url, $httpdata, 'POST', array("Content-type: text/html; charset=utf-8"));
		
		//踢出下线
		if (I('post.iskickout') == true)
		{
			//$serverdata = S('SERVER_CONFIG_DATA');
			
			//$value = $serverdata[I('serverid')];
			if ($value != null)
			{
				$playerurl = $value['severip'].":".$value['severport'];
					
				$playerhttpdata['fun']="KickOutPlayer";
					
				$playerhttpdata['accids']=$accids;
					
				$httpstr = http($playerurl, $playerhttpdata, 'POST', array("Content-type: text/html; charset=utf-8"));
			}
		}
		
		if($httpstr['success'] == 'true')
		{
			foreach ($accid AS $val)
			{	
				$data = array(				
					'id' => $index+1,
					'accid' =>$val,
					'time'=>new \MongoDate(),
					'end_time' =>$endtime,
					'acc'=>$userdata,
					'serverid'=>$value['id'],
					'remark'=>I('post.remark'),
				);
					
				$result = $model->add($data);
				
				$index++;
			}
				
			//LOG记录
			D('Gmlog')->GmAddLog('LimitPlayer',json_encode($httpdata));
				
			$res['success']='true';
			echo $this->ajaxReturn($res);
		}
		else{
			echo $this->ajaxReturn($httpstr);
		}
    }
	
	public function delLimit(){	
		$jsondata= str_ireplace('&quot;','"',I('post.data'));
		$temp = json_decode($jsondata,true);
		
		$i = 0;
		$ids = [];
		$accid = [];
		$serverid = 0;
		foreach($temp as $val){
			
			$ids[$i] = $val['accid'];
			$accid[$i]=$val['accid'];
			$serverid = $val['serverid'];
			$i++;
		}
		
		$serverdata = S('SERVER_CONFIG_DATA');	
		$value = $serverdata[$serverid];
				
		$where['acc_id'] = array('in',$ids);
		//$url = C('acc_ip').":".C('acc_port');
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		$url = $accserver['accseverip'].":".$accserver['accseverport'];
		
		$data['fun']="LimitPlayer";
		
		$data['accids']=json_encode($accid);
		$data['time']=0;

		$httpstr = http($url, $data, 'POST', array("Content-type: text/html; charset=utf-8"));
		if($httpstr['success'] == true)
		{
			$model = D('Blacklist');
			
			$userdata = $_SESSION['user_auth']['username'];	
			
			$save = array(
				'removetime' =>new \MongoDate(),
				'removeacc' =>$userdata,
			);
		
			$model->where($where)->save($save);
			
			//LOG记录
			D('Gmlog')->GmAddLog('LimitOutPlayer',json_encode($data));

			$res['success']='true';
			echo $this->ajaxReturn($res);
		}
		else{
			echo $this->ajaxReturn($httpstr);
		}
		
    }
	
}