<?php
namespace Home\Controller;
use Think\Controller;

//gmdb  gm_gmlog 
//字段说明  uid 用户_id id 用户id ip 用户ip username 用户名 oper 处理分类  logstr 相关处理参数

class GmLogController extends Controller {

	public function getInfo(){	

		if(I('username') != "")
		{
			$where = array(
				'username'        => I('username'),
	        );
		}
		else
		{
			$where = array();
		}
		
		$data['data'] = array();
		
		$gmlog=D('Gmlog');
		
		$gmlog->getCollection()->createIndex(array('username' => 1));
		
		$total=$gmlog->where($where)->count();
		
		$data['totalCount']=$total;
		$data['success']=true;
		
		$options['order'] = array('time' => -1);

		//select获取带数组带唯一id
		$serverdata=$gmlog->where($where)->limit(I('start').','.I('limit'))->select($options);
		
		foreach ($serverdata AS $key=>$value)
		{
			$logdata = $value;
			$logdata['time'] = date('Y-m-d H:i:s', $value['time']->sec);
			$logdata['id'] = $value['_id'];
			$logdata['userid'] = $value['id'];
			array_push($data['data'],$logdata);
		}
		
		echo $this->ajaxReturn($data);
    }
}