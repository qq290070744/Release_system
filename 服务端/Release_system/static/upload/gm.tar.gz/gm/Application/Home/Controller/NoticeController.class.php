<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;

//UI公告管理
//notice  登陆公告
//ScrollbarNotic 滚动条
class NoticeController extends Controller {
	
    public function getNotic(){
		$data['data'] = array();
			
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $accserver['accdbuser'],
					'db_pwd'   => $accserver['accdbpass'],
					'db_host'  => $accserver['accdbip'],
					'db_port'  =>$accserver['accdbport'],
					);
		
		$model=new MongoModel($accserver['accdbname'].'.announcement',null,$connection);
				
		$valid = intval(I('valid'));
		$where = array(
			'valid' => (bool)$valid,
		);
					
		$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();
			
		$data['totalCount']=$model->where($where)->count();
			
		foreach ($cursor AS $key=>$cursorvalue)
		{
			$notice = $cursorvalue;
			$notice['serverid'] = $value['id'];
			array_push($data['data'],$notice);
		}
				
				$data['success']=true;

		echo $this->ajaxReturn($data);
    }
	
	public function addNotic(){	
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $accserver['accdbuser'],
					'db_pwd'   => $accserver['accdbpass'],
					'db_host'  => $accserver['accdbip'],
					'db_port'  =>$accserver['accdbport'],
					);
		
		$model=new MongoModel($accserver['accdbname'].'.announcement',null,$connection);
				
				//暂时用来取最大的id数+1
		$cond = array(   
			array(  
				'$group' => array(
					'_id'=>null,
					'index'=> array('$max'=>'$id'),   						
				)
			),					
		); 
				
		$result = $model->getCollection()->aggregate($cond);
		$index = $result['result'][0]['index'];
				
		$valid = $datajson['valid'];
				
		$data = array(
			'id'=>$index+1,
			'title'=>$datajson['title'],
			'text'=>$datajson['text'],
			'valid' => (bool)$valid,
			'time'=>new \MongoDate(),
		);

		$result = $model->add($data);	
				
		D('Gmlog')->GmAddLog('addNotic',json_encode($data));
		
		$res['success']='true';
		echo $this->ajaxReturn($res);
    }
	
	public function updateNotic(){	
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		
		$id = intval($datajson['id']);
		$where = array(
			'id'=>intval($id),
		);
		
		$notice = [];
		
		if(array_key_exists('text',$datajson))
		{
			$notice['text'] = $datajson['text'];
		}
		
		if(array_key_exists('title',$datajson))
		{
			$notice['title'] = $datajson['title'];
		}
		
		if(array_key_exists('valid',$datajson))
		{
			$notice['valid'] = (bool)intval($datajson['valid']);
		}
		
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $accserver['accdbuser'],
					'db_pwd'   => $accserver['accdbpass'],
					'db_host'  => $accserver['accdbip'],
					'db_port'  =>$accserver['accdbport'],
					);
		
		$model=new MongoModel($accserver['accdbname'].'.announcement',null,$connection);
		
		if($model->where($where)->save($notice))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		
		D('Gmlog')->GmAddLog('updateNotic',json_encode($notice));
		
		echo $this->ajaxReturn($data);
    }
	
	public function delNotic(){	
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);
		
		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = intval($temp['id']);
			$i++;
		}
		
		$where['id'] = array('in',$ids);
		
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $accserver['accdbuser'],
					'db_pwd'   => $accserver['accdbpass'],
					'db_host'  => $accserver['accdbip'],
					'db_port'  =>$accserver['accdbport'],
					);
		
		$model=new MongoModel($accserver['accdbname'].'.announcement',null,$connection);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}

		D('Gmlog')->GmAddLog('delNotic',json_encode($where));
		
		echo $this->ajaxReturn($data);
    }
	
	public function getScrollbarNotic(){
		
		$data['data'] = array();
			
		$serverdata = S('SERVER_CONFIG_DATA');
		foreach ($serverdata AS $value)
		{
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
				$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $value['toolsuser'],
					'db_pwd'   => $value['toolspass'],
					'db_host'  => $value['toolsip'],
					'db_port'  => $value['toolsport'],
				);
		
				$model=new MongoModel($value['toolsname'].'.scrollingnews',null,$connection);
				
				$valid = intval(I('valid'));
				$where = array(
					'valid' => (bool)$valid,
				);
		
				$cursor = $model->where($where)->limit(I('start').','.I('limit'))->select();
			
				$data['totalCount']=$model->where($where)->count();
			
				foreach ($cursor AS $key=>$cursorvalue)
				{
					$notice = $cursorvalue;
					$notice['id'] = $cursorvalue['_id'];
					$notice['nid'] = $cursorvalue['id'];
					$notice['serverid'] = $value['id'];
					$notice['start_time'] = date('Y-m-d H:i:s', $cursorvalue['start_time']);
					$notice['end_time'] = date('Y-m-d H:i:s', $cursorvalue['end_time']);
					
					array_push($data['data'],$notice);
				}
				
				$data['success']=true;
			}
		}

		echo $this->ajaxReturn($data);
    }
	
	public function addScrollbarNotic(){
		
		$serverdata = S('SERVER_CONFIG_DATA');

		foreach ($serverdata AS $value)
		{										
			if(I('serverid') == 0 || I('serverid') == $value['id'])
			{
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
				
				$model=new MongoModel($value['toolsname'].'.scrollingnews',null,$connection);
				
				//暂时用来取最大的id数+1
				$cond = array(   
					array(  
						'$group' => array(
							'_id'=>null,
							'index'=> array('$max'=>'$id'),   						
						)
					),					
				); 
				
				$result = $model->getCollection()->aggregate($cond);
				$index = $result['result'][0]['index'];
				
				$valid = (bool)(I('post.valid'));
				
				$data = array(				
					'id' => $index+1,
					'text' =>I('post.text'),
					'start_time' =>strtotime(I('post.start_time')),
					'end_time' =>strtotime(I('post.end_time')),
					'period' =>(int)I('post.period'),
					'valid' =>$valid,
					'time'=>new \MongoDate(),
				);

				$result = $model->add($data);	


				//如果是当前激活的 要发给服务器
				if($valid)
				{
					$url = $value['severip'].":".$value['severport'];
			
					//定义传递的参数数组
					$httpdata = $data;
					$httpdata['fun']="ChangeScrollingNews";
					$httpdata['add_or_del'] = 'true';
					$httpstr = http($url, $httpdata, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
				}
				
				D('Gmlog')->GmAddLog('addScrollbarNotic',json_encode($data));	
			}			
		}
		
		$res['success']='true';
		echo $this->ajaxReturn($res);
    }
	
	public function updateScrollbarNotic(){
		$httpContent = file_get_contents('php://input', 'r');
		$datajson = (array)json_decode($httpContent);
		
		//$id = intval($datajson['id']);
		$where = array(
			'_id'=>new \MongoId( $datajson['id']),
		);
		
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[$datajson['serverid']];
		
		$notice = [];
		
		if(array_key_exists('start_time',$datajson))
		{
			$notice['start_time'] = strtotime($datajson['start_time']);
		}
		
		if(array_key_exists('end_time',$datajson))
		{
			$notice['end_time'] = strtotime($datajson['end_time']);
		}
		
		if(array_key_exists('text',$datajson))
		{
			$notice['text'] = $datajson['text'];
		}
		
		if(array_key_exists('period',$notice))
		{
			$notice['period'] = intval($datajson['period']);
		}
			
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
		$model=new MongoModel($value['toolsname'].'.scrollingnews',null,$connection);
		
		if($model->where($where)->save($notice))
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		
		D('Gmlog')->GmAddLog('updateScrollbarNotic',json_encode($notice));
		
		echo $this->ajaxReturn($data);
    }
	
	public function delScrollbarNotic(){		
		$httpContent=file_get_contents('php://input', 'r');
		$httpContent=str_replace(']','',str_replace('[','',$httpContent));
		$httpContent=explode(',',$httpContent);
		
		$temp=array();
		$i = 0;
		foreach($httpContent as $val){
			$temp=(array)json_decode($val);
			$ids[$i] = new \MongoId( $temp['id']);
			$i++;
		}
		
		$where['_id'] = array('in',$ids);
		
		$serverdata = S('SERVER_CONFIG_DATA');							
		$value = $serverdata[I('get.serverid')];
		
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
		$model=new MongoModel($value['toolsname'].'.scrollingnews',null,$connection);
		
		if($model->where($where)->delete())
		{
			$data['success']=true;
		}else{
			$data['success']=false;
		}
		
		//如果是当前激活的 要发给服务器
		$valid = (bool)I('get.valid');
		if($valid)
		{
			$url = $value['severip'].":".$value['severport'];
			
			$httpdata['fun']="ChangeScrollingNews";
			$httpdata['add_or_del'] = 'false';
			
			foreach($ids as $val){
				//定义传递的参数数组
				
				$httpdata['id'] =$val;
				
				$httpstr = http($url, $httpdata, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
			}

		}

		D('Gmlog')->GmAddLog('delScrollbarNotic',json_encode($where));
		
		echo $this->ajaxReturn($httpstr);
    }
	
	
	//再议
	public function validScrollbarNotic(){
	
		$jsondata= str_ireplace('&quot;','"',I('post.data'));
		
		$temp = json_decode($jsondata,true);
		
		$serverdata = S('SERVER_CONFIG_DATA');
		$valid = (bool)I('post.valid');
			
		foreach($temp as $val){
			if($val['valid'] == $valid)
			{
				$data['Message'] = $data['Message'].'id'.$val['id'].'已激活或者已下架;';
				continue;
			}
								
			$value = $serverdata[$val['serverid']];
			
			if($value == null)
			{
				$data['Message'] = $data['Message'].'id'.$val['id'].'服务器没有此公告;';
				continue;
			}
			
			$data['success']=false;
		
			$connection = array(
			'db_type'  => 'mongo',
			'db_user'  => $value['toolsuser'],
			'db_pwd'   => $value['toolspass'],
			'db_host'  => $value['toolsip'],
			'db_port'  => $value['toolsport'],
			);
		
			$model=new MongoModel($value['toolsname'].'.scrollingnews',null,$connection);
		
			$url = $value['severip'].":".$value['severport'];
			
			$id = intval($val['id']);
			
			if($valid)
			{
				$httpdata['fun']="ChangeScrollingNews";
				$httpdata['add_or_del'] = 'true';
				
				$httpdata['id'] =$id;
				$httpdata['text'] =$val['text'];	
				$httpdata['start_time'] =strtotime($val['start_time']);
				$httpdata['end_time'] =strtotime($val['end_time']);
				$httpdata['period'] =intval($val['period']);

				$httpstr = http($url, $httpdata, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));				
			}
			else{
				
				$url = $value['severip'].":".$value['severport'];
				$httpdata['fun']="ChangeScrollingNews";	
				$httpdata['id'] =$id;
				$httpstr = http($url, $httpdata, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
			}
			
			
			$where['id'] = $id;
			$savedata['valid'] = $valid;
			if($model->where($where)->save($savedata))
			{
				$data['success']=true;
				
			}
			
			$log['id'] = $id;
			$log['valid'] = $valid;
			
			D('Gmlog')->GmAddLog('validScrollbarNotic',json_encode($log));
		}
		
		$data['success'] = 'true';
		echo $this->ajaxReturn($data);
    }
}