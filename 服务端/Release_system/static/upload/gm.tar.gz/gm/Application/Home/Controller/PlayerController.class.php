<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model\MongoModel;
//UI上  用户管理工具  用户信息查询
// 通过http 和 社交服务器 读取用户信息
// 相关字段和 服务器上对应

class PlayerController extends Controller {
	
	//发送邮件
    public function addPlayersMali(){		
		$serverdata = S('SERVER_CONFIG_DATA');
		$value = $serverdata[I('serverid')];
			
		if($value == null)
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_server');
		}
		else{
			$url = $value['severip'].":".$value['severport'];
			
			//定义传递的参数数组
			$data['fun']="SendPlayersMail";
			
			$userid = I('post.roleid');

			$userid = str_ireplace('&quot;','"',$userid);
		
			$data['id'] = $userid;
			$data['text'] = I('post.text');
			$data['name'] = I('post.name');
			$data['title'] = I('post.title');
			
			$postdata = I('post.items');
			$postdata = str_ireplace('&quot;','"',$postdata);
			
			$data['items'] = $postdata;
			
			//定义返回值接收变量；
			$httpstr = http($url, $data, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8;"));
		}
		
		
		//LOG记录
		D('Gmlog')->GmAddLog('addmail',json_encode($data));
		
		echo $this->ajaxReturn($httpstr);
    }
	
	//发送邮件
    public function addMail(){
		$postdata = I('post.items');

		$postdata = str_ireplace('&quot;','"',$postdata);
		
		$serverdata = S('SERVER_CONFIG_DATA');
		$value = $serverdata[I('serverid')];
			
		if($value == null)
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_server');
		}
		else{
			$url = $value['severip'].":".$value['severport'];
			
			//定义传递的参数数组
			$data['fun']="SendPlayerMail";
			$data['id'] = I('post.userid');
			$data['text'] = I('post.text');
			$data['name'] = I('post.name');
			$data['title'] = I('post.title');
			$data['items'] = $postdata;
			
			//定义返回值接收变量；
			$httpstr = http($url, $data, 'POST', array("Content-type: application/x-www-form-urlencoded; charset=utf-8"));
			
			//LOG记录
			D('Gmlog')->GmAddLog('addmail',json_encode($data));
		}
			
		echo $this->ajaxReturn($httpstr);
    }
	
	//查询账号
	public function getAccountInfo($acc_id){
		$data['data'] = array();
		$accserver = S('OTHERSERVER_CONFIG_DATA');
		
		$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $accserver['accdbuser'],
					'db_pwd'   => $accserver['accdbpass'],
					'db_host'  => $accserver['accdbip'],
					'db_port'  =>$accserver['accdbport'],
					);
		 ini_set('mongo.long_as_object', 1);
		$model=new MongoModel($accserver['accdbname'].'.account',null,$connection);
        
		$where['acc_id'] = $acc_id;
		
		$model->getCollection()->createIndex(array('acc_id' => 1));
    	$result = $model->where($where)->select();
		//$result= $model->getLastSql();
		
    	foreach ($result AS $key)
    	{   
		   
    		$datas = $key;
           // $listdata["acc_id"] = $key["acc_id"]->value;  
        	//$datas = $listdata;
      }
	  //var_dump($datas);
		//die;
		return $datas;
	}
	
	
	//查询玩家
	public function getInfo(){	
	//$data['data'] = array();
				$data['success']=false;
			   
				$serverdata = S('SERVER_CONFIG_DATA');
												
				$value = $serverdata[I('serverid')];

				$connection = array(
					'db_type'  => 'mongo',
					'db_user'  => $value['playeruser'],
					'db_pwd'   => $value['playerpass'],
					'db_host'  => $value['playerip'],
					'db_port'  => $value['playerport'],
					);
				ini_set('mongo.long_as_object', 1);
				$model=new MongoModel( $value['playername'].'.role',null,$connection);

				$where = array();
	if (I('idtype')=="acc_id")
			{
					$where['acc_id'] = I('choseid');
					$model->getCollection()->createIndex(array('role_id' => 1)); 
					$result = $model->where($where)->select();
					
					foreach ($result AS $key)
					{   
						$listdata = $key;
						$date= $key["last_logout_time"]->value;
						$listdata["last_logout_time"] = date('Y-m-d H:i:s',$date);
						$data1= $listdata;
					}
					$datas = $this->getAccountInfo($data1["acc_id"]);
					$data2['data'] = $datas + $data1;
					$data2['success']=true;
					echo $this->ajaxReturn($data2);
				}
	if (I('idtype')=="role_id")
			{
					$where['role_id'] = I('choseid');
					$model->getCollection()->createIndex(array('role_id' => 1)); 
					$result = $model->where($where)->select();
					
					foreach ($result AS $key)
					{   
						$listdata = $key;
						$date= $key["last_logout_time"]->value;
						$listdata["last_logout_time"] = date('Y-m-d H:i:s',$date);
						$data1= $listdata;
					}
					$datas = $this->getAccountInfo($data1["acc_id"]);
					$data2['data'] = $datas + $data1;
					$data2['success']=true;
					echo $this->ajaxReturn($data2);
				}
       if(I('idtype') == "name")
	    {
	    		$where['name']=I('choseid');
					$model->getCollection()->createIndex(array('name' => 1)); 
					$result = $model->where($where)->select();
					foreach ($result AS $key)
				{   
					$listdata = $key;
					$date= $key["last_logout_time"]->value;
					$listdata["last_logout_time"] = date('Y-m-d H:i:s',$date);
					$data1= $listdata;
				}

				$data3 = $this->getAccountInfo($data1["acc_id"]);
				$data6['data']= $data3+$data1;
				$data6['success']=true;
				echo $this->ajaxReturn($data6);
		}

    }
	//查询玩家
	public function getAccInfo(){	
		//定义一个要发送的目标URL；		
		if(I('post.namelist') == "")
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_playername');
		}
		else{
			$serverdata = S('SERVER_CONFIG_DATA');
			$value = $serverdata[I('server')];
		
			if($value == null)
			{
				$httpstr['success'] = false;
				$httpstr['errorMessage'] = L('error_server');
			}
			else{
				$url = $value['severip'].":".$value['severport'];
				
				//定义传递的参数数组；
				$data['fun']="GetPlayerAccInfo";
				//$data['namelist']=I('namelist');
		
				$postdata = I('post.namelist');
				$postdata = str_ireplace('&quot;','"',$postdata);
				
				$data['namelist']=$postdata;
				//定义返回值接收变量；
				$httpstr = http($url, $data, 'POST', array("Content-type: text/html; charset=utf-8"));
				
				D('Gmlog')->GmAddLog('GetPlayerAccInfo',json_encode($data));
			}
		}
		
		echo $this->ajaxReturn($httpstr);
    }
	
	//重置账号
	public function rechargPlayerPwd(){

		if(I('playerroleid') == "")
		{
			$httpstr['success'] = false;
			$httpstr['errorMessage'] = L('error_playername');
		}
		else{
			$accserver = S('OTHERSERVER_CONFIG_DATA');
			$url = $accserver['accseverip'].":".$accserver['accseverport'];
			
			//$url = C('acc_ip').":".C('acc_port');
			//定义传递的参数数组；
			$data['fun']="RechargePlayerPwd";
			$data['playerroleid']= I('playerroleid');
		
			//定义返回值接收变量；
			$httpstr = http($url, $data, 'POST', array("Content-type: text/html; charset=utf-8"));
		
			D('Gmlog')->GmAddLog('RechargePlayerPwd',json_encode($data));
		}
		
		echo $this->ajaxReturn($httpstr);
    }
   
}