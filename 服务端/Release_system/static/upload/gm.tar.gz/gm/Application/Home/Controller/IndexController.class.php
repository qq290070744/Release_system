<?php
namespace Home\Controller;
use Think\Controller;
use Think\Csv;

class IndexController extends AuthController {
    public function index(){
    	$this->display();
		
		//phpinfo();
    }
    
    public function main(){
    	$this->assign('username',session('user_auth')['username']);
    	$this->assign('login',M('member')->field('login')->where(array('uid'=>UID))->find()['login']);
    	$this->assign('last_login_time',date('Y-m-d h-m-s',M('member')->field('last_login_time')->where(array('uid'=>UID))->find()['last_login_time']));
    	$this->display();
    }
	
    
    //切换 thinkphp 语言
	public function lang(){
		//切换语言
		switch(I('get.lang')){
            case 'zh_CN':
                cookie('think_language','zh-cn'); 
                break;
            case 'en':
                cookie('think_language','en-us');
                break;
			case 'zh_TW':
                cookie('think_language','zh-tw');
                break;
			case 'vn':
				cookie('think_language','pt-br');
				break;
        }   
   
    }
    
    //前台发过来的缓存
    public function saveCSV(){
    	
    	$postdata = I('post.title');
    	
    	$postdata = str_ireplace('&quot;','"',$postdata);
    	
    	$csv_title = json_decode($postdata);
    	
    	$postdata = I('post.data');
    	 
    	$postdata = str_ireplace('&quot;','"',$postdata);
    	
    	$csv_date = json_decode($postdata);
    	
    	S('CSV_DATA',$csv_date);
    	
    	S('CSV_TITLE',$csv_title);
    	
    	$res['success']='true';
    	echo $this->ajaxReturn($res);
    }
    
    
   //接上一步 缓存成功以后 生成 csv
    public function exportCSV()
    {
    	$csv=new Csv();
    	$csv->put_csv(S('CSV_DATA'),S('CSV_TITLE'));
    }
}