Ext.define('admin.view.layout.Main',{
	extend: 'Ext.tab.Panel',
	initComponent: function(){
		Ext.apply(this,{
			itemId: 'tabCenter',
			region: 'center',
			deferredRender: false,	// deferredRender: false //重新渲染
			autoDestroy: false,		// 关闭后再打开就不显示的问题经解决
			activeTab: 0,
			items:[{
				id: 'HomePage',
				title: gm_string.homepage,
				items:[
					{
						xtype:'panel',
						margin:5,
						bodyPadding:5,
						//src="'+'http://www.baidu.com'+'"
						html:'<iframe scrolling="auto" frameborder="0" width="100%" height="100%" src="Application/Home/View/Index/main.html"> </iframe>'
						
					},
				]
			}]
		});
		this.callParent(arguments);
	}
});