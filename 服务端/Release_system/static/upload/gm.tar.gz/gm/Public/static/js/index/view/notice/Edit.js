Ext.define('admin.view.notice.Edit',{
	extend:'Ext.window.Window',
	alias:'widget.noticeEdit',
	title:gm_announce.edit,	
	layout:'fit',
	resizable : false,
	autoShow:true,
	initComponent:function(){
		this.items=[
			{
				xtype:'form',
				bodyPadding : 5,
				fieldDefaults:{
					labelAlign :'left',
					labelWidth : 120,
					allowBlank : false
				},
				items:[
					{
						xtype:'textfield',
						name:'title',
						fieldLabel:gm_announce.title
					},
					{
						xtype:'textarea',
						name:'text',
						fieldLabel:gm_announce.content,
						height: 260,
						width:400
					},					
					{
						xtype:'checkboxfield',
						name:'valid',
						fieldLabel:gm_announce.ifactive,
						inputValue:1,
						uncheckedValue:0
					},
				]
			}
		];
		this.buttons=[
			{text:gm_btnstring.EditSave,action:'noticeCreateBtn'}
		];
		this.buttonAlign='center',
		this.callParent(arguments);
	}
})