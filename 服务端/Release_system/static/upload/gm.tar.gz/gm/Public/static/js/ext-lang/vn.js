﻿var gm_time_form = {};
gm_time_form.date = 'Y-m-d h:m:s'
gm_time_form.time = 'Y-m-d'
gm_time_form.dates = 'Y-m-d H:i:s'

var gm_string = {};
gm_string.gmmanagertool = 'GM quản lý';
gm_string.exits_sys = 'Thoát';
gm_string.homepage = 'Trang chủ';
gm_string.order_id = 'Số request';
gm_string.channel = 'Hệ điều hành';
gm_string.group = 'Nhóm sv';
gm_string.chargermb = 'Số lượng nạp';
gm_string.roleid = 'ID người chơi';
gm_string.time = 'Thời gian';
gm_string.serverselect = 'Chọn sv';
gm_string.channelselect = 'Chọn hệ điều hành';
gm_string.startdate = 'Thời gian bắt đầu';
gm_string.enddate = 'Thời gian kết thúc';
gm_string.rolename = 'ID người chơi';
gm_string.areaselect = 'Chọn địa điểm';
gm_string.createdata = 'Tạo dữ liệu';
gm_string.order_type = 'Trạng thái đơn';
gm_string.order_log = 'Log đơn';
gm_string.product_id = 'id vật phẩm';


gm_string.Luckyroller= '幸运转盘';


gm_string.title = 'Sửa tin tức sv';
gm_string.serverarea = 'Khu vực sv';
gm_string.serverid = 'ID server';
gm_string.servername = 'Tên nhóm sv';
gm_string.serverip = 'Địa chỉ server';
gm_string.serverpost = 'Cổng server';
gm_string.serverlogdbip = 'Log DB ip';
gm_string.serverlogdbport = 'Log DB port';
gm_string.serverlogdbuser= 'Log DB Người dùng';
gm_string.serverlogdbpass= 'Log DB Pass';
gm_string.serverlogdbname = 'Log DB Tên';
gm_string.servertoolsip = 'Set DB địa chỉ';
gm_string.servertoolsport = 'Set DB port';
gm_string.servertoolsuser = 'Set DB người dùng';
gm_string.servertoolspass = 'Set DB pass';
gm_string.servertoolsname = 'Set DB tên';

gm_string.serverplayerip ='Địa chỉ DB người chơi';
gm_string.serverplayerport ='Port DB người chơi';
gm_string.serverplayeruser ='User DB người chơi';
gm_string.serverplayerpass ='Pass DB người chơi';
gm_string.serverplayername ='Tên DB người chơi';

gm_string.accserverip = 'acc server trả phí';
gm_string.accserverport = 'acc server port';
gm_string.accdbip = 'accDB trả phí';
gm_string.accdbport = 'accDB port';
gm_string.accdbuser = 'accDB acc';
gm_string.accdbpass = 'accDB Password';
gm_string.accdbname = 'accDB Tên';


gm_string.paydbip = 'Địa chỉ LogDB trả phí';
gm_string.paydbport = 'Trả phí LogDB port';
gm_string.paydbuser = 'Trả phí LogDB acc';
gm_string.paydbpass = 'Trả phí LogDB Password';
gm_string.paydbname = 'Trả phí LogDB Tên';

gm_string.menu = 'Quản lý đơn hàng';
gm_string.server_manage = 'Quản lý sv';
gm_string.data_staticstic = 'Thống kê số liệu';
gm_string.users_manage = 'Công cụ quản lý người dùng';
gm_string.activity = 'Quản lý hoạt động';
gm_string.redeem_function = 'Tính năng Lễ bao';
gm_string.code_manager = 'Quản lý mã lễ bao';
gm_string.announcement = 'Quản lý thông  báo';
gm_string.charge_manage = 'Quản lý nạp';

gm_string.report = 'report type';

var gm_exchangecode = {};
gm_exchangecode.createexchangecode = 'Tạo GC';
gm_exchangecode.exchangecodenum = 'Số lượng GC';
gm_exchangecode.canuse = 'Có phải có thể sử dụng lại';
gm_exchangecode.type = 'Loại hình';
gm_exchangecode.giftid = 'ID Lễ bao';
gm_exchangecode.gifttype = 'Loại lễ bao';
gm_exchangecode.exchangecode = 'Mã GC';
gm_exchangecode.canrepeat = 'Có phải có thể lặp lại';
gm_exchangecode.user = 'Người dùng';
gm_exchangecode.ifuse = 'Có muốn dùng';
gm_exchangecode.platformid = 'vBulletin Diversion';
gm_exchangecode.totalpay = "Tổng số nạp tiền";
gm_exchangecode.createpaydetail = "生成导流平台报表";
gm_exchangecode.create_detail_time = '报表月份 格式Y-m';

var gm_notice = {};
gm_notice.serverselectnotice = 'hãy chọn một sv';
gm_notice.channelselectnotice = 'Hãy chọn hệ điều hành';
gm_notice.roleidnotic = 'Nhập ID người dùng muốn kiểm tra';
gm_notice.serverarea = 'hãy chọn 1 sv';
gm_notice.prompt = 'Chú ý';
gm_notice.create = 'Đang tạo số liệu, hãy đợi...'; 
gm_notice.deletestr = 'Bạn có muốn xóa những tin này?',
gm_notice.exportstr = 'Đang xuất ra,hãy chờ...',
gm_notice.managestr = 'Đang xử lý số liệu, hãy đợi...',
gm_notice.load= 'Đang lấy số liệu, hãy đợi...'; 
gm_notice.mail='Gửi thư thành công!';
gm_notice.createstr='Tạo data thành công,hãy kiểm tra lại data';
gm_notice.recharge_playerPwd = 'Xác nhận reset pass người chơi và gửi đến hòm mail của người chơi';
gm_notice.scrollberup='Bạn có muốn post/hạ tin này không？';

var gm_btnstring = {};
gm_btnstring.search = 'Kiểm tra';
gm_btnstring.serverAdd = 'Sv mới thêm';
gm_btnstring.serverDelete = 'Xóa sv';
gm_btnstring.accserveredit = '其他服务器配置';
gm_btnstring.EditSave = 'Lưu';
gm_btnstring.EditClose = 'Hủy';
gm_btnstring.create = 'Tạo';
gm_btnstring.delete = 'Xóa';
gm_btnstring.keyword = 'Nhập từ khóa tìm kiếm';
gm_btnstring.import_users = 'Đổ người chơi vào';
gm_btnstring.confirm = 'Xác định';
gm_btnstring.add = 'Thêm';
gm_btnstring.clear = 'Xóa';
gm_btnstring.import = 'Đổ vào';
gm_btnstring.upanddown = 'Cho lên/xuống';

gm_btnstring.exportbtn = 'Xuất thành csv';
gm_btnstring.create = 'Tạo';
gm_btnstring.createdately = 'Tạo báo cáo theo thời gian';
gm_btnstring.createdaily = 'Tạo báo cáo theo ngày';
var gm_probability ={};
gm_probability.import_datas = 'Xác suất thẻ rút ';//抽卡概率
gm_probability.card_id = 'Thẻ ID';//卡牌ID
gm_probability.percent = 'Xác suất: Tỷ lệ phần trăm';//概率：百分比
gm_probability.sendAll = 'chuyển giao';//发送
gm_probability.start_time = 'Bao nhiêu ngày';//多少天数
gm_probability.stop_time = '结束时间 格式Y-m-d H:i:s';//
gm_probability.import = 'nhập';//导入
gm_probability.card_probability = 'thẻ xác suất';//卡牌概率
gm_probability.add = 'thêm vào';//添加
gm_probability.delete = 'xóa bỏ';//删除
gm_probability.clear = 'tất cả Xóa';//全部清空
gm_probability.success = 'gửi thành công';//发送成功
gm_probability.time = 'Vui lòng chọn thời gian';//请选择时间
gm_probability.servererror = 'Vui lòng chọn một máy chủ';//请选择一个服务器
gm_probability.failure = 'Không gửi';//发送失败
var gm_common = {};
gm_common.displaymsg = 'Hiển thị {0} - {1} tin，tổng cộng {2} tin';
gm_common.emptymsg = 'Ko có số liệu';
gm_common.number = 'Số';
gm_common.username = 'Tên người dùng';
gm_common.pwd = 'pass';
gm_common.pwd_new = 'Pass mới';
gm_common.pwd_new_empty = 'pass mới không được để trống';
gm_common.pwd_new_too_long = 'Pass mới không quá 12 kí tự';
gm_common.pwd_confirm = 'Xác nhận pass';
gm_common.pwd_confirm_empty = 'Xác nhận pass không được để trống';
gm_common.pwd_old_too_long = 'Pass cũ không quá 12 kí tự';
gm_common.pwd_different = 'Hai lần nhập pass không giống nhau';
gm_common.area = 'Khu vực';
gm_common.username_request = 'Tên người dùng phải từ 5~16 kí tự';
gm_common.userid = 'ID người dùng';
gm_common.time = 'Thời gian';
gm_common.opertype = 'Loại thao tác';
gm_common.params = 'Tham số';
gm_common.searchname = 'Hãy nhập người dùng bạn muốn kiểm tra';
gm_common.title = 'Chú ý';
gm_common.content = 'Nội dung';
gm_common.newmsg = 'Tin mới thêm';
gm_common.delmsg = 'Xóa tin';
gm_common.level = 'Lv';
gm_common.viplevel = 'Cấp VIP';
gm_common.user_num = 'Số người';
gm_common.recommend = 'Ghi chú';
gm_common.send_resource = 'Phát tài nguyên';
gm_common.money = 'Vàng';
gm_common.diamond = 'Gem';
gm_common.charge_diamond = 'Tổng số Gem nạp';
gm_common.friendpoint = 'Điểm thân thiện';
gm_common.log_msg = 'log tin tức';
gm_common.log_type = 'Loại log';
gm_common.operation_relative = 'Thao tác liên quan';
gm_common.operation = 'Thao tác';
gm_common.user_edit = 'Sửa người dùng';
gm_common.obj_edit = 'Sửa vật phẩm';
gm_common.obj_type = 'Loại vật phẩm';
gm_common.obj_num = 'Số lượng vật phẩm';
gm_common.obj_id = 'ID vật phẩm';
gm_common.obj_quality = 'Phẩm chất vật phẩm';
gm_common.obj_level = 'Lv vật phẩm';
gm_common.tip = 'Chú ý';
gm_common.search_type = 'Loại hình check';
gm_common.search_condition = 'Điều kiện kiểm tra';
gm_common.search_request = 'Nhập tên người dùng muốn xuất, phải cách bởi dấu";"';

gm_common.recharge_playerPwd = 'Reset pass người chơi';
gm_common.player_acc = 'Acc';
gm_common.player_info = 'Thông tin cơ bản người chơi';
gm_common.player_channel = 'Platform đăng nhập';

var gm_statistics = {};
gm_statistics.date = 'Ngày';
gm_statistics.reguser = 'Đăng ký';
gm_statistics.tomorrowdelay = 'Lưu lại ngày 2';
gm_statistics.thirddaydelay = 'Lưu lại sau 3 ngày';
gm_statistics.forthdaydelay = 'Lưu lại sau 4 ngày';
gm_statistics.fifthdaydelay = 'Lưu lại sau 5 ngày';
gm_statistics.sixthdaydelay = 'Lưu lại sau 6 ngày';
gm_statistics.seventhdaydelay = 'Lưu lại sau 7 ngày';
gm_statistics.fifteendaydelay = 'Lưu lại sau 15 ngày';
gm_statistics.thirtydaysdelay = 'Lưu lại sau 30 ngày';
gm_statistics.login = 'Thống kê người chơi đăng nhập';
gm_statistics.online = 'Thống kê người chơi ol';
gm_statistics.new_user = 'Thống kê người chơi mới';

gm_statistics.login_user = 'Acc đăng nhập';
gm_statistics.charge_user = 'Acc nạp';
gm_statistics.max_online = 'PCU';
gm_statistics.consumer_ingot = 'NB tiêu';
gm_statistics.max_online_time = 'Thời gian Ol max';

var gm_limit_account = {};
gm_limit_account.sequence = 'Trình tự';
gm_limit_account.limit_account_time = 'Thời gian đóng acc';
gm_limit_account.limit_account_deadtime = 'Thời gian kết thúc đóng acc';
gm_limit_account.limit_account_gm = 'Người đóng acc';
gm_limit_account.limit = '封停';
gm_limit_account.limit_release = 'Dỡ bỏ';
gm_limit_account.limit_account_list = 'Tên người chơi cần đóng acc';
gm_limit_account.limit_account_request = 'Nhập tên người chơi cần thao  tác,ngăn cách bằng dấu ";"';
gm_limit_account.limit_account_period = 'Thời gian đóng acc(phút)';
gm_limit_account.limit_account_immediatly = 'Đóng acc người chơi(có hiệu lực ngay)';
gm_limit_account.isKickout = '是否踢玩家下线';
gm_limit_account.isCleanRank = '是否清除玩家排行';

var gm_announce = {};
gm_announce.newsid = '活动公告';
gm_announce.edit = 'Sửa thông cáo đăng nhập';
gm_announce.id = 'id công cáo';
gm_announce.title = 'Chú ý công cáo';
gm_announce.content = 'Nội dung công cáo';
gm_announce.ifactive = 'Có muốn kích hoạt';
gm_announce.active = 'Kích hoạt';
gm_announce.start_time = 'Thời gian bắt đầu';
gm_announce.stop_time = 'Thời gian kết thúc';
gm_announce.period = 'Cách thời gian';

var gm_mail = {};
gm_mail.title = 'Người chơi gửi tài nguyên';
gm_mail.mailtitle = 'Chú ý thư';
gm_mail.deputy_mailtitle = 'Tiêu đề phụ thư';
gm_mail.content = 'Nội dung thư';
gm_mail.appendix_list = 'Danh sách đính kèm';
gm_mail.send_res = 'Người chơi gửi tài nguyên';
gm_mail.tip_delete = 'Xác nhận xóa những tin tức này không？';
gm_mail.tip_choose_delete = 'Hãy chọn số liệu muốn xóa';
gm_mail.send = 'Gửi';

var gm_scollbar = {};
gm_scollbar.title = 'Sửa công cáo';
gm_scollbar.content = 'Nội dung công cáo';
gm_scollbar.start_time = 'Thời gian bắt đầu cách thức Y-m-d H:i:s';
gm_scollbar.stop_time = 'Thời gian kết thúc cách thức Y-m-d H:i:s';
gm_scollbar.period = 'Thời gian giãn cách(giây)';
gm_scollbar.ifactive = 'Có muốn kích hoạt';

var gm_user_oper = {};
gm_user_oper.user_no = 'Số hiệu người dùng';
gm_user_oper.user_type = 'Loại người dùng';
gm_user_oper.new_user = 'Người dùng mới thêm';
gm_user_oper.del_user = 'Xóa người dùng';
gm_user_oper.keyword = 'Nhập từ khóa tìm kiếm';

var gm_error = {};
gm_error.error = 'Chú ý sai';
gm_error.servererror = 'Hãy chọn sv';
gm_error.deletestr = 'Hãy chọn tin tức bạn muốn xóa';
gm_error.limit ='Nhập tên người dùng muốn khóa acc';
gm_error.noserver='Kết nối sv thất bại';
gm_error.findplayer='Chọn kiểm tra người chơi';
gm_error.mailerror='Số lượng đính kèm không lớn hơn 5';
gm_error.playername = 'Nhập tên người chơi muốn gửi thư';
gm_error.playertoomuch = 'Tên nhập vào quá nhiều,chỉ khống chế trong 20 người';
gm_error.scrollbar = 'Trạng thái kích hoạt không thể sửa';
gm_error.scrollbarup='hãy chọn tin bạn muốn post/hạ';

gm_error.exporterr='Copy số liệu thành công!';
gm_error.noplayer='Danh sách người chơi trống!';

var gm_channel = [  
    ['-1', 'toàn bộ hệ điều hành'],  
    ['1', 'mặc định'],  
    ['2', 'Kết nối thông dụng'],
	['3', 'QQ ứng dụng bảo'],
	['4', 'wechat'],
	['5', 'Xiaomi JinShanyun'],
	['6', 'IOS'],
	['7', 'anysdk'],
	['8', 'Dùng nhanh'],
	['9', 'itools'],
	['10', 'facebook'],
	['11', '台湾'],
	['12', 'google-play'],
	['13', '越南'],
];

gm_channel.all = '全平台';



gm_mail.allplayer = 'Tất cả người chơi';
gm_mail.mailValidity = 'Hiệu lực thư';
gm_mail.allmail = 'Danh sách thư gửi toàn server';

gm_mail.userlist = 'Danh sách người nhận';
gm_mail.allmailstr = 'Xác nhận gửi thư toàn server';

var gm_activity ={};
gm_activity.activitylist = 'Danh sách hoạt động';
gm_activity.push = 'Push message';
gm_activity.continuetime = 'Thời gian duy trì(p)';
gm_activity.isRepeat = 'Có lặp lại không';
gm_activity.repeatType = 'Loại thời gian lặp lại';
gm_activity.repeatTime = 'Thời gian lặp lại(p)';
gm_activity.system = 'Hệ thống liên quan';
gm_activity.acttype = 'Loại hoạt động';
gm_activity.systemsub = 'Hệ thống con của hệ thống liên quan';

gm_activity.nextstarttime = 'Thời gian mở lượt hoạt động sau';

gm_activity.pushtype = 'Loại push';
gm_activity.pushtime = 'Thời gian push(p)';
gm_activity.pushtext = 'Nội dung push';
gm_activity.pushinerval = 'Quãng push(s)';
gm_activity.pushcontinue = 'Thời gian push(p)';

gm_activity.editactivity = 'Thêm hoạt động';

var gm_rank = {};
gm_rank.id_ = 'id người chơi';
gm_rank.num = 'Số lượng';
gm_rank.ranktype='Loại xếp hạng';
gm_rank.rankcoin='Loại tiền';

var gm_addredeem ={};
gm_addredeem.id = 'Giftcode'
gm_addredeem.name = 'Thêm đạo cụ';
gm_addredeem.nameid = 'ID đạo cụ';
gm_addredeem.count = 'Số lượng (cái)';
gm_addredeem.redeem = 'Chọn đạo cụ';
gm_addredeem.chooseredeem = 'tên đạo cụ';
gm_addredeem.type = 'Loại đạo cụ';
gm_addredeem.isrepeat = 'Có thể dùng lặp lại không';
gm_addredeem.Sycee = 'Nguyên bảo (cái)';
gm_addredeem.redeemname = 'Tên Lễ bao';
gm_addredeem.redeemcount ='Số lượng Lễ bao (cái)';
gm_addredeem.create = 'Submit';
gm_addredeem.cancel = 'Hủy';
gm_addredeem.addredeems = 'Tên Lễ bao';
gm_addredeem.redeemsname = 'Thêm Lễ bao';
gm_addredeem.starttime = 'Thời gian bắt đầu';
gm_addredeem.audit = 'Duyệt';
gm_addredeem.getfile = 'Nhận thông tin';
gm_addredeem.addredeemsto = 'Hãy thêm Lễ bao';
gm_addredeem.startdate = 'Thời gian bắt đầu còn hiệu lực';
gm_addredeem.endtime = 'Thời gian kết thúc';
gm_addredeem.user = 'Người dùng';
gm_addredeem.Items = 'Đạo cụ';
gm_addredeem.deleteredeem = 'Xóa giftcode';
gm_addredeem.redeemcdk = 'Nhập giftcode';

var gm_discountcard = {};
gm_discountcard.discounts = 'Hãy chọn tỉ lệ giảm';
gm_discountcard.make = 'Hãy chọn tỉ lệ ở khoảng giữa 0 và 1';
gm_discountcard.discount = 'Tỉ lệ giảm';
gm_discountcard.starttime = 'Bắt đầu';
gm_discountcard.starttimes = 'Hãy chọn thời gian bắt đầu';
gm_discountcard.endtime = 'send';

var gm_roller = {};
gm_roller.cost = '单次转盘消耗';
gm_roller.boomrate='爆炸几率';
gm_roller.boommax='能量槽大小';
gm_roller.energymax='转化成能量比率上限';
gm_roller.energymin='转换成能量比率下限';
gm_roller.starttime='活动开始时间';
gm_roller.endtime='活动结束时间';
gm_roller.mail_title='邮件标题';
gm_roller.mail_name='邮件名字';
gm_roller.mail_text='邮件内容';
gm_roller.roller_items='转盘物品表';
gm_roller.starttime='开始时间';
gm_roller.endtime='结束时间';
gm_roller.type='类型';
gm_roller.servererror='请选择一个服务器';
gm_roller.energyerror='转换成能量比率上线 大于 转换成能量比率下限';
gm_roller.energyerrors='转换成能量比率上线相加转换成能量比率下限为1';
gm_roller.rate='概率';
gm_roller.level='等级默认为0';