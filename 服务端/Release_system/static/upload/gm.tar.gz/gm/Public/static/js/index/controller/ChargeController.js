Ext.define('admin.controller.ChargeController',{
	extend: 'Ext.app.Controller',
    models: ['ChargeModel'],
    stores: ['ChargeStore','ChargeLogStore'],
	views:['charge.List','charge.Log','charge.Edit'],
	refs: [{
            ref: 'ChargeList',
            selector: 'chargeList'
    },{
        ref: 'ChargeLog',
        selector: 'chargeLog'
    }],
    init: function () {
        this.control({
			'chargeList button[action=chargeSearch]'     :  {click: this.chargeSearch},
			'chargeLog button[action=chargelogSearch]'     :  {click: this.chargelogSearch},
			'chargeLog button[action=chargeFillOrders]'     :  {click: this.chargeFillOrders},
			'chargeEdit button[action=doChargeFillOrders]'     :  {click: this.doChargeFillOrders},
		});
    },
	
	chargeSearch:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#server').getValue();
		var channelid = grid.down('#channelid').getValue();
		var roleid = grid.down('#searchroleid').getValue();
		
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#enddate').getValue()), Ext.Date.HOUR, 24);
		
		
		var store = grid.getStore();
		//store  = this.getStore('ChargeStore');

		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = { 
					serverid : serverid,
					channelid : channelid,
					roleid:roleid,
					startdate:startdate,
					enddate:enddate,
					};
			Ext.apply(store.proxy.extraParams, new_params);
		});	
		
        store.load({});
	},
	
	chargelogSearch:function(button){
		var grid = button.up('panel');

		var roleid = grid.down('#searchroleid').getValue();
		var orderid = grid.down('#orderid').getValue();
		
		var store = grid.getStore();
		//store  = this.getStore('ChargeStore');

		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = { 
					orderid : orderid,
					roleid:roleid,
					};
			Ext.apply(store.proxy.extraParams, new_params);
		});	
		
        store.load({});
	},

	chargeFillOrders:function(button){
		Ext.widget('chargeEdit');
	},

	doChargeFillOrders:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();

        var store  = this.getStore('CodeTotalPayStore');	
		
		//验证有没有修改
		if(form.getForm().isValid()){
			if(record){
				record.set(values);
				win.close();
				store.sync();
				store.load();
			}
			else
			{
				form.submit({
					url:'/gm/index.php?s=/Home/Charge/fillOrders.html',
					waitMsg : gm_notice.create,
					method: 'POST',
					params: values,
					success: function(form, action) {
						if(action.result.success == 'true')
						{
							win.close();
						}
						else{
							Ext.Msg.alert(gm_error.error, action.result.errorMessage);
						}

					},
					failure: function(form, action) {
						Ext.Msg.alert(gm_error.error, action);
					},		
				});
			}
		}
		else{
			win.close();
		}
	},
});