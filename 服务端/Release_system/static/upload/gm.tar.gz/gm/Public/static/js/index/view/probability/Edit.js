Ext.define('admin.view.probability.Edit',{
	extend:'Ext.window.Window',
	alias : 'widget.probabilityEdit',
	title:gm_probability.import_datas, //
	//store: 'ProbabilityStore',
	layout:'fit',
	resizable : false,
	autoShow:true,
    initComponent: function(){
		this.fieldDefaults={
			allowBlank : false,
			labelAlign :'right'
		},
		//this.bodyPadding=10,
		this.items=[
		{
			xtype:'form',
			bodyPadding : 5,
			fieldDefaults:{
				labelAlign :'left',
				labelWidth : 120,
				allowBlank : false,
			},
			//defaultType:'textfield',
			items:[
			    {
					xtype:'combobox',
					name: 'cardid',
					fieldLabel: gm_probability.card_id,
				    triggerAction: 'all',//����������ť��ʾȫ������  
					//onclick:'all',
					store : {
				    	autoLoad: true,
				    	fields:['id','name'],
			    		proxy: {
				    	    type: 'ajax',
				    	    url: '/gm/index.php?s=/Home/ComboBox/getCardIDComboBox.html' //�����ǲ�������˳��д,�������Դ���ڵ�һ��������select��ʱ��load��
					},
					autoDestroy: true,
					},
					displayField:'name',
					valueField:'id',
					queryMode: 'local', 
					forceSelection : true, 
					typeAhead : true,
					handleHeight : 10,
					autoDestroy: false,
			    },{
					xtype:'textfield',
					name:'probability',
					fieldLabel:gm_probability.percent,
				},
			    ],	
		},],
		this.bbar=[
			'->',
			{text: gm_btnstring.EditSave,iconCls: 'Reportdisk',action: 'itemprobilitysavebtn'},
			'->'
		],
		this.buttonAlign='center',
	    this.callParent(arguments);
		}
});