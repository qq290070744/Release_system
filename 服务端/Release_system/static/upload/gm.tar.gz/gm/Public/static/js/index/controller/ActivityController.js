Ext.define('admin.controller.ActivityController',{
	extend: 'Ext.app.Controller',
    models: ['ActivityModel'],
    stores: ['ActivityStore'],
	views:['activity.List','activity.Edit'],
	refs: [{
            ref: 'ActivityList',
            selector: 'activityList'
    }],
    init: function () {
        this.control({
		//	'activityList'                       		  :  {itemdblclick:this.itemdblclick},
			'activityList button[action=activitySearch]'     :  {click: this.activitySearch},
			'activityList button[action=activityCreate]'     :  {click: this.activityCreate},
			'activityList button[action=activityDelete]'     :  {click: this.activityDelete},
			'activityEdit button[action=activityCreateBtn]'     :  {click: this.activityCreateBtn},
		});
    },
	
   // itemdblclick:function(grid, record, item,index, e, eOpts){
		//var view=Ext.widget('activityEdit');
		//view.down('form').loadRecord(record);
		//this.down('ckeditor').setValue(jsonObj.content);
	//},
	//˫���¼�
	activityCreate:function(button){
		Ext.widget('activityEdit');
	},
	
	activityCreateBtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();
		
		var store  = this.getStore('ActivityStore');	
		
		//��֤��û���޸�
		if(form.getForm().isValid()){
			if(record){
				record.set(values);
				win.close();
				store.sync();
				store.load();
			}
			else
			{
				form.submit({
				url:'/gm/index.php?s=/Home/Activity/AddActivity.html',
				waitMsg : gm_notice.managestr,
				method: 'POST',
				params: values,
				success: function(form, action) {
					if(action.result.success == 'true')
					{
						store.load({});
						win.close();
					}
					else{
						Ext.Msg.alert(gm_error.error, action.result.errorMessage);
					}
				},
				failure: function(form, action) {
					Ext.Msg.alert(gm_error.error, action);
				},		
				});
			}
		}
		else{
			win.close();
		}
		
		
	},
	
	activitySearch:function(button){
		var grid = button.up('panel');
		var serverid = grid.down('#serverid').getValue();
		if(serverid==null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		var store  = this.getStore('ActivityStore');	
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});		
		store.load({});	
	},

	activityDelete:function(button){
		var grid = this.getActivityList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('ActivityStore');			
		
		if(record.length<=0){
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					store.remove(record);
					store.sync();
					store.load();
				}
			})
		}
	}
});