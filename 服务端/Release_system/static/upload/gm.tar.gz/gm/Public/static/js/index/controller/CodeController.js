Ext.define('admin.controller.CodeController',{
	extend: 'Ext.app.Controller',
    models: ['CodeModel'],
    stores: ['CodeStore'],
	views:['code.List','code.Edit'],
	refs: [{
            ref: 'CodeList',
            selector: 'codeList'
    }],
    init: function () {
        this.control({
			'codeList button[action=codeSearch]'     :  {click: this.codeSearch},
			'codeList button[action=codeCreate]'     :  {click: this.codeCreate},
			'codeEdit button[action=codeCreateBtn]'     :  {click: this.codeCreateBtn},
			'codeEdit button[action=codeCloseBtn]'     :  {click: this.codeCloseBtn},
			'codeList button[action=codeDelete]'     :  {click: this.codeDelete},
			'codeList button[action=codeExport]'     :  {click: this.codeExport},
		});
    },
	
	
	codeCreate:function(button){
		Ext.widget('codeEdit');
	},
	
	codeCloseBtn:function(button){
		button.up('window').close();
	},
	
	codeCreateBtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();
		
		form.submit({
			url:'/gm/index.php?s=/Home/Code/addCode.html',
			waitMsg : gm_notice.create,
			method: 'POST',
			params: values,
			success: function(form, action) {
				if(action.result.success == 'true')
				{
					win.close();
				}
				else{
					Ext.Msg.alert('test001','test001');
					Ext.Msg.alert(gm_error.error, action.result.errorMessage);
				}

			},
			failure: function(form, action) {
				Ext.Msg.alert('test002','test002');
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
		//document.write('<script type="text/javascript" src''' + path + '/ext_all'+(rtl?'-rtl':'$code')+'.js'</script>');
	},
	
	codeSearch:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		var codetype = grid.down('#codetype').getValue();
		var platformid = grid.down('#platformid').getValue();
		var codeuse = Number(grid.down('#codeuse').getValue());
		
		if(serverid==null)
		{
			Ext.Msg.alert('serach test 001','test001');
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		store  = this.getStore('CodeStore');	
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
					codetype : codetype,
					platformid : platformid,
					codeuse : codeuse,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});	
	},

	codeExport:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		var codetype = grid.down('#codetype').getValue();
		var platformid = grid.down('#platformid').getValue();
		var codeuse = Number(grid.down('#codeuse').getValue());
	
		if(serverid==null)
		{
			Ext.Msg.alert('code export test 001','test001');
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		//直接跳转
		window.location.href = '/gm/index.php?s=/Home/Code/exportCode.html&serverid='+serverid+'&codetype='+codetype+'&platformid'+platformid+'&codeuse='+codeuse;
	},
	
	codeDelete:function(button){
		var grid = this.getCodeList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('CodeStore');			
		
		if(record.length<=0){
			Ext.Msg.alert('code delete test001','test001');
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					store.remove(record);
					store.sync();
					store.load();
				}
			})
		}
	}
});