Ext.define('admin.controller.PlayerResController',{
	extend: 'Ext.app.Controller',
	views:['player.Resources','tools.Item','tools.Queryplayer'],
	refs: [{
				ref: 'PlayerRes',
				selector: 'playerRes',
		}
	],
    init: function () {
        this.control({
			'playerRes button[action=sendMailsbtn]'     :  {click: this.sendMailsbtn},
			'playerRes button[action=additem]'     		:  {click: this.additem},
			'playerRes button[action=ImportPlayer]'     :  {click: this.ImportPlayer},
			'playerRes button[action=clearImportPlayer]'     :  {click: this.clearImportPlayer},		
			'playerItem button[action=itemsavebtn]'     :  {click: this.itemsavebtn},
			'queryplayer button[action=queryplayerbtn]'     :  {click: this.queryplayerbtn},
			
			
		});
    },
	
	resEdit:function(grid,record){
		var view=Ext.widget('playerItem');
		view.down('form').loadRecord(record);
	},
	
	additem:function(button){
		var view=Ext.widget('playerItem');
	},
	
	ImportPlayer:function(button){
		var form=button.up('form').getForm();
		var isall = form.findField("isAll").getValue();
		if(!isall)
		{
			var view=Ext.widget('queryplayer');
		}
		
	},
	
	clearImportPlayer:function(button){
		var form=button.up('form').getForm();
		form.findField("userid").setValue('');
	},
	
	queryplayerbtn:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			values = form.getValues();
		
		var str = values['queryitem'];
		str = str.replace(/\n/g, "");
		
		var strlist = str.split(";");
		var namelist = [];	
		for(var i in strlist)
		{
			if(strlist[i] != "")
			{
				namelist.push(strlist[i]);
			}
		}
		if(namelist.length  <= 0 )
		{
			Ext.Msg.alert(gm_error.error, gm_error.playername);
			return;
		}
		
		if(namelist.length > 20)
		{
			Ext.Msg.alert(gm_error.error, gm_error.playertoomuch);
			return;
		}
		
		var datas = [];
		datas['namelist'] = Ext.encode(namelist);
		
		var resform = this.getPlayerRes().getForm();;
		
		form.submit({
			url:'/gm/index.php?s=/Home/Player/getAccInfo',
			waitMsg : gm_notice.managestr,
			method: 'POST',
			params: datas,
			success: function(form, action) {
				if(action.result.success == 'true')
				{
					var role = resform.findField("userid").getValue();
					role = role + action.result.data.roleid;
				
					resform.findField("userid").setValue(role);
				
					var error = action.result.data.error;
					if(error!="")
					{
						Ext.Msg.alert(gm_error.error, error);
					}
					win.close();
				}
				else{
					Ext.Msg.alert(gm_error.error, action.result.errorMessage);
				}

			},
			failure: function(form, action) {
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
	},
	
	
	itemsavebtn:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
			console.log(values);
		var resform = this.getPlayerRes();
		console.log(resform);
		var grid = resform.down("#items");
		console.log(grid);
		var	store  = grid.getStore();
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
				win.close();
			}
	},
	
	sendMailsbtn:function(button){
		
		var form=button.up('form').getForm();	
		
		var datas = form.getValues();
		
		if(datas['serverid'] == "")
		{
			Ext.Msg.alert(gm_notice.prompt, gm_error.servererror);
			return;
		}
		
		var resform = this.getPlayerRes();
		var grid = resform.down("#items");
		var	store =  grid.getStore();
		var list = [];
		
		if(store.getCount() > 5)
		{
			Ext.Msg.alert(gm_notice.prompt, gm_error.mailerror);
			return;
		}
		
        for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}
		
		datas['items'] = Ext.encode(list);		
		
		var isall = form.findField("isAll").getValue();
		if(isall)
		{
			Ext.Msg.confirm(gm_common.tip,gm_mail.allmailstr,function(optional){
				if(optional=='yes'){
					form.submit({
						url:'/gm/index.php?s=/Home/Mail/addAllPlayerMail',
						waitMsg : gm_notice.managestr,
						method: 'POST',
						params: datas,
						success: function(form, action) {
							if(action.result.success == true)
							{
								Ext.Msg.alert(gm_notice.prompt,gm_notice.mail);
							}
							else{
								Ext.Msg.alert(gm_error.error, action.result.errorMessage);
							}
						},
						failure: function(form, action) {
							Ext.Msg.alert(gm_error.error, action);
						},		
					});
				}
			});		
		}
		else
		{

			var strlist = datas['userid'].split(";");
			var rolelist = [];	
			for(var i in strlist)
			{
				if(strlist[i] != "")
				{
					rolelist.push(strlist[i]);
				}
			}
			
			if(rolelist.length > 20)
			{
				Ext.Msg.alert(gm_error.error, gm_error.playertoomuch);
				return;
			}
			
			if(rolelist.length <= 0)
			{
				Ext.Msg.alert(gm_error.error, gm_error.noplayer);
				return;
			}
			
			datas['roleid'] = Ext.encode(rolelist);
			
			form.submit({
				url:'/gm/index.php?s=/Home/Player/addPlayersMali',
				waitMsg : gm_notice.managestr,
				method: 'POST',
				params: datas,
				success: function(form, action) {
					if(action.result.success == 'true')
					{
						Ext.Msg.alert(gm_notice.prompt,gm_notice.mail);
					}
					else{
						Ext.Msg.alert(gm_error.error, action.result.errorMessage);
					}
				},
				failure: function(form, action) {
					Ext.Msg.alert(gm_error.error, action);
				},		
			});
		}
		
	},
	
});