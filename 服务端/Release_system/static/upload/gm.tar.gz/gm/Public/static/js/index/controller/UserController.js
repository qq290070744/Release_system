Ext.define('admin.controller.UserController',{
	extend: 'Ext.app.Controller',
    models: ['UserModel'],
    stores: ['UserStore'],
	views:['user.List','user.Edit'],
	refs: [{
            ref: 'UserList',
            selector: 'userList'
    }],
    init: function () {
        this.control({
			'userList'                              :  {itemdblclick:this.userEdit},
			'userEdit button[action=userEditSave]'  :  {click:this.userEditSave},
            'userList button[action=userAdd]'       :  {click: this.userAdd},
            'userList button[action=userEdit]'       :  {click: this.userEdit},
            'userList button[action=userDelete]'    :  {click: this.userDelete},
            'userEdit button[action=userEditClose]' :  {click: this.userEditClose},
		});
    },
	userEdit:function(grid,record){
		var view=Ext.widget('userEdit');
		view.down('form').loadRecord(record);
	},
	userAdd:function(button){
		var view=Ext.widget('userEdit');
	},
	userEditSave:function(button){
        var win    = button.up('window'),
            form   = win.down('form'),
            record = form.getRecord(),
            values = form.getValues(),
			store  = this.getStore('UserStore'),
			model  = this.getModel('UserModel');
        
        	//var vid = values['id'];
        	var vnewPwd = values['newPwd'];
        	var vconfirmPwd = values['confirmPwd'];  
        	var vusername = values['username'];
        	var vpassword = values['password'];
        	var vstatus = values['status'];
	        var authCheck = Ext.getCmp('auth').items;
	        var vauth = '';
	        var first = 0;
	        for(var i = 0; i < authCheck.length; i++){
	        if(authCheck.get(i).checked){
	        	if(first == 0){
	        		vauth = authCheck.get(i).moduleid;
	        		first = 1;
	        	}
	        	else{
	        		vauth += ',' + authCheck.get(i).moduleid;
	        	}
	        }
	        }
	        //Ext.MessageBox.alert('提示', '您的兴趣是' + values);		
	        
	        
			if(form.getForm().isValid()){
				var new_params = {
						//id:vid,
						username:vusername,
						status:vstatus,
						password:vpassword,
						newPwd:vnewPwd,
						confirmPwd:vconfirmPwd,
						auth:vauth
					};
				if(record){
					//record.set(values);
					record.set(new_params);
				}else{
					record = Ext.create(model);					
					//record.set(values);
					record.set(new_params);
					store.add(record);
				}
				win.close();
				store.sync();
				store.load();
			}
	},
    userDelete: function(button) {
    	var grid = this.getUserList(),
			record = grid.getSelectionModel().getSelection(),
			store = this.getStore('UserStore');			
			if(record.length<=0){
				Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
			}else{
				Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
					if(optional=='yes'){
						store.remove(record);
						store.sync();
						store.load();
					}
				})
			}
    },
	userEditClose:function(button){
		button.up('window').close()
	}
	
});