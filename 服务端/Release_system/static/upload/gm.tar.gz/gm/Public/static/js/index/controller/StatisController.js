Ext.define('admin.controller.StatisController',{
	extend: 'Ext.app.Controller',
    models: ['StatisModel'],
    stores: ['StatisStore'],
	views:['statis.List','statis.Line'],
	refs: [{
            ref: 'statisList',
            selector: 'StatisList'
    }],
    init: function () {
        this.control({
			'statisList button[action=statisSearch]'  :  {click:this.statisSearch},
		});
    },
	

	statisSearch:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#server').getValue();
		var searchtype = grid.down('#searchtype').getValue();
		var channelid = grid.down('#channelid').getValue();
		
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#enddate').getValue()), Ext.Date.HOUR, 24);
			
		store  = this.getStore('StatisStore');

		store.removeAll(); 
		store.currentPage = 1;
        store.load({
                params : {
					serverid : serverid,
					searchtype : searchtype,
					startdate:startdate,
					enddate:enddate,
					channelid:channelid,
                }
            });
	},
});