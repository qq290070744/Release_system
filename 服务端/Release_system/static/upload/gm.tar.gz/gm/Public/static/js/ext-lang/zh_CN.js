var gm_time_form = {};
gm_time_form.date = 'Y年m月d日 h时m分s秒'
gm_time_form.time = 'Y年m月d日'
gm_time_form.dates = 'Y-m-d H:i:s'
var gm_string = {};

gm_string.gmmanagertool = 'GM管理工具';
gm_string.exits_sys = '退出系统';
gm_string.homepage = '首页';
gm_string.order_id = '订单号';
gm_string.channel = '平台';
gm_string.group = '服务器组';
gm_string.chargermb = '充值金额';
gm_string.roleid = '玩家角色ID';
gm_string.accid = '玩家账号ID';
gm_string.time = '时间';
gm_string.online_time = '在线时长(分)';
gm_string.last_logout_time = '上一次在线时间';
gm_string.serverselect = '服务器选择';
gm_string.channelselect = '登陆平台选择';
gm_string.startdate = '起始日期';
gm_string.enddate = '结束日期';
gm_string.areaselect = '地区选择';
gm_string.createdata = '数据生成';
gm_string.order_type = '订单状态';
gm_string.order_log = '订单日志';
gm_string.product_id = '商品id';

gm_string.idname='查询类型';
gm_string.PleaseselectYouWantQuerycontent='请选择你要查询的内容';

gm_string.title = '编辑服务器信息';
gm_string.serverarea = '服务器地区';
gm_string.serverid = '服务器ID';
gm_string.servername = '服务器组名字';
gm_string.serverip = '服务器地址';
gm_string.serverpost = '服务器端口';
gm_string.serverlogdbip = '日志DB地址';
gm_string.serverlogdbport = '日志DB端口';
gm_string.serverlogdbuser= '日志DB用户';
gm_string.serverlogdbpass= '日志DB密码';
gm_string.serverlogdbname = '日志DB名字';
gm_string.servertoolsip = '配置DB地址';
gm_string.servertoolsport = '配置DB端口';
gm_string.servertoolsuser = '配置DB用户';
gm_string.servertoolspass = '配置DB密码';
gm_string.servertoolsname = '配置DB名字';

gm_string.serverplayerip ='玩家DB地址';
gm_string.serverplayerport ='玩家DB端口';
gm_string.serverplayeruser ='玩家DB用户';
gm_string.serverplayerpass ='玩家DB密码';
gm_string.serverplayername ='玩家DB名字';


gm_string.accserverip = '账号服务器地址';
gm_string.accserverport = '账号服务器端口';
gm_string.accdbip = '账号DB地址';
gm_string.accdbport = '账号DB端口';
gm_string.accdbuser = '账号DB用户';
gm_string.accdbpass = '账号DB密码';
gm_string.accdbname = '账号DB名字';

gm_string.paydbip = '付费LogDB地址';
gm_string.paydbport = '付费LogDB端口';
gm_string.paydbuser = '付费LogDB用户';
gm_string.paydbpass = '付费LogDB密码';
gm_string.paydbname = '付费LogDB名字';

gm_string.prepaiddbip = '充值订单DB地址';
gm_string.prepaiddbport = '充值订单DB端口';
gm_string.prepaiddbuser = '充值订单DB用户';
gm_string.prepaiddbpass = '充值订单DB密码';
gm_string.prepaiddbname = '充值订单DB名字';


gm_string.menu = '管理菜单';
gm_string.server_manage = '服务器管理';
gm_string.data_staticstic = '数据统计';
gm_string.users_manage = '用户管理工具';
gm_string.activity = '活动管理';
gm_string.redeem_function = '礼包功能';
gm_string.code_manager = '激活码管理';
gm_string.announcement = '公告管理';
gm_string.charge_manage = '充值管理工具';
gm_string.Luckyroller = '幸运转盘';
gm_string.report = '报表类型';

var gm_exchangecode = {};
gm_exchangecode.createexchangecode = '生成兑换码';
gm_exchangecode.exchangecodenum = '激活码数量';
gm_exchangecode.canuse = '是否可重复使用';
gm_exchangecode.type = '类型';
gm_exchangecode.giftid = '礼包ID';
gm_exchangecode.gifttype = '礼包类型';
gm_exchangecode.exchangecode = '激活码';
gm_exchangecode.canrepeat = '是否可重复';
gm_exchangecode.user = '使用人';
gm_exchangecode.ifuse = '是否使用';
gm_exchangecode.platformid = '导流平台';
gm_exchangecode.totalpay = "充值总额";
gm_exchangecode.createpaydetail = "生成导流平台报表";
gm_exchangecode.create_detail_time = '报表月份 格式Y-m';

var gm_notice = {};
gm_notice.serverselectnotice = '请选择一个服务器';
gm_notice.channelselectnotice = '请选择一个登陆平台';
gm_notice.roleidnotic = '请输入需要查询用户ID';
gm_notice.serverarea = '请选择一个服务器地区';
gm_notice.prompt = '提示';
gm_notice.create = '数据生成中，请稍等...'; 
gm_notice.deletestr = '您确定要删除这些信息吗？',
gm_notice.exportstr = '正在导出 请稍后...',
gm_notice.managestr = '数据处理中，请稍等...',
gm_notice.load= '数据读取中，请稍等...'; 
gm_notice.mail='邮件发送成功!';
gm_notice.createstr='数据生成成功,请重新查询数据';
gm_notice.recharge_playerPwd = '确认重置玩家密码,并发送至用户账号邮箱';

gm_notice.scrollberup='您确定要上/下架这些信息吗？';
var gm_btnstring = {};
gm_btnstring.search = '查询';
gm_btnstring.searchs = '查询此次激活码';
gm_btnstring.serverAdd = '新增服务器';
gm_btnstring.serverDelete = '删除服务器';
gm_btnstring.accserveredit = '其他服务器配置';
gm_btnstring.EditSave = '保存';
gm_btnstring.EditClose = '取消';
gm_btnstring.create = '生成';
gm_btnstring.delete = '删除';
gm_btnstring.keyword = '请输入查询关键词';
gm_btnstring.import_users = '导入玩家';
gm_btnstring.confirm = '确定';
gm_btnstring.add = '添加';
gm_btnstring.clear = '清空';
gm_btnstring.import = '导入';
gm_btnstring.upanddown = '上/下架';
gm_btnstring.exportbtn = '导出成csv';
gm_btnstring.create = '生成';
gm_btnstring.createdately = '生成日期期间报表';
gm_btnstring.createdaily = '生成每日报表';
gm_btnstring.fillorders = '补单';


var gm_common = {};
gm_common.card_id = '卡牌ID',
gm_common.displaymsg = '显示 {0} - {1} 条，共计 {2} 条';
gm_common.emptymsg = '没有数据';
gm_common.number = '编号';
gm_common.username = '昵称';
gm_common.pwd = '密码';
gm_common.pwd_new = '新密码';
gm_common.pwd_new_empty = '新密码不能为空';
gm_common.pwd_new_too_long = '新密码长度不能超过12个字符';
gm_common.pwd_confirm = '确认密码';
gm_common.pwd_confirm_empty = '确认密码不能为空';
gm_common.pwd_old_too_long = '旧密码长度不能超过12个字符';
gm_common.pwd_different = '两次输入的密码不一致';
gm_common.area = '地区';
gm_common.username_request = '用户名必须是5~16位英文字母';
gm_common.userid = '用户ID';
gm_common.time = '时间';
gm_common.opertype = '操作类型';
gm_common.params = '参数';
gm_common.searchname = '请输入需要查询用户名';
gm_common.title = '标题';
gm_common.content = '内容';
gm_common.newmsg = '新增信息';
gm_common.delmsg = '删除信息';
gm_common.level = '等级';
gm_common.viplevel = 'VIP等级';
gm_common.user_num = '人数';
gm_common.recommend = '备注';
gm_common.send_resource = '发放资源';
gm_common.money = '金币';
gm_common.diamond = '钻石';
gm_common.charge_diamond = '充值总钻石';
gm_common.friendpoint = '友情点';
gm_common.log_msg = 'log信息';
gm_common.log_type = '日志类型';
gm_common.operation_relative = '相关操作';
gm_common.operation = '操作';
gm_common.user_edit = '编辑用户信息';
gm_common.obj_edit = '编辑物品信息';
gm_common.obj_type = '物品类型';
gm_common.obj_num = '物品数量';
gm_common.obj_id = '物品ID';
gm_common.obj_quality = '物品品质';
gm_common.obj_level = '物品等级';
gm_common.tip = '提示';
gm_common.search_type = '查询类型';
gm_common.search_condition = '查询条件';
gm_common.search_request = '输入需要导入的玩家名，需要以";" 隔开';

gm_common.recharge_playerPwd = '重置玩家账号密码';
gm_common.player_acc = '账号';
gm_common.player_info = '玩家基础信息';
gm_common.player_channel = '登陆平台';

var gm_statistics = {};
gm_statistics.serverid = '服务器组';
gm_statistics.date = '日期';
gm_statistics.reguser = '注册用户';
gm_statistics.tomorrowdelay = '次日留存';
gm_statistics.thirddaydelay = '三日留存';
gm_statistics.forthdaydelay = '四日留存';
gm_statistics.fifthdaydelay = '五日留存';
gm_statistics.sixthdaydelay = '六日留存';
gm_statistics.seventhdaydelay = '七日留存';
gm_statistics.fifteendaydelay = '十五日留存';
gm_statistics.thirtydaysdelay = '三十日留存';
gm_statistics.login = '登陆用户统计';
gm_statistics.online = '在线人数统计';
gm_statistics.new_user = '新增用户统计';

gm_statistics.login_user = '登陆用户';
gm_statistics.charge_user = '充值用户';
gm_statistics.max_online = '最高在线人数';
gm_statistics.consumer_ingot = '消费元宝';
gm_statistics.max_online_time = '峰值在线时间';

var gm_limit_account = {};
gm_limit_account.sequence = '序列';
gm_limit_account.limit_account_time = '封号操作时间';
gm_limit_account.limit_account_deadtime = '封号结束时间';
gm_limit_account.limit_account_gm = '封号操作人';
gm_limit_account.limit = '封停';
gm_limit_account.limit_release = '解除';
gm_limit_account.limit_account_list = '需要封号玩家名';
gm_limit_account.limit_account_request = '输入需要操作的玩家ID，需要以";" 隔开';
gm_limit_account.limit_account_period = '封号时长(分)';
gm_limit_account.limit_account_immediatly = '封停玩家账号(即可生效)';
gm_limit_account.isKickout = '是否踢玩家下线';
gm_limit_account.isCleanRank = '是否清除玩家排行';

var gm_announce = {};
gm_announce.newsid = '活动公告';
gm_announce.edit = '编辑登陆公告';
gm_announce.serverid = '服务器ID';
gm_announce.id = '公告id';
gm_announce.news = '公告类型';
gm_announce.title = '公告标题';
gm_announce.AnnouncementType = '公告类型';
gm_announce.name = '副标题';
gm_announce.content = '公告内容';
gm_announce.time = '创建公告时间';
gm_announce.ifactive = '是否激活';
gm_announce.active = '激活';
gm_announce.start_time = '开始时间';
gm_announce.stop_time = '结束时间';
gm_announce.period = '间隔';

var gm_mail = {};
gm_mail.title = '玩家发送资源';
gm_mail.mailtitle = '邮件标题';
gm_mail.deputy_mailtitle = '邮件副标题';
gm_mail.content = '邮件内容';
gm_mail.appendix_list = '附件列表';
gm_mail.send_res = '玩家发送资源';
gm_mail.tip_delete = '您确定要删除这些信息吗？';
gm_mail.tip_choose_delete = '请选择要删除的数据';
gm_mail.send = '发送';

var gm_probability ={};
gm_probability.import_datas = '抽卡概率';
gm_probability.card_id = '卡牌ID';
gm_probability.percent = '概率：百分比';
gm_probability.sendAll = '发送';
gm_probability.start_time = '多少天数';
gm_probability.stop_time = '结束时间 格式Y-m-d H:i:s';
gm_probability.import = '导入';
gm_probability.card_probability = '卡牌概率';
gm_probability.add = '添加';
gm_probability.delete = '删除';
gm_probability.clear = '全部清空';
gm_probability.success = '发送成功';
gm_probability.time = '请选择时间';
gm_probability.servererror = '请选择一个服务器';
gm_probability.failure = '发送失败';


var gm_scollbar = {};
gm_scollbar.title = '编辑滚动条公告';
gm_scollbar.content = '公告内容';
gm_scollbar.start_time = '开始时间 格式Y-m-d H:i:s';
gm_scollbar.stop_time = '结束时间 格式Y-m-d H:i:s';
gm_scollbar.period = '间隔时间(秒)';
gm_scollbar.ifactive = '是否激活';

var gm_user_oper = {};
gm_user_oper.user_no = '用户编号';
gm_user_oper.user_type = '用户类型';
gm_user_oper.new_user = '新增用户';
gm_user_oper.del_user = '删除用户';
gm_user_oper.edit_user = '编辑用户';
gm_user_oper.keyword = '请输入查询关键词';

var gm_error = {};
gm_error.error = '错误提示';
gm_error.servererror = '请选择服务器';
gm_error.deletestr = '请选择您要删除的信息';
gm_error.limit ='请正确输入要封号的玩家名';
gm_error.noserver='连接服务器失败';
gm_error.findplayer='请先查找玩家';
gm_error.mailerror='附件数量不能大于5';
gm_error.playername = '请正确输入需要发送的邮件的玩家名';
gm_error.playertoomuch = '输入的名字数量过多 请控制在20以内';
gm_error.scrollbar = '激活状态下无法修改';
gm_error.scrollbarup='请选择您要上/下架的信息';
gm_error.nodata = '查询失败';
gm_error.exporterr='数据重复生成!';
gm_error.noplayer=' 玩家列表为空!';
gm_error.writeserverid='请选择服务器';
gm_error.roleidnames='选择玩家id或用户名'

var gm_channel = [  
    ['-1', '全平台'],  
    ['1', '默认'],  
    ['2', '通用接口'],
	['3', 'QQ 应用宝'],
	['4', '微信'],
	['5', '小米金山云'],
	['6', 'IOS'],
	['7', 'anysdk'],
	['8', '快用'],
	['9', 'itools'],
	['10', 'facebook'],
	['11', '台湾'],
	['12', 'google-play'],
	['13', '越南'],
];

gm_channel.all = '全平台';


gm_mail.allplayer = '全体玩家';
gm_mail.mailValidity = '邮件有效期';

gm_mail.allmail = '系统全服邮件列表';

gm_mail.userlist = '领取玩家列表';
gm_mail.allmailstr = '确认发送全服邮件';

var gm_activity ={};
gm_activity.activitylist = '活动列表';
gm_activity.push = '推送信息';
gm_activity.continuetime = '持续时间(分)';
gm_activity.isRepeat = '是否重复';
gm_activity.repeatType = '重复时间类型';
gm_activity.repeatTime = '重复时间(分)';
gm_activity.push = '推送信息';
gm_activity.system = '相关系统';
gm_activity.acttype = '活动类型';
gm_activity.systemsub = '相关系统子系统';

gm_activity.nextstarttime = '下次活动开启时间';

gm_activity.pushtype = '推送类型';
gm_activity.pushtime = '推送时间(分)';
gm_activity.pushtext = '推送内容';
gm_activity.pushinerval = '推送间隔(秒)';
gm_activity.pushcontinue = '推送时间(分)';

gm_activity.editactivity = '增加活动';

var gm_rank = {};
gm_rank.id_ = '玩家id';
gm_rank.num = '数量';
gm_rank.ranktype='排行类型';
gm_rank.rankcoin='货币类型';

var gm_addredeem ={};
gm_addredeem.id = '礼包激活码'
gm_addredeem.name = '添加道具';
gm_addredeem.nameid = '道具ID';
gm_addredeem.count = '数量（个）';
gm_addredeem.redeem = '选择道具';
gm_addredeem.chooseredeem = '道具名称';
gm_addredeem.type = '道具类型';
gm_addredeem.isrepeat = '是否可重复使用';
gm_addredeem.Sycee = '元宝（个）';
gm_addredeem.redeemname = '礼包名称';
gm_addredeem.redeemcount ='礼包数量（个）';
gm_addredeem.create = '提交审核';
gm_addredeem.cancel = '取消';
gm_addredeem.addredeems = '礼包名称';
gm_addredeem.redeemsname = '添加礼包';
gm_addredeem.starttime = '开始时间';
gm_addredeem.audit = '审核';
gm_addredeem.getfile = '获取信息';
gm_addredeem.addredeemsto = '请先添加礼包';
gm_addredeem.startdate = '有效开始时间';
gm_addredeem.endtime = '结束时间';
gm_addredeem.user = '使用人';
gm_addredeem.Items = '道具';
gm_addredeem.deleteredeem = '删除激活码';
gm_addredeem.redeemcdk = '输入激活码';

var gm_discountcard = {};
gm_discountcard.discounts = '请选择折扣率';
gm_discountcard.make = '折扣值在0到1之间选择';
gm_discountcard.discount = '折扣率';
gm_discountcard.starttime = '开始时间';
gm_discountcard.starttimes = '请选择开始时间';
gm_discountcard.endtime = '结束时间';

var gm_roller = {};
gm_roller.cost = '单次转盘消耗';
gm_roller.boomrate='爆炸几率';
gm_roller.boommax='能量槽大小';
gm_roller.energymax='转化成能量比率上限';
gm_roller.energymin='转换成能量比率下限';
gm_roller.starttime='活动开始时间';
gm_roller.endtime='活动结束时间';
gm_roller.mail_title='邮件标题';
gm_roller.mail_name='邮件名字';
gm_roller.mail_text='邮件内容';
gm_roller.roller_items='转盘物品表';
gm_roller.starttime='开始时间';
gm_roller.endtime='结束时间';
gm_roller.type='类型';
gm_roller.servererror='请选择一个服务器';
gm_roller.energyerror='转换成能量比率上线 大于 转换成能量比率下限';
gm_roller.energyerrors='转换成能量比率上线相加转换成能量比率下限为1';
gm_roller.rate='概率';
gm_roller.level='等级默认为0';

gm_roller.Rankings='排名';
gm_roller.one='第一名';
gm_roller.two='第二名';
gm_roller.three='第三名';
gm_roller.four='第4-10名';
gm_roller.five='第11-50名';
gm_roller.article='物品';