Ext.define('admin.controller.PlayerLogController',{
	extend: 'Ext.app.Controller',
    models: ['AllLogModel'],//
    stores: ['AllLogStore',],
	views:['player.Log'],//
	refs: [{
            ref: 'playerLog',
            selector: 'PlayerLog'
    }],
    init: function () {
        this.control({
			'playerLog button[action=allplayerlogSearch]'  :  {click:this.allplayerlogSearch},
			'playerLog button[action=exportAllplayerlog]'   :  {click: this.exportAllplayerlog},
			'playerLog button[action=playerlogCreateBtn]'   :  {click: this.playerlogCreateBtn},
		});
    },
	
	allplayerlogSearch:function(button){
		var buttons = button.up('panel');
		
		var logtype = buttons.down('#logtype').getValue();
		var serverid = buttons.down('#logserver').getValue();
		var logcomm = buttons.down('#logcomm').getValue();
		//ʱ��ת��
		var startdate = Ext.Date.add(new Date(buttons.down('#logstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(buttons.down('#logenddate').getValue()), Ext.Date.HOUR, 24);
		var roleid = buttons.down('#searchroleid').getValue();
		
		var grid = buttons.up('panel');
		 store  = grid.getStore('AllLogStore');//GetAllPlayerLogStore
		// console.log(store);
		 
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = { 
					serverid : serverid,
					logcomm : logcomm,
					logtype : logtype,
					startdate:startdate,
					enddate:enddate,
					roleid:roleid,
					};
			Ext.apply(store.proxy.extraParams, new_params);
		});	
		
        store.load({});
	},
	
	exportAllplayerlog:function(button){
     	var buttons = button.up('panel');
		
		var logtype = buttons.down('#logtype').getValue();
		var serverid = buttons.down('#logserver').getValue();
		var logcomm = buttons.down('#logcomm').getValue();
		//ʱ��ת��
		var startdate = Ext.Date.add(new Date(buttons.down('#logstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(buttons.down('#logenddate').getValue()), Ext.Date.HOUR, 24);
		var roleid = buttons.down('#searchroleid').getValue();
		
		var grid = buttons.up('panel');
		 store  = grid.getStore('AllLogStore');
	//	console.log(store);
		
		var list = new Array();
		for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}
		if(serverid==null ||logtype ==null ||logcomm == null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		var title = ([gm_common.userid,gm_common.time,gm_common.opertype,gm_common.operation]);
		var datas = {
			title:Ext.encode(title),
			data:Ext.encode(list),
		};
	//console.log(list);
	Ext.Ajax.request({
			url:'/gm/index.php?s=/Home/Index/saveCSV',
			waitMsg : gm_notice.exportstr,
			method: 'POST',
			params: datas,
			success: function(response) {
				var result = Ext.decode(response.responseText);		
				if(result.success == 'true')
				{
					window.location.href = '/gm/index.php?s=/Home/Index/exportCSV.html';
				}
				else{
					Ext.Msg.alert(gm_error.error, result.errorMessage);
				}
			},
			failure: function(response) {
				var result = Ext.decode(response.responseText);
				Ext.Msg.alert(gm_error.error, result);
			},		
		});
	}
});