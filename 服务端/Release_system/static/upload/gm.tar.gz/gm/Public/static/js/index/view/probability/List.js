Ext.define('admin.view.probability.List',{
	extend:'Ext.form.Panel',
	alias : 'widget.probabilityList',
	store: 'ProbabilityStore',
	//renderTo: Ext.getBody(),
	//resizable : false,
	//autoShow:true,
	border : 0,
	//height: 800,
	
    initComponent: function(){
		this.items=[{  
		        xtype: 'buttongroup',  
				columns: 5,   
				floatable:true,  
				defaults: {  
					scale: 'small',
				},
				 layout: {
							type: 'vbox',
							pack: 'center',              //纵向对齐方式 start：从顶部；center：从中部；end：从底部
							align: 'left'         //对齐方式 center、left、right：居中、左对齐、右对齐；stretch：延伸；stretchmax：以最大的元素为标准延伸
						},
			       items:[ 	
			       			{
							xtype:'combobox',
							name:'serverid',  
							fieldLabel:gm_string.serverselect,  
							triggerAction: 'all',//单击触发按钮显示全部数据  
							store : {
								autoLoad: false,
								fields:['id','name'],
								proxy: {
									type: 'ajax',
									url: '/gm/index.php?s=/Home/ComboBox/getSeverComboBox.html' //这里是参数可以顺便写,这个数据源是在第一个下拉框select的时候load的
									},
									autoDestroy: false
								},
							emptyText:gm_notice.serverselectnotice,
							displayField:'name',//定义要显示的字段  
							valueField:'id',//定义值字段  
							mode: 'local',//远程模式 
							forceSelection : true,//要求输入值必须在列表中存在  
							typeAhead : true,//允许自动选择匹配的剩余部分文本  
							handleHeight : 10,//下拉列表中拖动手柄的高度
							autoDestroy: false,
							width:300
						},	{
								xtype: 'textfield',
								name:'lastday',
								fieldLabel:gm_probability.start_time,
								width:300
							},
						{
							xtype: 'gridpanel',
							name: 'items',
							itemId:'items',
							title: gm_probability.card_probability,
							height: 260,
							width:502,
							border : 1,
							store: Ext.create('Ext.data.Store', {
								fields: ['cardid', 'probability'],
								autoDestroy: true
							}),
							plugins: [
							Ext.create('Ext.grid.plugin.CellEditing', {
								clicksToEdit: 2
							})
							],
							tbar:[{  
									text:gm_btnstring.add,
									iconCls: 'Add',
									action:'additem'
								},'-',{  
									text:gm_btnstring.delete, 
									iconCls: 'Delete',
									handler:function(){  
										var row = this.up('grid').getSelectionModel().getSelection(); 
										var store = this.up('grid').store; 
										if(row.length==0)
										{
											Ext.Msg.alert(gm_common.tip,gm_mail.tip_choose_delete);
										}
										else{
											Ext.Msg.confirm(gm_common.tip,gm_mail.tip_delete,function(optional){
												if(optional=='yes'){
													store.remove(row);  
												}
											})
										}
									}  
								},'-',{  
									text:gm_btnstring.clear, 
									iconCls: 'Delete',
									handler:function(){  
										var store = this.up('grid').store; 
										Ext.Msg.confirm(gm_common.tip,gm_mail.tip_delete,function(optional){
											if(optional=='yes'){
												store.removeAll();  
											}
										})
									}  
								}],
							columns:[{
									header: gm_probability.card_id, 
									dataIndex: 'cardid',
									width:200
								},{ 
									header: gm_probability.percent, 
									dataIndex: 'probability',
									width:200
								},
								],  				
						}
							,{
							xtype: 'button',				
							text: gm_probability.sendAll,
							iconCls: 'Emailgo',
							action: 'SendProbilitybtn',
							width:220
						},],
		}],
	    this.callParent(arguments);
 }
});