Ext.define('admin.controller.KeepController',{
	extend: 'Ext.app.Controller',
    models: ['KeepModel'],
    stores: ['KeepStore'],
	views:['keep.List'],
	refs: [{
            ref: 'keepList',
            selector: 'KeepList'
    }],
    init: function () {
        this.control({
			'keepList button[action=keepSearch]'  :  {click:this.keepSearch},
			'keepList button[action=keepExport]'  :  {click:this.keepExport},
			'keepList button[action=keepcreate]'  :  {click:this.keepcreate},
			
		});
    },
    keepcreate:function(button){
    	var grid = button.up('panel');
		
		var serverid = grid.down('#keepserver').getValue();
		//时区转换
		var channelid = grid.down('#channel').getValue();
		var startdate = Ext.Date.add(new Date(grid.down('#keepstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#keependdate').getValue()), Ext.Date.HOUR, 24);
		
		var datas = {
				serverid:serverid,
				startdate:startdate,
				enddate:enddate,
				channelid:channelid,
		};
		Ext.MessageBox.wait(gm_notice.create,gm_notice.prompt);
		
		Ext.Ajax.request({
			url:'/gm/index.php?s=/Home/Keep/createKeeplog',
			method: 'POST',
			params: datas,
			success: function(response) {
				Ext.MessageBox.hide();
				
				var result = Ext.decode(response.responseText);
				if(result['success']==true)
				{
					Ext.Msg.alert(gm_notice.prompt, gm_notice.createstr);
				}
				else
				{
					Ext.Msg.alert('keep test001','keep test001');
					Ext.Msg.alert(gm_error.error, result['err']);
				}
				
			},
			failure: function(response) {
				Ext.MessageBox.hide();
				
				var result = Ext.decode(response.responseText);
				Ext.Msg.alert(gm_error.error, result);
			},		
		});
    },
	keepSearch:function(button){
		var grid = button.up('panel');
		
		var serverid = grid.down('#keepserver').getValue();
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#keepstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#keependdate').getValue()), Ext.Date.HOUR, 24)
			
		var store  = grid.getStore();

		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
			var new_params = {
				serverid : serverid,
				startdate:startdate,
				enddate:enddate,
            }
		Ext.apply(store.proxy.extraParams, new_params);
			
	});
  
    store.load({});	
	},
	
	keepExport:function(button){
		var grid = button.up('panel');
		
		var serverid = grid.down('#keepserver').getValue();
		
		store  = this.getStore('KeepStore');

		var list = new Array();
		for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}


	
		var title = [gm_statistics.reguser,gm_statistics.tomorrowdelay,
		              gm_statistics.thirddaydelay,gm_statistics.forthdaydelay,gm_statistics.fifthdaydelay,
					  gm_statistics.sixthdaydelay,gm_statistics.seventhdaydelay,gm_statistics.fifteendaydelay,gm_statistics.thirtydaysdelay,gm_statistics.date,gm_statistics.serverid];
		var datas = {
				data:Ext.encode(list),
				title:Ext.encode(title),
		};
		Ext.Ajax.request({
			url:'/gm/index.php?s=/Home/Index/saveCSV',
			waitMsg : gm_notice.exportstr,
			method: 'POST',
			params: datas,
			success: function(response) {
				var result = Ext.decode(response.responseText);		
				if(result.success == 'true')
				{
					window.location.href = '/gm/index.php?s=/Home/Index/exportCSV.html';
				}
				else{
					Ext.Msg.alert(gm_error.error, result.errorMessage);
				}
			},
			failure: function(response) {
				var result = Ext.decode(response.responseText);
				Ext.Msg.alert(gm_error.error, result);
			},		
		});
	},
	
});