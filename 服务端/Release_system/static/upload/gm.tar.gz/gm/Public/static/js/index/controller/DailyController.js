Ext.define('admin.controller.DailyController',{
	extend: 'Ext.app.Controller',
    models: ['DailyModel'],
    stores: ['DailyStore'],
	views:['daily.List'],
	refs: [{
            ref: 'dailyList',
            selector: 'DailyList'
    }],
    init: function () {
        this.control({
			'dailyList button[action=dailySearch]'  :  {click:this.dailySearch},
			'dailyList button[action=dailyExport]'  :  {click:this.dailyExport},
			'dailyList button[action=dailycreate]'  :  {click:this.dailycreate},
			'dailyList button[action=dailydel]'  :  {click:this.dailydel},
			//'dailyList button[action=datelycreate]'  :  {click:this.datelycreate},
			
			
		});
    },
	
    dailySearch:function(button){
		var buttons = button.up('panel');
		
		var type = buttons.down('#reporttype').getValue();
		var serverid = buttons.down('#server').getValue();
		var channelid= buttons.down('#channel').getValue();
		var startdate = Ext.Date.add(new Date(buttons.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(buttons.down('#enddate').getValue()), Ext.Date.HOUR, 24);
		
		var grid = buttons.up('panel');
		store  = grid.getStore();
        
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					type:type,
					serverid : serverid,
					channelid:channelid,
					startdate:startdate,
					enddate:enddate,
                }
			Ext.apply(store.proxy.extraParams, new_params);
		});
      
	    store.load({});	
	},
	
	dailydel:function(button){
		var buttons = button.up('panel');
		
		var serverid = buttons.down('#server').getValue();
		var type = buttons.down('#reporttype').getValue();
		
		var grid = buttons.up('panel');
		store  = grid.getStore();		
		
		var datas = {
				type:type,
				serverid:serverid,
		};
		
		Ext.MessageBox.wait(gm_notice.managestr,gm_notice.prompt);
		  
		Ext.Ajax.request({
			url:'/gm/index.php?s=/Home/Daily/clearDaily',
			method: 'GET',
			params: datas,
			success: function(response) {
				Ext.MessageBox.hide();
				
				var result = Ext.decode(response.responseText);
				if(result['success']==true)
				{
					 store.removeAll(); 
				}		
			},
			failure: function(response) {
				Ext.MessageBox.hide();
				
				var result = Ext.decode(response.responseText);
				Ext.Msg.alert(gm_error.error, result);
			},	
		});
	},
	
	dailyExport:function(button){
		var buttons = button.up('panel');
		
		var serverid = buttons.down('#server').getValue();
		var channel = buttons.down('#channel').getValue();

		var type = buttons.down('#reporttype').getValue();
		if(serverid==null ||channel　==null ||type == null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		//直接跳转
		window.location.href = '/gm/index.php?s=/Home/Daily/exportDaily.html&serverid='+serverid+'&channelid='+channel+'&type='+type;
	},
	
	dailycreate:function(button){
		var grid = button.up('panel');
		
		var type = grid.down('#reporttype').getValue();
		
		var serverid = grid.down('#server').getValue();
		var startdate = Ext.Date.add(new Date(grid.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#enddate').getValue()), Ext.Date.HOUR, 24);
		
		var datas = {
				serverid:serverid,
				startdate:startdate,
				enddate:enddate,
		};
		Ext.Ajax.timeout = 90000;
		
		if( type == 'daily')
		{		
			Ext.MessageBox.wait(gm_notice.create,gm_notice.prompt);
			
			Ext.Ajax.request({
				url:'/gm/index.php?s=/Home/Daily/createDaily',
				method: 'POST',
				params: datas,
				success: function(response) {
					Ext.MessageBox.hide();
					
					var result = Ext.decode(response.responseText);
					if(result['success']==true)
					{
						Ext.Msg.alert(gm_notice.prompt, gm_notice.createstr);
					}
					else
					{
						Ext.Msg.alert(gm_error.error, result['err']);
					}
					
				},
				failure: function(response) {
					Ext.MessageBox.hide();
					
					var result = Ext.decode(response.responseText);
					Ext.Msg.alert(gm_error.error, result);
				},		
			});
		}
		else if( type == 'dately')
		{
			Ext.MessageBox.wait(gm_notice.create,gm_notice.prompt);

			Ext.Ajax.request({
				url:'/gm/index.php?s=/Home/Daily/createDately',
				method: 'POST',
				params: datas,
				success: function(response) {
					Ext.MessageBox.hide();
					
					var result = Ext.decode(response.responseText);
					if(result['success']==true)
					{
						Ext.Msg.alert(gm_notice.prompt, gm_notice.createstr);
					}
					else
					{
						Ext.Msg.alert(gm_error.error, result['err']);
					}
					
				},
				failure: function(response) {
					Ext.MessageBox.hide();
					
					var result = Ext.decode(response.responseText);
					Ext.Msg.alert(gm_error.error, result);
				},		
			});
		}
		
	},
	
});