Ext.define('admin.controller.GmLogController',{
	extend: 'Ext.app.Controller',
    models: ['GmLogModel'],
    stores: ['GMLogStore'],
	views:['GmLog.List'],
	refs: [{
            ref: 'GmLogList',
            selector: 'gmLogList'
    }],
    init: function () {
        this.control({
            'GmLogList button[action=userSearch]'       :  {click: this.userSearch},
		});
    },
	
	userSearch:function(button){
		var name = Ext.getCmp("searchnameId").getValue();
		store  = this.getStore('GMLogStore');
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					username : name
                }
			Ext.apply(store.proxy.extraParams, new_params);
		});
      
	    store.load({});	
	}
});