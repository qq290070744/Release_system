Ext.define('admin.view.user.List',{
	extend:'Ext.grid.Panel',
	alias : 'widget.userList',
	store: 'UserStore',
	selModel: Ext.create('Ext.selection.CheckboxModel'),
	border : 0,
    initComponent: function(){
	    this.columns = [
			{header: gm_user_oper.user_no, dataIndex: 'id', flex: 0.5},
	        {header: gm_common.username, dataIndex: 'username', flex: 1},
	        {header: gm_user_oper.user_type,  dataIndex: 'status',  flex: 1},
	        {header:'权限列表', dataIndex:'auth',flex:1},
	        {header: gm_common.pwd,  dataIndex: 'password',  flex: 1,hidden:true}
	    ];
		this.tbar=[{  
                    text : gm_user_oper.new_user,  
                    action:'userAdd',
					iconCls:'Useradd'
                },'-',{  
                    text : gm_user_oper.edit_user,  
                    action:'userEdit',
					iconCls:'Useredit'
                },'-',{  
                    text : gm_user_oper.del_user,  
                    action:'userDelete',
					iconCls:'Userdelete'
                }],
		this.bbar=Ext.create('Ext.PagingToolbar', {   
					store: this.store,
					displayInfo: true
					//displayMsg: gm_common.displaymsg,   
					//emptyMsg: gm_common.emptymsg   
				}  
		);
		this.viewConfig={  
				enableTextSelection:true  
		},
	    this.callParent(arguments);
    }
});