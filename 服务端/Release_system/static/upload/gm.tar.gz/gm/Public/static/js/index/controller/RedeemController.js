Ext.define('admin.controller.RedeemController',{
	extend: 'Ext.app.Controller',
    //models: ['AddredeemModel'],
    stores: ['RedeemStore'],
	views:['redeem.List','redeem.Edit','redeem.AccEdit','redeem.OneEdit'],
	refs: [{
            ref: 'RedeemList',
            selector: 'redeemList'
    },{
        ref: 'RedeemOneEdit',
        selector: 'redeemOneEdit'
    }
	],
	 init: function () {
        this.control({
            'redeemOneEdit button[action=additem]'       :  {click: this.additem},
			'redeemEdit button[action=redeemsavebtn]'     :  {click: this.redeemsavebtn},
            'redeemList button[action=redeemSearch]'     :  {click: this.redeemSearch},
			'redeemList button[action=addoneitem]'       :  {click: this.addoneitem},
			'redeemOneEdit button[action=redeemsavebtns]'     :  {click: this.redeemsavebtns},
			'accRedeemEdit button[action=getfilebtn]'     :  {click: this.getfilebtn},
			'redeemAccEdit button[action=redeemSearchs]'     :  {click: this.redeemSearchs},
			'redeemOneEdit button[action=redeemcreatebtn]'     :  {click: this.redeemcreatebtn},
			'redeemList button[action=redeemExport]'       :  {click: this.redeemExport},
			'redeemOneEdit button[action=redeemCloseBtn]'       :  {click: this.redeemCloseBtn},
			'redeemList button[action=redeemDelete]'     :  {click: this.redeemDelete},
		});
    },
	
	additem:function(button){
		var view=Ext.widget('redeemEdit');
	},
	addoneitem:function(button){
		var view=Ext.widget('redeemOneEdit');
	},
	redeemCloseBtn:function(button){
		button.up('window').close();
	},
	redeemDelete:function(button){
		var grid = this.getRedeemList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('RedeemStore');			
		console.log(store);
		if(record.length<=0){
			Ext.Msg.alert('redeem delete test001','test001');
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					store.remove(record);
					store.sync();
					store.load();
				}
			})
		}
	},
	
	redeemSearch:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		var redeemids = grid.down('#redeemids').getValue();
		var channelid = Number(grid.down('#channelid').getValue());
		var redeemuse = Number(grid.down('#redeemuse').getValue());
		if(serverid==null)
		{
			Ext.Msg.alert('serach test 001','test001');
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		store  = this.getStore('RedeemStore');	
		//console.log(store);
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
					id : redeemids,
					channelid : channelid,
					redeemuse : redeemuse,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});	
	},
	redeemExport:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		var redeemids = grid.down('#redeemids').getValue();
		var channelid = Number(grid.down('#channelid').getValue());
	
		if(serverid==null)
		{
			Ext.Msg.alert('redeem export test 001','test001');
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		//直接跳转
		window.location.href = '/gm/index.php?s=/Home/Redeem/exportRedeem.html&serverid='+serverid+'&redeemids='+redeemids+'&channelid='+channelid;
	},
	
	getfilebtn:function(button)
	{
	  var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
			//console.log(values);
		var resform = this.getRedeemList();
		var grid = resform.down("#itemss");
		var	store  = grid.getStore();
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
				win.close();
			}
	},
	
	redeemsavebtn:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
			console.log(values);
		var resform = this.getRedeemOneEdit();
		var grid = resform.down("#itemsd");
		var	store  = grid.getStore();
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
				//win.close();
			}
	},
	
	redeemsavebtns:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
		//	console.log(values);
		var resform = this.getRedeemList();
		var grid = resform.down("#item");
		var	store  = grid.getStore();
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
			}
	},
	
	redeemcreatebtn:function(button){
		var win= button.up('window');
        form = win.down('form').getForm();
        var values = form.getValues();
	    var	list =  win.down('form').down("#itemsd");
		var	store =  list.getStore();
		var list = [];
		 for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}
		values['itemsd'] = Ext.encode(list);
		console.log(list);
		
		form.submit({
			url:'/gm/index.php?s=/Home/Redeem/addRedeem.html',
			waitMsg : gm_notice.create,
			method: 'POST',
			params: values,
			success: function(form, action) {
				if(action.result.success == 'true')
				{
					win.close();
				}
				else{
					Ext.Msg.alert('test001','test001');
					Ext.Msg.alert(gm_error.error, action.result.errorMessage);
				}

			},
			failure: function(form, action) {
				Ext.Msg.alert('test002','test002');
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
	},
});