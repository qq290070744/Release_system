Ext.define('admin.controller.RankController',{
	extend: 'Ext.app.Controller',
    models: ['RankModel'],
    stores: ['RankStore'],
	views:['rank.List'],
	refs: [{
            ref: 'RankList',
            selector: 'rankList'
    }],
    init: function () {
        this.control({
        	'rankList button[action=rankSearch]' :  {click: this.rankSearch},
            
		});
    },

    rankSearch:function(button){
		var buttons = button.up('panel');
		var grid = buttons.up('panel');
		
		var serverid = grid.down('#server').getValue();
		var ranktype = grid.down('#ranktype').getValue();
		var rankcoin = grid.down('#rankcoin').getValue();
		
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#enddate').getValue()), Ext.Date.HOUR, 24);
			
		store  = grid.getStore();
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = { 
					serverid : serverid,
					ranktype : ranktype,
					rankcoin : rankcoin,
					startdate:startdate,
					enddate:enddate,
					};
			Ext.apply(store.proxy.extraParams, new_params);
		});	
		
        store.load({});
	},

});