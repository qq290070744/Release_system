Ext.define('admin.controller.NoticeController',{
	extend: 'Ext.app.Controller',
    models: ['NoticeModel'],
    stores: ['NoticeStore'],
	views:['notice.List','notice.Edit'],
	refs: [{
            ref: 'NoticeList',
            selector: 'noticeList'
    }],
    init: function () {
        this.control({
			'noticeList'                       		  :  {itemdblclick:this.itemdblclick},
			'noticeList button[action=noticeSearch]'     :  {click: this.noticeSearch},
			'noticeList button[action=noticeCreate]'     :  {click: this.noticeCreate},
			'noticeList button[action=noticeDelete]'     :  {click: this.noticeDelete},
			'noticeEdit button[action=noticeCreateBtn]'     :  {click: this.noticeCreateBtn},

		});
    },
	
	itemdblclick:function(grid, record, item, index, e, eOpts){
		var view=Ext.widget('noticeEdit');
		view.down('form').loadRecord(record);
	},
	
	noticeCreate:function(button){
		Ext.widget('noticeEdit');
	},
	
	noticeCreateBtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();
		
		var store  = this.getStore('NoticeStore');	
		var model  = this.getModel('NoticeModel');
		
		//验证有没有修改
		if(form.getForm().isValid()){
			if(record){
				record.set(values);
			}else{
				record = Ext.create(model);
				record.set(values);
				store.add(record);
			}
			win.close();
			store.sync();
			store.load();
		}
		else{
			win.close();
		}
	},
	
	noticeSearch:function(button){
		var grid = button.up('panel');
		var valid =Number(grid.down('#valid').getValue());
		
		store  = this.getStore('NoticeStore');	
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					valid:valid,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});	
	},

	noticeDelete:function(button){
		var grid = this.getNoticeList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('NoticeStore');			
		
		if(record.length<=0){
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					store.remove(record);
					store.sync();
					store.load();
				}
			})
		}
	}
});