Ext.define('admin.view.layout.Sidebar',{
	extend: 'Ext.panel.Panel',
	region: 'west',
	title: gm_string.menu,
	xtype: 'sidebar',
	iconCls: 'Sitemap',
	split: true,
	collapsible: true,
	width:180,
	layout: {
        type: 'accordion',
        titleCollapse: true,
        animate: true,
        activeOnTop: false		
	},
	/*items:[
	  {
			title: gm_string.server_manage,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Bulletwrench',
			store: 'admin.store.menu.Config'
		},
		{
			title: gm_string.data_staticstic,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Serverchart',
			store: 'admin.store.menu.Inquiry'
		},
		{
			title: gm_string.users_manage,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Folderuser',
			store: 'admin.store.menu.Player'
		},
		{
			title: gm_string.announcement,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Note',
			store: 'admin.store.menu.Notice'
		},
		{
			title: gm_string.charge_manage,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Databaseedit',
			store: 'admin.store.menu.Distribute'
		},
		{
			title: gm_string.activity,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Note',
			store: 'admin.store.menu.Activity'
		},
		{
			title: gm_string.redeem_function,
			xtype: 'treepanel',
			rootVisible: false,
			margin : 0,
			iconCls : 'Note',
			store: 'admin.store.menu.Redeems'
		}
	]*/
});