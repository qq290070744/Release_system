Ext.define('admin.controller.CodeTotalPayController',{
	extend: 'Ext.app.Controller',
    models: ['CodeTotalPayModel'],
    stores: ['CodeTotalPayStore'],
	views:['codetotalpay.List','codetotalpay.Edit'],
	refs: [{
            ref: 'CodeTotalPayList',
            selector: 'codetotalpayList'
    }],
    init: function () {
        this.control({
			'codetotalpayList button[action=codetotalpaySearch]'     :  {click: this.codetotalpaySearch},
			'codetotalpayList button[action=codetotalpayCreate]'     :  {click: this.codetotalpayCreate},
			'codetotalpayList button[action=codetotalpayExport]'     :  {click: this.codetotalpayExport},
			'codetotalpayEdit button[action=codetotalpayCreateBtn]'    :  {click: this.codetotalpayCreateBtn},
			'codetotalpayEdit button[action=codetotalpayCloseBtn]'     :  {click: this.codetotalpayCloseBtn},
		});
    },

    codetotalpayCreate:function(button){    	
		Ext.widget('codetotalpayEdit');
	},

	codetotalpayCloseBtn:function(button){
		button.up('window').close();
	},
	
	codetotalpayCreateBtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();

        var store  = this.getStore('CodeTotalPayStore');	
		
		//验证有没有修改
		if(form.getForm().isValid()){
			if(record){
				record.set(values);
				win.close();
				store.sync();
				store.load();
			}
			else
			{
				form.submit({
					url:'/gm/index.php?s=/Home/Code/addCodeTotalPay.html',
					waitMsg : gm_notice.create,
					method: 'POST',
					params: values,
					success: function(form, action) {
						if(action.result.success == 'true')
						{
							win.close();
						}
						else{
							Ext.Msg.alert(gm_error.error, action.result.errorMessage);
						}

					},
					failure: function(form, action) {
						Ext.Msg.alert(gm_error.error, action);
					},		
				});
			}
		}
		else{
			win.close();
		}
	},
	
	codetotalpaySearch:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		//var startdate = grid.down('#startdate').getValue();
		//var enddate = grid.down('#enddate').getValue();
		var platformid = grid.down('#platformid').getValue();
		
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#startdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#enddate').getValue()), Ext.Date.HOUR, 24);
		
		if(serverid==null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}


		
		store  = this.getStore('CodeTotalPayStore');	
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
					startdate: startdate,
					enddate : enddate,
					platformid : platformid
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});	
	},

	codetotalpayExport:function(button){
		var grid = button.up('panel');
			
		var serverid = grid.down('#serverid').getValue();
		var codetype = grid.down('#codetype').getValue();
		var codeuse = Number(grid.down('#codeuse').getValue());
	
		if(serverid==null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		//直接跳转
		window.location.href = '/gm/index.php?s=/Home/Code/exportCode.html&serverid='+serverid+'&codetype='+codetype+'&codeuse='+codeuse;
	}
	
});