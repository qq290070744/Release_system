Ext.define('admin.view.limit.List',{
	extend:'Ext.grid.Panel',
	alias : 'widget.limitList',
	store: 'LimitStore',
	border : 0,
	height: 400,
	selModel: Ext.create('Ext.selection.CheckboxModel'),
    initComponent: function(){		
		this.columns = [
			{header: gm_limit_account.sequence, dataIndex: 'id',hidden:true},
			{header: gm_string.group, dataIndex: 'serverid', flex: 0.1},
			{header: gm_string.accid, dataIndex: 'accid', flex: 0.2},
	        {header: gm_limit_account.limit_account_time, dataIndex: 'time', flex: 0.3},
			{header: gm_limit_account.limit_account_deadtime,  dataIndex: 'end_time',  flex: 0.3},
	        {header: gm_limit_account.limit_account_gm,  dataIndex: 'acc',  flex: 0.2},
			{header: gm_common.recommend,  dataIndex: 'remark',  flex: 0.3}
	    ],
		this.tbar=[{
					xtype:'combobox',
					itemId:'serverid',  
					fieldLabel:gm_string.serverselect,  
					triggerAction: 'all',//单击触发按钮显示全部数据  
					store : {
						autoLoad: false,
						fields:['id','name'],
						proxy: {
							type: 'ajax',
							url: '/gm/index.php?s=/Home/ComboBox/getSeverComboBox.html' //这里是参数可以顺便写,这个数据源是在第一个下拉框select的时候load的
						},
						autoDestroy: true
					},//设置数据源  
					displayField:'name',//定义要显示的字段  
					valueField:'id',//定义值字段  
					mode: 'local',//本地模式  
					forceSelection : true,//要求输入值必须在列表中存在  
					typeAhead : true,//允许自动选择匹配的剩余部分文本  
					handleHeight : 10//下拉列表中拖动手柄的高度  
				},'-',{  
					text : gm_btnstring.search,  
					action:'limitSearch',
					iconCls:'Zoom'
				},'-',{  
					text : gm_limit_account.limit,  
					action:'limitCreate',
					iconCls:'Keyadd'
				},'-',{  
					text : gm_limit_account.limit_release,  
					action:'limitDelete',
					iconCls:'Keydelete'
				}],
				
		this.bbar=Ext.create('Ext.PagingToolbar', {   
					store: this.store,
					displayInfo: true,   
					displayMsg: gm_common.displaymsg,   
					emptyMsg: gm_common.emptymsg   
				}  
		);
		this.viewConfig={  
				enableTextSelection:true  
		},
	    this.callParent(arguments);
    }
});