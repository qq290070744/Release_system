Ext.define('admin.view.user.Edit',{
	extend:'Ext.window.Window',
	alias:'widget.userEdit',
	title:gm_common.user_edit,	
	layout:'fit',
	resizable : false,
	autoShow:true,
	initComponent:function(){
		this.items=[
			{
				xtype:'form',
				bodyPadding : 5,
				fieldDefaults:{
					allowBlank : false,
					labelAlign :'right',
					labelWidth : 60
				},
				defaultType:'textfield',
				items:[
					{name:'username',fieldLabel:gm_common.username,regex:/[a-zA-Z]{5,16}/,regexText:gm_common.username_request},
					{
						xtype:'combobox',
						name:'status',
						itemId:'status', 
						fieldLabel:gm_common.area,  
						triggerAction: 'all',//单击触发按钮显示全部数据  
						store : {
							autoLoad: true,
							fields:['type','name'],
							proxy: {
								type: 'ajax',
								url: '/gm/index.php?s=/Home/ComboBox/getUserLevelComboBox.html' //这里是参数可以顺便写,这个数据源是在第一个下拉框select的时候load的
							},
							autoDestroy: true
						},
						displayField:'name',//  
						valueField:'type',//  
						mode: 'remote',// 
						forceSelection : true,//  
						typeAhead : true,//  
						handleHeight : 10 //	
					},
					{
                        name : 'password',
                        inputType : 'password',
                        fieldLabel : gm_common.pwd,
                        allowBlank : true,
						readOnly:true
                    }, 
                    {
                        id : 'newPwd',
                        name : 'newPwd',
                        inputType : 'password',
                        fieldLabel : gm_common.pwd_new,
                        allowBlank : false,
                        blankText : gm_common.pwd_new_empty,
                        regex : /^[\s\S]{0,12}$/,
                        regexText : gm_common.pwd_new_too_long
                    }, {
                        name : 'confirmPwd',
                        inputType : 'password',
                        fieldLabel : gm_common.pwd_confirm,
                        vtype : 'password',
                        initialPassField : 'newPwd',
                        allowBlank : false,
                        blankText : gm_common.pwd_confirm_empty,
                        regex : /^[\s\S]{0,12}$/,
                        regexText : gm_common.pwd_old_too_long
                    },
                   /* {
 					   xtype:'checkboxgroup',
 					   id:'authGroup',//服务管理器
 					   fieldLabel:'选择权限列表',
 					   hiddenLabel:true,
 					   //width:500,
 					   labelWidth:80,//标签宽度   
 					  // allowBlank:false,
 					  // blankText:'必须择',
 					   msgTarget:'side',
 					   layout: { 
 								 type:'table',        //这里采用'table'布局可以实现，就可以保证布局不乱
 								 columns:3
 								},
 						 defaults:{
 						//	cls:'inline_checkbox'
 						margins : 20 
 						},
 					   items:[
 							{boxLabel:gm_string.server_manage,name:'1'},
 							{boxLabel:gm_string.users_manage,name:'2'},
 							{boxLabel:gm_string.data_staticstic,name:'3'},
 							{boxLabel:gm_string.announcement,name:'4'},
 							{boxLabel:gm_string.charge_manage,name:'5'},
 							{boxLabel:gm_string.activity,name:'6'},
 							{boxLabel:gm_string.redeem_function,name:'7'},
 					   ]
 			           },*/
 			          {
 			        	  xtype: 'fieldset',
 			        	  title: '权限设置',
 			        	  autoHeight: true,
 			        	  defaultType: 'checkbox',
 			        	  hideLabels: true,
 			        	  id: 'auth',
 			        	  layout: { 
							type:'table',        //这里采用'table'布局可以实现，就可以保证布局不乱
							columns:3
						  },								
 			        	  defaults: {
 			        		 margins : 20 
 			        	  },
 			        	  //vertical: false,
 			        	  items: [
 			        	  	{boxLabel:gm_string.server_manage, moduleid: '1'},
							{boxLabel:gm_string.users_manage, moduleid: '2'},
							{boxLabel:gm_string.data_staticstic, moduleid: '3'},
							{boxLabel:gm_string.announcement, moduleid: '4'},
							{boxLabel:gm_string.charge_manage, moduleid: '5'},
							{boxLabel:gm_string.activity, moduleid: '6'},
							{boxLabel:gm_string.redeem_function, moduleid: '7'},
 			        	  ]
 			        }
				]
			}
		];
		Ext.apply(Ext.form.VTypes, {
                password : function(val, field) {
                    if (field.initialPassField) {
                        var pwd = Ext.getCmp(field.initialPassField);
                        return (val == pwd.getValue());
                    }
                    return true;
                },
                passwordText : gm_common.pwd_different
        });
		
		this.buttons=[
			{text:gm_btnstring.EditSave,action:'userEditSave'},
			{text:gm_btnstring.EditClose,action:'userEditClose'}
		];
		this.buttonAlign='center',
		this.callParent(arguments);
	}
})