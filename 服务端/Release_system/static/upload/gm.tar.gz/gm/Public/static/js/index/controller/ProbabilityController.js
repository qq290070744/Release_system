var cardwin = null;

Ext.define('admin.controller.ProbabilityController',{
	extend: 'Ext.app.Controller',
	//models: ['ProbabilityModel'],
    stores: ['ProbabilityStore'],
	views:['probability.List','probability.Edit'],
	
	refs: [{
            ref: 'ProbabilityList',
            selector: 'probabilityList'
    }],
    init: function () {
        this.control({
            'probabilityList button[action=ImportProbility]'       :  {click: this.ImportProbility},
		//	'probabilityList button[action=clearImportProbility]'     :  {click: this.clearImportProbility},
			'probabilityList button[action=additem]'     		:  {click: this.additem},
			'probabilityList button[action=SendProbilitybtn]'   :  {click: this.SendProbilitybtn},
			'probabilityEdit button[action=itemprobilitysavebtn]'     :  {click: this.itemprobilitysavebtn},
		});
    },
	
	ImportProbility:function(button){
		var form=button.up('form').getForm();
		var isall = form.findField("isAll");
		if(!isall)
		{
			cardwin = Ext.widget('probabilityEdit');
		}
		
	},
	
	SendProbilitybtn:function(button){
		var form=button.up('form').getForm();	
		//console.log(form);
		var datas = form.getValues();
		
		if(datas['lastday'] == "")
		{
			Ext.Msg.alert(gm_notice.prompt, gm_probability.time);
			return;
		}
		
		if(datas['serverid'] == "")
		{
			Ext.Msg.alert(gm_notice.prompt, gm_probability.servererror);
			return;
		}
		var resform = this.getProbabilityList();
		var grid = resform.down("#items");
		var	store =  grid.getStore();
		//console.log(store);
		var list = [];
		  for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}
		 
		datas['items'] = Ext.encode(list);
	//	console.log(datas);
						form.submit({
							url:'/gm/index.php?s=/Home/Probability/addAllProbability',
							waitMsg : gm_notice.load,
							method: 'POST',
							params: datas,
							success: function(form, action) {
								if(action.result.success == true)
											{
												Ext.Msg.alert(gm_notice.prompt,gm_probability.success);
											}
											else{
												Ext.Msg.alert(gm_error.error, action.result.errorMessage);
											}
							},		
											failure: function(form, action) {
												Ext.Msg.alert(gm_error.error, action);
												},		
						});
	},
	
	additem:function(button){
		var view=Ext.widget('probabilityEdit');
	},
	
	itemprobilitysavebtn:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
		//	console.log(values); 
			//var itemArr = new Array();
			//itemArr.push(values);
		//	console.log(itemArr);
		var resform = this.getProbabilityList();
	//	console.log(resform);
		var grid = resform.down("#items");
		var	store  = grid.getStore();
		//	console.log(store);
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
				win.close();
			}
	},
});