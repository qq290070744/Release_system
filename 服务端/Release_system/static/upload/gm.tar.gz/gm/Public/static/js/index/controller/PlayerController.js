var mailwin = null;
Ext.define('admin.controller.PlayerController',{
	extend: 'Ext.app.Controller',
    models: ['PlayerModel'],
	//stores: ['PlayerStore'],
	views:['player.Info','player.Mail','tools.MailItem'],
	refs: [{
            ref: 'playerInfo',
            selector: 'PlayerInfo'
		},
	],
    init: function () {
        this.control({
			'playerInfo button[action=playerSearch]'     :  {click: this.playerSearch},
			'playerInfo button[action=addplayerMail]'       :  {click: this.addplayerMail},
			'playerMail button[action=playerMailClose]' 	 :  {click: this.playerMailClose},
			'playerMail button[action=mailadditem]' 	 :  {click: this.mailadditem},
			'playerMail button[action=SendMailbtn]' 	 :  {click: this.SendMailbtn},
			'playerMailItem button[action=mailitemsavebtn]'     :  {click: this.mailitemsavebtn},
			'playerInfo button[action=playerlogSearch]' 	 :  {click: this.playerlogSearch},
			'playerInfo button[action=chargelist]' 	 :  {click: this.chargelist},
			'playerInfo button[action=rechargplayerpwd]' 	 :  {click: this.rechargplayerpwd},
			
		});
    },
	
	playerSearch:function(button){
		var form = button.up('form').getForm();
		var serverid = form.findField('serverid').getValue();
		var idtype = form.findField('idtype').getValue();
		var choseid = form.findField('choseid').getValue();
		//var grid = form.load("#items");
		if(serverid==null ||idtype==null ||choseid == null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		form.load({
			url: '/gm/index.php?s=/Home/Player/getInfo',
			waitMsg : gm_notice.load,
			method: 'GET',
			params: {
				serverid : serverid,
				idtype : idtype,
				choseid:choseid,
			},
			success: function (form, action) {
				if(action.result.success == 'false')
				{
					Ext.Msg.alert(gm_notice.prompt, action.result.data.errorMessage);
				}		
			},
			failure: function(form, action) {
				Ext.Msg.alert(gm_error.error, gm_error.nodata);
			},		
		}); 
	},
	
	addplayerMail:function(button){
		var form = button.up('form').getForm();
		var id = form.findField('role_id').getValue();
		var serverid = form.findField('serverid').getValue();
		if(id == "")
		{
			Ext.Msg.alert(gm_notice.prompt,gm_error.findplayer);
		}
		else{
			mailwin = Ext.widget('playerMail');
			mailwin.down('form').getForm().findField('userid').setValue(id);
			mailwin.down('form').getForm().findField('serverid').setValue(serverid);			
		}
	},
	
	mailadditem:function(button){
		Ext.widget('playerMailItem');
	},
	
	mailitemsavebtn:function(button){
        var win    = button.up('window'),
			form   = win.down('form'),
			record = form.getRecord(),
			values = form.getValues();
		//	console.log(values);
			
		if(mailwin == null)
		{
			Ext.Msg.alert(gm_error.error, "界面出错");
			win.close();
			return;
		}

		var resform = mailwin.down('form');
		var grid = resform.down("#items");
		//var grid = resform.getForm().findField("items");
		var	store  = grid.getStore();
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					store.add(values);
				}
				win.close();
			}
	},
	
	playerMaliClose:function(button){
		button.up('window').close();
		mailwin = null;
	},
	
	SendMailbtn:function(button){
		var win=button.up('window'),
			form = win.down('form').getForm();		
		var datas = form.getValues();
		
		var	list =  win.down('form').down("#items");
	
		var	store =  list.getStore();
		
		var list = [];
		
		if(store.getCount() > 5)
		{
			Ext.Msg.alert(gm_notice.prompt, gm_error.mailerror);
			return;
		}
		
        for (var i = 0; i < store.getCount(); i++) {
            list.push(store.getAt(i).data);
		}
		
		datas['items'] = Ext.encode(list);
		
		form.submit({
			url:'/gm/index.php?s=/Home/Player/addMail',
			waitMsg : gm_notice.load,
			method: 'POST',
			params: datas,
			success: function(form, action) {
				Ext.Msg.alert(gm_notice.prompt,gm_notice.mail);
				win.close();
				mailwin = null;
			},
			failure: function(form, action) {
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
	},
	
	playerlogSearch:function(button){
		var form = button.up('form'),
			loggrid = form.down('#loggrid'),
			store = loggrid.getStore();

		var logtype = form.down('#logtype').getValue();
		var logcomm = form.down('#logcomm').getValue();
		
		var userid = form.getForm().findField('id').getValue();
		var serverid = form.getForm().findField('serverid').getValue();
		
		if(userid == "")
		{
			Ext.Msg.alert(gm_notice.prompt,gm_error.findplayer);
			return;
		}
		
		var startdate = Ext.Date.add(new Date(loggrid.down('#logstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(loggrid.down('#logenddate').getValue()), Ext.Date.HOUR, 24);
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = { 
					serverid : serverid,
					roleid:userid,
					logtype : logtype,
					logcomm : logcomm,
					startdate:startdate,
					enddate:enddate,
					};
			Ext.apply(store.proxy.extraParams, new_params);
		});	
		
		store.load({});
	},
	
	rechargplayerpwd:function(button){
		var form = button.up('form');
		
		var userid = form.getForm().findField('role_id').getValue();
		var serverid = form.getForm().findField('serverid').getValue();
		
		if(userid == "")
		{
			Ext.Msg.alert(gm_notice.prompt,gm_error.findplayer);
			return;
		}
		
		Ext.Msg.confirm(gm_notice.prompt,gm_notice.recharge_playerPwd,function(optional){
			if(optional=='yes'){
				form.submit({
					url: '/gm/index.php?s=/Home/Player/rechargPlayerPwd',
					waitMsg : gm_notice.managestr,
					method: 'GET',
					params: {
						serverid: serverid,
						playerroleid: userid,
					},
					success: function (form, action) {
						if(action.result.success == 'false')
						{
							Ext.Msg.alert(gm_notice.prompt, action.result.data.errorMessage);
						}		
					},
					failure: function(form, action) {
						Ext.Msg.alert(gm_error.error, gm_error.noserver);
					},		
				});
			}
		})
		
	},
	
	chargelist:function(button){
		
	},
});