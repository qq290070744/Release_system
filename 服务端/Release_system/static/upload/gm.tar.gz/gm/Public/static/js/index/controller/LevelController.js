Ext.define('admin.controller.LevelController',{
	extend: 'Ext.app.Controller',
    stores: ['LevelStore'],
	views:['level.List'],
	refs: [{
            ref: 'levelList',
            selector: 'LevelList'
    }],
    init: function () {
        this.control({
			'levelList button[action=levelSearch]'  :  {click:this.levelSearch},
		});
    },
	
	levelSearch:function(button){
		var grid = button.up('panel');

		var serverid = grid.down('#levelserver').getValue();
		//时区转换
		var startdate = Ext.Date.add(new Date(grid.down('#levelstartdate').getValue()));
		var enddate = Ext.Date.add(new Date(grid.down('#levelenddate').getValue()), Ext.Date.HOUR, 24)
			
		store  = this.getStore('LevelStore');

		store.removeAll();  		
        store.load({
                params : {
					serverid : serverid,
					startdate:startdate,
					enddate:enddate,
                }
            });
	},
	
});