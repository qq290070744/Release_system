Ext.define('admin.controller.ScrollbarController',{
	extend: 'Ext.app.Controller',
    models: ['ScrollbarModel'],
    stores: ['ScrollbarStore'],
	views:['scrollbar.List','scrollbar.Edit'],
	refs: [{
            ref: 'ScrollbarList',
            selector: 'scrollbarList'
    }],
    init: function () {
        this.control({
			'scrollbarList'                       		  :  {itemdblclick:this.itemdblclick},
			'scrollbarList button[action=scrollbarCreate]'     :  {click: this.scrollbarCreate},
			'scrollbarEdit button[action=scrollbarCreateBtn]'     :  {click: this.scrollbarCreateBtn},
			'scrollbarList button[action=scrollbarSearch]'     :  {click: this.scrollbarSearch},
			'scrollbarList button[action=scrollbarDelete]'     :  {click: this.scrollbarDelete},
			'scrollbarList button[action=scrollbarUpdate]'     :  {click: this.scrollbarUpdate},
		});
    },
	
	itemdblclick:function(grid, record, item, index, e, eOpts){
		
		if(record.getAt('valid') == false)
		{
			var view=Ext.widget('scrollbarEdit');
			view.down('form').loadRecord(record);
		}
		else{
			Ext.Msg.alert(gm_error.error, gm_error.scrollbar);
		}

	},
	
	scrollbarCreate:function(button){
		Ext.widget('scrollbarEdit');
	},
	
	scrollbarCreateBtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        record = form.getRecord(),
        values = form.getValues();
		
		var store  = this.getStore('ScrollbarStore');	
		
		//验证有没有修改
		if(form.getForm().isValid()){
			if(record){
				record.set(values);
				win.close();
				store.sync();
				store.load();
			}
			else
			{
				form.submit({
				url:'/gm/index.php?s=/Home/Notice/addScrollbarNotic.html',
				waitMsg : gm_notice.managestr,
				method: 'POST',
				params: values,
				success: function(form, action) {
					if(action.result.success == 'true')
					{
						store.load({});
						win.close();
					}
					else{
						Ext.Msg.alert(gm_error.error, action.result.errorMessage);
					}

				},
				failure: function(form, action) {
					Ext.Msg.alert(gm_error.error, action);
				},		
				});
			}
		}
		else{
			win.close();
		}
		
		
	},
	
	scrollbarSearch:function(button){
		var grid = button.up('panel');
		var serverid = grid.down('#serverid').getValue();
		var valid =Number(grid.down('#valid').getValue());

		if(serverid==null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		var store  = this.getStore('ScrollbarStore');	
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
					valid:valid,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});	
	},

	
	scrollbarDelete:function(button){
		var grid = this.getScrollbarList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('ScrollbarStore');			
		
		if(record.length<=0){
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					store.remove(record);
					store.sync();
					store.load();
				}
			})
		}
	},
	
	scrollbarUpdate:function(button){
		var grid = this.getScrollbarList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('ScrollbarStore');			
		
		if(record.length<=0){
			Ext.Msg.alert(gm_notice.prompt,gm_error.scrollbarup);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.scrollberup,function(optional){
				if(optional=='yes'){
					var valid =Number(grid.down('#valid').getValue());
					var list = [];	
					for (var i = 0; i < record.length; i++) {
						list.push(record[i].data);
					}
					
					if(valid == 0)
					{
						valid = 1;
					}
					else{
						valid = 0;
					}
					var param = {
						valid:valid,
						data:Ext.encode(list),
					}
					Ext.MessageBox.wait(gm_notice.managestr,gm_notice.prompt);
					
					Ext.Ajax.request({
						url:'/gm/index.php?s=/Home/Notice/validScrollbarNotic',
						method: 'POST',
						params: param,
						success: function(response) {
							Ext.MessageBox.hide();
							
							var result = Ext.decode(response.responseText);
							
							if(result.success == 'true')
							{
								store.load({});
							}
							else{
								Ext.Msg.alert(gm_error.error, result.errorMessage);
							}
						},
						failure: function(response) {
							Ext.MessageBox.hide();
							
							var result = Ext.decode(response.responseText);
							Ext.Msg.alert(gm_error.error, result);
						},		
					});
				}
			})
		}
	},
});