Ext.define('admin.view.layout.Header',{
	extend:'Ext.panel.Panel',
	xtype: 'adminheader',
	initComponent: function(){
		Ext.apply(this,{
			region:'north',
			height:60,
			split: true,
			bodyCls:'header',
			html:gm_string.gmmanagertool,
			bbar: [
			 // {text:'我的面板',iconCls:'Computeroff',action:'wdmb'},'-',
			 // {text:'系统设置',iconCls:'Cog',action:'xtsz'},'-',
			 // {text:'操作日志',iconCls:'Pagewhiteedit',action:'nrgl'},'-',
			 // {text:'用户管理',iconCls:'Group',action:'yhgl'},'->',
			 // {text:'使用帮助',iconCls:'Help',action:'sybz'},'-',
			  {text:gm_string.exits_sys,iconCls:'Usergo',action:'tcxt'}
			]
		});
		this.callParent(arguments);
	}
});
