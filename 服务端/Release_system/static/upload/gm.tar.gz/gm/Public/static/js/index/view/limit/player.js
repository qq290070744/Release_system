Ext.define('admin.view.limit.player',{
	extend:'Ext.window.Window',
	alias : 'widget.limitplayer',
	title:gm_limit_account.limit_account_immediatly,	
	layout:'fit',
	resizable : false,
	autoShow:true,
    initComponent: function(){
		this.fieldDefaults={
			allowBlank : false,
			labelAlign :'right'
		},
		this.items=[
		{
			xtype:'form',
			bodyPadding : 5,
			fieldDefaults:{
				labelAlign :'left',
				labelWidth : 120,
				allowBlank : false
			},
			items:[
				{
					xtype:'combobox',
					name:'server',  
					fieldLabel:gm_string.serverselect,  
					triggerAction: 'all',
					store : {
						autoLoad: false,
						fields:['id','name'],
						proxy: {
							type: 'ajax',
							url: '/gm/index.php?s=/Home/ComboBox/getSeverComboBox.html'
						},
						autoDestroy: false
					},
					displayField:'name',
					valueField:'id',
					mode: 'local', 
					forceSelection : true, 
					typeAhead : true,
					handleHeight : 10,
					autoDestroy: false
				},{
					xtype: 'textarea',
					name: 'players',
					fieldLabel: gm_string.accid,
					emptyText:gm_limit_account.limit_account_request
					//readOnly:true,
				},{
					xtype:'checkboxfield',
					itemId:'iskickout', 
					name:'iskickout',
					fieldLabel: gm_limit_account.isKickout,
					inputValue:false,
					uncheckedValue:false,
					checked:true
				},{
					xtype: 'numberfield',
					name: 'time',
					fieldLabel: gm_limit_account.limit_account_period
				},{
					xtype: 'textarea',
					name: 'remark',
					fieldLabel: gm_common.recommend
				}
				],
		},]
		this.bbar=[
			'->',
			{text: gm_btnstring.confirm,iconCls: 'Zoom', action: 'limitplayerbtn'},
			'->'
		],
	    this.callParent(arguments);
    }
});