var m_serverid = 0;

Ext.define('admin.controller.LimitController',{
	extend: 'Ext.app.Controller',
    models: ['LimitModel'],
    stores: ['LimitStore'],
	views:['limit.List','limit.player'],
	refs: [{
            ref: 'LimitList',
            selector: 'limitList'
    }],
    init: function () {
        this.control({
			'limitList button[action=limitSearch]'     :  {click: this.limitSearch},
			'limitList button[action=limitCreate]'     :  {click: this.limitCreate},
			'limitplayer button[action=limitplayerbtn]'     :  {click: this.limitplayerbtn},
			'limitList button[action=limitDelete]'     :  {click: this.limitDelete},

		});
    },
	
	
	limitCreate:function(button){
		Ext.widget('limitplayer');
	},
	
	limitplayerbtn:function(button){
		var win    = button.up('window'),
        form   = win.down('form'),
        values = form.getValues();
		
		var data = [];
		
		data['end_time'] = Ext.Date.add(new Date(),Ext.Date.MINUTE,values['time']);
		
		var strlist = values['players'].split(";");
		var acclist = [];	
		for(var i in strlist)
		{
			if(strlist[i] != "")
			{
				acclist.push(strlist[i]);
			}
		}
		
		data['accid'] = Ext.encode(acclist);
		
		form.submit({
			url:'/gm/index.php?s=/Home/Limit/addLimit.html',
			waitMsg : gm_notice.managestr,
			method: 'POST',
			params: data,
			success: function(form, action) {
				if(action.result.success == 'true')
				{
					win.close();
				}
				else{
					Ext.Msg.alert(gm_error.error, action.result.errorMessage);
				}

			},
			failure: function(form, action) {
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
	},
	
	limitSearch:function(button){
		var grid = button.up('panel');
		var serverid = grid.down('#serverid').getValue();

		if(serverid==null)
		{
			Ext.Msg.alert(gm_error.error, gm_error.servererror);
			return;
		}
		
		store  = this.getStore('LimitStore');	
		
		store.removeAll();
		store.currentPage = 1;
		store.on('beforeload', function (store, options) {
				var new_params = {
					serverid : serverid,
                };
			Ext.apply(store.proxy.extraParams, new_params);
		});	
			
				
		store.load({});
		
		m_serverid = serverid;
	},

	limitDelete:function(button){
		var grid = this.getLimitList(),
		record = grid.getSelectionModel().getSelection(),
		store = this.getStore('LimitStore');			
		
		if(record.length<=0){
			Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr);
		}else{
			Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
				if(optional=='yes'){
					
					var list = [];	
					for (var i = 0; i < record.length; i++) {
						list.push(record[i].data);
					}
					
					var param = {
						serverid:m_serverid,
						data:Ext.encode(list),
					}
					
					Ext.MessageBox.wait(gm_notice.managestr,gm_notice.prompt);
					
					Ext.Ajax.request({
						url:'/gm/index.php?s=/Home/Limit/delLimit',
						method: 'POST',
						params: param,
						success: function(response) {
							Ext.MessageBox.hide();
							
							var result = Ext.decode(response.responseText);
							
							if(result.success == 'true')
							{
								store.load({});
							}
							else{
								Ext.Msg.alert(gm_error.error, result.errorMessage);
							}
						},
						failure: function(response) {
							Ext.MessageBox.hide();
							
							var result = Ext.decode(response.responseText);
							Ext.Msg.alert(gm_error.error, result);
						},		
					});
				}
			})
		}
	}
});