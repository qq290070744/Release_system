Ext.define('admin.controller.ServerController',{
	extend: 'Ext.app.Controller',
    models: ['ServerModel'],
    stores: ['ServerStore'],
	views:['server.List','server.Edit','server.AccEdit'],
	refs: [{
            ref: 'serverList',
            selector: 'ServerList'
    }],
    init: function () {
        this.control({
			'ServerList'                       		  :  {itemdblclick:this.itemdblclick},
			'ServerEdit button[action=serverEditSave]'  :  {click:this.serverEditSave},
            'ServerList button[action=serverAdd]'       :  {click: this.serverAdd},
            'ServerList button[action=serverDelete]'    :  {click: this.serverDelete},
            'ServerEdit button[action=serverEditClose]' :  {click: this.serverEditClose},
            'ServerList button[action=accserverEdit]'  :  {click:this.accserverEdit},
            'accServerEdit button[action=accserverEditSave]'  :  {click:this.accserverEditSave},
		});
    },
    
    accserverEdit:function(button){
		var view=Ext.widget('accServerEdit');
		var form = view.down('form');
		var params = [];
		form.load({
			url:'/gm/index.php?s=/Home/Server/getAccInfo',	
		});
	},
	

	accserverEditSave:function(button){
		 var win    = button.up('window'),
         	form   = win.down('form'),
         	record = form.getRecord();
		
		form.submit({
			url:'/gm/index.php?s=/Home/Server/editAccInfo',
			waitMsg : gm_notice.managestr,
			method: 'POST',
			params: record,
			success: function(form, action) {
				if(action.response.responseText == true)
				{
					form.load({
						url:'/gm/index.php?s=/Home/Server/getAccInfo',	
					});
				}

			},
			failure: function(form, action) {
				Ext.Msg.alert('server test001','server test001');
				Ext.Msg.alert(gm_error.error, action);
			},		
		});
	},
	
	itemdblclick:function(grid, record, item, index, e, eOpts){
		var view=Ext.widget('ServerEdit');
		view.down('form').loadRecord(record);
	},
	
	serverAdd:function(button){
		var view=Ext.widget('ServerEdit');
	},
	serverEditSave:function(button){
        var win    = button.up('window'),
            form   = win.down('form'),
            record = form.getRecord(),
            values = form.getValues(),
			store  = this.getStore('ServerStore'),
			model  = this.getModel('ServerModel');
			
			if(form.getForm().isValid()){
				if(record){
					record.set(values);
				}else{
					record = Ext.create(model);
					record.set(values);
					store.add(record);
				}
				win.close();
				store.sync();
				store.load();
			}
	},
    serverDelete: function(button) {
    	var grid = this.getSeverList();
		var	record = grid.getSelectionModel().getSelection();
		var	store = this.getStore('ServerStore');			
			if(record.length<=0){
				Ext.Msg.alert(gm_notice.prompt,gm_error.deletestr );
			}else{
				Ext.Msg.confirm(gm_notice.prompt,gm_notice.deletestr,function(optional){
					if(optional=='yes'){
						store.remove(record);
						store.sync();
						store.load();
					}
				})
			}
    },
	serverEditClose:function(button){
		button.up('window').close()
	},
	
});